const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const base=__dirname,out=path.join(path.dirname(base),'outputs'),final=path.join(base,'repair-evidence-final'),source=JSON.parse(fs.readFileSync(path.join(final,'source-manifest.json')));
const acceptedRoot=path.join(base,'repair-evidence-accepted'),accepted=JSON.parse(fs.readFileSync(path.join(acceptedRoot,'source-manifest.json')));
const read=p=>JSON.parse(fs.readFileSync(path.join(final,p),'utf8'));
for(const [group,n] of Object.entries({runtime:1,application:8,browser:5,regression:9})){const groupRead=p=>JSON.parse(fs.readFileSync(path.join(group==='browser'?acceptedRoot:final,p),'utf8'));const commands=groupRead(group+'-01/'+group+'-commands.json');assert.equal(commands.length,n);assert.ok(commands.every(c=>c.passed));assert.equal(groupRead(group+'-01-commands.json')[0].exit,0);}
const rows=JSON.parse(fs.readFileSync(path.join(base,'row-dispositions.json'),'utf8'));
Object.assign(rows,{
 A01:['Verified candidate','Repair branch codex/quotedone-audit-repairs-20260927; review commit '+accepted.head+'. Application/runtime/regression commit '+source.head+'; application bytes are identical. The accepted completion/main branches are preserved.'],
 A02:['Verified unchanged','All 19 accepted engine files retain tree '+source.engineTree+'.'],
 A03:['Verified execution','Fresh committed-source runtime, application, browser, full regression and build completed; exact logs/exits and source bindings are packaged.'],
 A04:['Coverage improved; not exhaustive','Positive fixtures no longer declare unresolved notes/unknowns. Whole-request negatives, all 20 adapters and prior suites pass; arbitrary combinations are not proved.'],
 A07:['Fixed documentation','Added floor-overlay decision, corrected original >=300 provenance, reconciled main master-toggle rule, and made current no-assumption voice rules explicit.'],
 B01:['Verified controls','Existing exact arithmetic controls pass; wire-token fidelity now prevents loss before route validation.'],
 B02:['Verified fixed','Lossy raw HTTP decimals reject before any write, including BOM-prefixed JSON, nested maps/tiers/factors and customer measurements. Valid 200.01 and 90071992547409.90 persist and quote unchanged.'],
 B14:['Verified fixed boundary','Structured missing facts and explicit external unknowns review; all original details are retained.'],
 B16:['Confirmed omission fixed; breadth remains bounded','Unknown/additional scope cannot release the selected-service subtotal. Existing selected-fee/add-on controls pass; no universal combination claim.'],
 C01:['Verified fixed','Array, text and object unknowns block instant estimates on public, authenticated and preview paths.'],
 C02:['Verified fixed','Untriaged context, differing serviceRequest and unsupported envelope fields require complete-request review.'],
 C03:['Verified fixed','Text asking for bagging/removal cannot be ignored when structured inputs say No; it triggers review.'],
 C04:['Safely restricted','No unproven scope/logistics classifier was added. Nonempty notes, including benign access notes, currently require review.'],
 D05:['Verified guard; ledger fixed','Floor overlay remains review-only; its preparation/compatibility/pricing decision is now recorded.'],
 D06:['Intentional accepted restriction','Exact configured room thresholds still review. No wrong numeric quote was demonstrated; no custom equality policy invented.'],
 D07:['Fixed provenance','Original default >=300 ->1.00 is explicitly acknowledged. Later accepted all-threshold equality guard remains; historical engine documents are identified as checkpoint records.'],
 E02:['Additional defect reproduced and fixed','Jurisdiction text 1.0000000000000001 previously saved as 1. Exact validation and raw UI text now prevent that. Jurisdiction edits invalidate approval/revision; interview routes remain draft-only.'],
 E05:['Verified and extended','Actual 400/409/413/422 browser recovery, real 500 rollback and lost-response retries; concurrency, tenant isolation and restart also pass.'],
 E06:['Historical receipt rule preserved; expiry policy unresolved','Exact retry is immutable, including after tax/rate edits. Expiry and offer-validity policy remain a separate business decision.'],
 E07:['Verified fixed per owner ruling','Every new estimate submission requires email or phone syntax, including instant quotes. Missing/blank/malformed contact rejects before writes; editable correction survives reload. Reachability is not asserted.'],
 E08:['Verified fixed','Customer renders optionAvailabilityNotice; mixed tiers show it, all valid tiers omit it, all-review tiers release no price.'],
 E09:['Verified fixed','Definitive 400/409/413/422 rejections restore details and allow correction with a new UUID. Uncertain failures keep the immutable retry payload. Restored textarea labels remain stable.'],
 E10:['Verified fixed','Operator owners and existing authorized staff can list/read/update their tenant leads; price/calculation access stays gated. No additional seats are provisioned.'],
 E11:['Verified fixed in tested topologies','Real cross-origin and same-origin browser catalog/submission work, preserving exact allowlist denial cases. Deployed topology remains unverified.'],
 F01:['Fixed current specification','Current voice document forbids paced/guessed/substituted measurements and retains unknowns; old scripts are archived as history. Live voice execution is still a separate gate.'],
 F03:['Confirmed defects closed; launch acceptance outstanding','This repair candidate is ready for independent review. Unsupported pricing contracts and unverified deployment/provider/live-data gates still prevent a universal public-launch certification.']
});
assert.equal(Object.keys(rows).length,73);
const body=`# Off The Clock AI — verified repairs and project state

**The confirmed audit defects are repaired and verified in the local application. The candidate is ready for independent repository review; this is not a certification of 100% real-world quote accuracy or public-launch readiness.**

Repository: sportaholic000-hue/off-the-clock. Review branch: \`codex/quotedone-audit-repairs-20260927\`. Review/browser commit: \`${accepted.head}\`. Runtime, application and regression groups ran at \`${source.head}\`, from accepted completion \`9670fdb5c55f35a0ccddcd397f2d188b5c811844\`. Those commits have identical application, engine and ordinary-test bytes; their sole difference is a Country-control selector in the new browser harness. The complete browser group was rerun at the review commit after that test fix. Later delivery-only documentation/evidence commits contain identical application and test code. Accepted engine tree: \`${source.engineTree}\` (all 19 files unchanged).

## Verified repairs

| Finding | Current behavior | Direct acceptance evidence |
|---|---|---|
| Incomplete or contradictory request released a subtotal | Declared unknowns, additional context, differing service descriptions and unsupported envelope fields require whole-request review. Public submission, authenticated calculation and owner preview agree. Complete measured $50 controls still quote. | audit-repairs-http; audit-repairs-browser; all-adapters; access-retry-workflow |
| Raw decimal changed before validation | Wire decimals that would change value reject before saving. Strings are not misread as numbers; escaped duplicate keys reject; UTF-8 BOM cannot bypass validation. Representable large amounts, 0.1, fractional unit rates and high valid markup remain supported. | audit-repairs-http/wire-results.json; quoteApplicationBoundary.spec.mjs; money-workflow |
| Additional tax-writer precision defect | Actual pre-repair POST accepted text 1.0000000000000001 and stored 1. The owner form now transmits the original text and the server validates exact decimal preservation. Rejection writes nothing; correction to 7.5 saves exactly. | development/tax-text-before/result.json; audit-repairs-http; audit-repairs-browser/tax-browser.json |
| No callback contact | Following the owner's ruling, every new submitted estimate requires an email or telephone with valid syntax, including instant estimates. Missing/name-only/blank/malformed contact gets 422 before any quote, lead or request row is saved. Details remain editable across reload. | contact-workflow; audit-repairs-browser 422 corrections |
| Partial tier notice disappeared | Available estimates display the engine's safe option-availability notice. All valid options show their expected prices; all-review configurations show no price. | audit-repairs-browser partial/all-valid/all-review cases |
| Failed requests trapped the user in retry | Real 400/409/413/422 responses restore the original fields; correction uses a new UUID. A local size check prevents new oversized submissions. Network/server uncertainty preserves the exact pending request, including across reload. Restored textarea labels stay accessible. | audit-repairs-browser, actual SQLite abort and dropped upstream responses |
| Operator CRM denied | Lead list/detail/status updates work for authenticated existing owner/staff roles on Operator. Another tenant cannot read/change them; staff do not receive owner-only calculations. Quote/pricing plan restrictions remain. | audit-repairs-http role/tenant matrix |
| Same-origin quote form failed | Allowed same-origin browser GETs can use same-origin Fetch Metadata plus Referer when Origin is absent. Cross-origin flow works; wrong/null/missing origin controls still deny. Explicit empty API URL is supported; production default is same-origin. | audit-repairs-http origin matrix; real Chromium through same-origin forwarding proxy |
| Conflicting project records | Current voice collection rules no longer direct guessed measurements. The old flow is preserved as history. Floor-overlay guard is in the decision ledger, original >=300 threshold provenance is corrected, and main's recorded master-toggle rule is reconciled. | REPAIR_CONTRACT_20260927.md, OWNER_DECISIONS.md and current specs |

No owner rate, measurement, product identity, charge allocation, tax policy or unsupported service formula was invented. Review-gated requests retain the complete original submission and saved-book snapshot. The application marks an early scope review as an application decision; it does not pretend the arithmetic engine ran.

## Verification completed

All final runs use a fresh isolated store and the unchanged locked dependencies under portable Node 22.23.2, Windows x64 / ABI 127. The canonical worktree is bound to Git blobs; individual runtime, HTTP and browser runs record executed file hashes.

| Check | Result |
|---|---|
| Native runtime | Real SQLite create/commit/rollback/reopen/integrity, bcrypt, registration/login and authorization pass. |
| Application group | 8 workflows pass: all adapters, money, access/retry, legacy approval, identity ambiguity, audit repairs, contact and synthetic schema upgrade. |
| Service adapters | 20 independently specified service fixtures plus 20 missing-measurement controls; 16 quote-capable ordinary controls and 4 intentional review-only types. |
| Financial application controls | 65 pass, including fractional rates, fixed cents, high markup, margin, fees, tax, minimums, ranges, zero classifications and conditional review guards. |
| Browser group | 5 real browser workflows pass: full owner/customer/review/restart journey, configuration/privacy, reordered preview responses/editor integrity, structured measurements, and the new audit repairs including the real tax-entry form. |
| Ordinary regression | 430/430 pass. |
| VNext suite | 311/311 pass. |
| Phase 1 engine suite | 46/46 pass. |
| Original independent precision cases | 22/22 pass, original fixture unchanged. |
| Focused suite | 30/30 pass: previous 25 editor/store/fixture controls plus 5 new boundary tests. |
| Instrumented replay | 35/35 pass. |
| Integration boundary | Sole authorized bridge and frozen 19-file engine verified; no legacy fallback. |
| Client build | Existing locked Vite entrypoint builds successfully. |

Counts overlap and must not be added together as unique scenarios. The unchanged historical no-application-import gate exits 1 because it rejects the now-authorized quoteDoneBridge.js; the runner expects that precise rejection. It is **not** reported as a passing isolation gate. The separate current integration-boundary check passes.

Earlier attempts are retained, including failures. They include a restored-textarea label defect fixed in the implementation, Chrome automatically recovering a dropped response before the first fault-injection harness expected it, a harness assertion racing catalog loading, and a Country-control locator mismatch in the expanded tax UI test. In the archive, final/browser-01 is the failed locator attempt; accepted/browser-01 is its successful complete five-workflow rerun. The accepted runtime, application and regression groups are under final/. HTTP/browser tests use real servers, auth and SQLite; a synthetic SQLite abort and a real dropped response exercise failure behavior. Existing component tests remain component tests.

## Current project state and remaining release gates

The repository contains a React/Vite owner/customer interface, Express application, SQLite accounts/quotes/leads and per-owner JSON price books. A single application bridge calls the accepted VNext engine. Owner configuration approval, enabled status and revisions gate customer quotes; quote-or-review persistence commits before acknowledgement. Exact retries recover the saved historical receipt, not a newly priced offer.

The owner now explicitly requires callback contact for every estimate. An email or phone alone is sufficient; syntax checks do not prove ownership, consent or deliverability. Untriaged notes currently require review even when they appear to concern harmless logistics. This deliberately avoids guessing their pricing significance.

**Still review-only:** FENCING_INSTALL, FENCING_REPLACEMENT, EXTERIOR_PAINTING and CUSTOM. Conditional guards also remain for unresolved scopes such as flooring overlay/stairs/product underlayment/exact thresholds, purchase-package material costs, fair/poor or mixed-zone interior paint, siding trim/removal, concrete demolition/exposed aggregate, commercial flat-roof insulation and seasonal date policy. OWNER_DECISIONS.md records the specific missing contracts. These guards were preserved and verified, not relabeled as completed instant-quote capabilities.

**Still unverified:** actual deployed commit/proxy/runtime; production traffic and limiter behavior; multi-process file-book compare-and-swap; backup restoration and live legacy-data migration; contractor-specific rates, quantities, category definitions, material identity and applicable tax choices; exhaustive scope/fee combinations; quote expiry/offer-validity policy. The tests establish declared synthetic calculations, not the accuracy of external facts supplied by a customer or contractor.

The public-page branch remains a separate review library; the sales-demo branch still lacks real Gemini/microphone acceptance. Voice, messaging, booking, billing, widget publication and other unfinished platform phases are not made launch-ready by this repair. BUILD_STATUS keeps the broader Phase 2–6 gates open. No protected branch merge, production deployment, paid provider call, phone provisioning, external message or real-data migration was performed.

Independent review should check this branch and its evidence first. A public release still needs the deployed candidate identified, supported offerings/owner rules accepted, production smoke tests and the applicable operational/provider gates completed. Enabling unresolved services requires explicit pricing contracts; removing review guards would not establish accuracy.

## Reproduce and inspect

Use the existing REPRODUCE.md runtime instructions and committed run-completion.mjs groups: runtime, application, browser and regression. Supply fresh evidence directories, the compatible locked native runtime, the existing browser/esbuild paths, a candidate Git checkout and the preserved synthetic prior database for schema-upgrade verification. Do not run these fixtures against live stores. New regressions are committed in verification/quotedone/ and test/quoteApplicationBoundary.spec.mjs.

The accompanying evidence archive contains exact commands/exits, final source hashes, safe synthetic HTTP results, screenshots, original development attempts, the extra tax defect reproduction and a read-only inspector. It excludes databases, credentials, runtime binaries and dependency trees. After extraction, set QUOTEDONE_GIT to an available Git executable and run: \`node inspect-repair-evidence.cjs <extracted-directory> <repository>\`. The inspector validates every archived payload hash, source-to-Git binding, execution group and targeted acceptance result.

## Disposition of all 73 audit rows

| ID | Current disposition | Evidence-based state |
|---|---|---|
${Object.entries(rows).map(([id,[state,note]])=>'| '+id+' | '+state+' | '+note.replaceAll('|','\\|')+' |').join('\n')}
`;
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'Off_The_Clock_Verified_Repairs_2026-09-27.md'),body);fs.writeFileSync(path.join(out,'Off_The_Clock_Audit_Dispositions_2026-09-27.json'),JSON.stringify({testedApplicationCommit:source.head,reviewCommit:accepted.head,rows},null,2));console.log(JSON.stringify({report:'Off_The_Clock_Verified_Repairs_2026-09-27.md',rows:Object.keys(rows).length,testedCommit:source.head}));
