const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const repo='C:/Users/money/Documents/Codex/2026-09-09/continue-the-existing-off-the-clock-2/work/quotedone-completion';
const prior=path.join(path.dirname(repo),'quotedone-verification'),git='C:/Users/money/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
const tag=process.argv[2]||'dev',root=path.join(__dirname,'quotedone-verification-repairs-'+tag),evidence=path.join(__dirname,'repair-evidence-'+tag);
const g=(...args)=>cp.execFileSync(git,args,{cwd:repo,encoding:'utf8',windowsHide:true,maxBuffer:30e6}).trimEnd();
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(evidence,{recursive:true});
const names=[...new Set(g('ls-files','--cached','--others','--exclude-standard').split('\n'))].filter(n=>!n.includes('node_modules/')&&!n.includes('/dist/')&&!n.endsWith('.zip')&&(/^(server|client|test|verification|scripts|specs|docs)\//.test(n)||/^[^/]+\.(json|md)$/.test(n)||['.gitignore','.gitattributes'].includes(n)));
const files=[];for(const name of names){const bytes=fs.readFileSync(path.join(repo,name)),normalized=/\.(js|mjs|cjs|jsx|json|md|css|html|txt)$/.test(name)?Buffer.from(bytes.toString('utf8').replace(/\r\n/g,'\n')):bytes;const dst=path.join(root,name);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,normalized);files.push({name,sha256:crypto.createHash('sha256').update(normalized).digest('hex')});}
for(const name of ['node_modules','.portable-runtime'])if(!fs.existsSync(path.join(root,name)))fs.symlinkSync(path.join(prior,name),path.join(root,name),'junction');
const state={repo,root,evidence,head:g('rev-parse','HEAD'),dirty:g('status','--porcelain=v1'),engineTree:g('rev-parse','HEAD:server/quote-engine-vnext'),files};fs.writeFileSync(path.join(evidence,'source-manifest.json'),JSON.stringify(state,null,2));console.log(JSON.stringify({...state,files:files.length},null,2));
