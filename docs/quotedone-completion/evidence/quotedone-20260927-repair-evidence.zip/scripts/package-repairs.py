from pathlib import Path
import json, hashlib, zipfile, datetime, re
base=Path(__file__).resolve().parent
outputs=base.parent/'outputs'
final=base/'repair-evidence-final'
accepted=base/'repair-evidence-accepted'
report=outputs/'Off_The_Clock_Verified_Repairs_2026-09-27.md'
archive=outputs/'Off_The_Clock_Verified_Repair_Evidence_2026-09-27.zip'
assert not archive.exists(), 'Preserve prior delivery archives.'
assert report.exists()
sources=[json.loads((p/'source-manifest.json').read_text()) for p in [final,accepted]]
assert not any(s['dirty'] for s in sources)
for group,count in [('runtime',1),('application',8),('browser',5),('regression',9)]:
    location=accepted if group=='browser' else final
    commands=json.loads((location/f'{group}-01/{group}-commands.json').read_text())
    assert len(commands)==count and all(c['passed'] for c in commands)
    assert json.loads((location/f'{group}-01-commands.json').read_text())[0]['exit']==0
counts={'ordinary':430,'vnext':311,'quote-engine':46,'focused':30}
for name,count in counts.items():
    text=(final/f'regression-01/{name}.log').read_text(encoding='utf-8')
    assert re.search(rf'^# tests {count}$',text,re.M),name
    assert re.search(rf'^# pass {count}$',text,re.M),name
    assert re.search(r'^# fail 0$',text,re.M),name
replay_text=(final/'regression-01/instrumented-replay.log').read_text(encoding='utf-8')
replay,_=json.JSONDecoder().raw_decode(replay_text)
assert len(replay['tests'])==35 and all(row['pass'] for row in replay['tests'])
del replay,replay_text
before={f['name']:f['sha256'] for f in sources[0]['files']}
after={f['name']:f['sha256'] for f in sources[1]['files']}
changed=[n for n in sorted(before.keys()|after.keys()) if before.get(n)!=after.get(n)]
assert changed==['verification/quotedone/audit-repairs-browser.mjs'],changed
proof={'from':sources[0]['head'],'to':sources[1]['head'],'changedFiles':changed,'applicationAndOrdinaryTestsIdentical':True}
(accepted/'source-equivalence.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
items={}
for prefix,folder in [('final',final),('accepted',accepted),('development',base/'repair-evidence-dev')]:
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix in {'.json','.log','.png','.txt','.md','.mjs','.js','.cjs'} and 'pricebooks' not in p.relative_to(folder).parts:
            items[prefix+'/'+p.relative_to(folder).as_posix()]=p
for name in ['setup-repairs.cjs','run-repairs.cjs','reproduce-tax-text.mjs','build-repair-report.cjs','package-repairs.py']:
    items['scripts/'+name]=base/name
items['inspect-repair-evidence.cjs']=base/'inspect-repair-evidence.cjs'
for name in [report.name,'Off_The_Clock_Audit_Dispositions_2026-09-27.json']:
    items[name]=outputs/name
for row in sources[-1]['files']:
    items['tested-source/'+row['name']]=Path(sources[-1]['root'])/row['name']
readme='''Off The Clock AI verified repair evidence, September 27, 2026

Start with Off_The_Clock_Verified_Repairs_2026-09-27.md. It contains verified repairs, limitations and all 73 audit dispositions. This is synthetic local verification, not a production deployment.

Accepted groups:
- final/runtime-01: native runtime, genuine app startup and authentication.
- final/application-01: eight workflows including contact and HTTP precision.
- accepted/browser-01: five browser workflows, rerun after the Country locator fix.
- final/regression-01: original suites, replay, current integration check and build.

final/browser-01 is the preserved FAILED expanded browser attempt. Use accepted/browser-01 for its successful rerun. development/ contains prior attempts and tax-text-before. Do not report failed attempts as passes.

The two source-manifest.json files record both immutable test commits. accepted/source-equivalence.json proves that their sole difference is the browser test Country selector. Application, engine and ordinary-test bytes match. The 19-file accepted engine is unchanged. The inspector records Git checkout line-ending conversions for .gitignore and three historical Python scripts; executed application bindings must still match their manifest hashes exactly.

Run the read-only inspector from a checkout containing both commits:
  node inspect-repair-evidence.cjs <extracted-directory> <repository>
Set QUOTEDONE_GIT to an available Git executable if needed. ARCHIVE_MANIFEST.json lists all payload hashes. The inspector checks archive hashes, Git source blobs, accepted command groups, targeted assertions and executed bindings.

Reproduction uses the committed verification/quotedone/run-completion.mjs with the compatible locked native runtime, existing browser and esbuild paths documented in REPRODUCE.md. Use fresh synthetic stores. No paid provider calls occur. The schema-upgrade fixture is synthetic. scripts/ records this machine's setup; adapt paths for another machine.

No runtime executables, dependencies, credentials or SQLite databases are included. Contacts, customer records and screenshots are synthetic; request-log secrets are omitted. The historical no-import gate's one-bridge rejection is expected exit 1, not a passing gate.
'''
entries=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(items.items()):
        data=p.read_bytes();z.writestr(name,data);entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    data=readme.encode();z.writestr('README.txt',data);entries.append({'path':'README.txt','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    z.writestr('ARCHIVE_MANIFEST.json',json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedApplicationCommit':sources[0]['head'],'reviewCommit':sources[1]['head'],'files':entries},indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in entries:
        data=z.read(row['path']);assert len(data)==row['bytes'];assert hashlib.sha256(data).hexdigest()==row['sha256']
    extracted=base/'repair-evidence-inspection';assert not extracted.exists();extracted.mkdir();z.extractall(extracted)
result={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloadFiles':len(entries),'allMemberHashesVerified':True,'testedApplicationCommit':sources[0]['head'],'reviewCommit':sources[1]['head'],'sourceEquivalence':proof,'report':report.name,'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest(),'testCounts':counts,'instrumentedReplay':'35/35'}
(outputs/'REPAIR_DELIVERY_VERIFICATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
