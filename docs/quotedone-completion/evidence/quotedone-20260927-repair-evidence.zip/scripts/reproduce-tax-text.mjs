import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const [root,evidence]=process.argv.slice(2).map(v=>path.resolve(v));
const {startApplication}=await import(pathToFileURL(path.join(root,'verification/quotedone/application-harness.mjs')));
const {mowingFixture}=await import(pathToFileURL(path.join(root,'verification/quotedone/repair-fixture.mjs')));
const app=await startApplication(root,evidence,{port:4491});
try{const f=await mowingFixture(app,'tax-text-before'),before=await f.read(),reply=await app.request('POST','/api/business/jurisdiction',{country:'US',region:'NY',taxMode:'TAX_ALL',taxPercent:'1.0000000000000001'},f.owner.token),after=await f.read();const result={wireTaxPercent:'1.0000000000000001',status:reply.status,storedTaxPercent:after.defaults.taxPercent,changed:before.revision!==after.revision};fs.writeFileSync(path.join(evidence,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));}finally{await app.stop();}
