// Read-only evidence checks. Run from any checkout containing the tested commit:
// node inspect-repair-evidence.cjs <extracted archive> <repository>
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'.'),repo=path.resolve(process.argv[3]||'.'),git=process.env.QUOTEDONE_GIT||'git';
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const archive=read('ARCHIVE_MANIFEST.json');for(const row of archive.files)assert.equal(sha(fs.readFileSync(path.join(root,row.path))),row.sha256,row.path);
const manifest=read('final/source-manifest.json'),accepted=read('accepted/source-manifest.json');assert.equal(manifest.dirty,'');assert.equal(accepted.dirty,'');
const g=(...args)=>cp.execFileSync(git,args,{cwd:repo,maxBuffer:30e6,windowsHide:true});
const lineEndingConversions=[];
for(const row of [...manifest.files.map(r=>({...r,commit:manifest.head})),...accepted.files.map(r=>({...r,commit:accepted.head}))]){
 const blob=g('show',row.commit+':'+row.name);
 if(sha(blob)===row.sha256)continue;
 const text=blob.toString('utf8');assert.ok(Buffer.from(text).equals(blob),row.name+' unexpected binary difference');
 const variants=[['CRLF to LF',text.replace(/\r\n/g,'\n')],['Git checkout LF to CRLF',text.replace(/\r?\n/g,'\r\n')]];
 const match=variants.find(([,value])=>sha(Buffer.from(value))===row.sha256);
 assert.ok(match,row.name+' differs from tested Git content beyond line endings');
 lineEndingConversions.push({commit:row.commit,file:row.name,conversion:match[0]});
}
assert.equal(g('rev-parse',manifest.head+':server/quote-engine-vnext').toString().trim(),manifest.engineTree);
const groups={runtime:1,application:8,browser:5,regression:9};
for(const [group,count]of Object.entries(groups)){
 const prefix=group==='browser'?'accepted':'final';const commands=read(prefix+'/'+group+'-01/'+group+'-commands.json');assert.equal(commands.length,count);
 for(const row of commands){assert.equal(row.passed,true);assert.equal(row.exit,row.name==='historical-isolation'?1:0);assert.equal(row.expectedExit,row.exit);}
 const outer=read(prefix+'/'+group+'-01-commands.json');assert.equal(outer.length,1);assert.equal(outer[0].exit,0);
}
const adapters=read('final/application-01/all-adapters/results.json');assert.equal(adapters.length,20);assert.equal(adapters.filter(r=>r.expectedCents!==null).length,16);for(const row of adapters){assert.equal(row.passed,true);assert.equal(row.negative.resultType,'ESTIMATE_REQUIRES_REVIEW');}
for(const p of ['final/application-01/audit-repairs-http/result.json','final/application-01/contact-workflow/result.json','accepted/browser-01/audit-repairs-browser/result.json'])assert.equal(read(p).passed,true,p);
const money=read('final/application-01/money-workflow/results.json');for(const row of money)assert.equal(row.passed,true,row.name);
// Every executed source binding must agree with the immutable manifest, after
// the copy's recorded CRLF -> LF normalization. No production receipt implied.
const fileHashes=new Map(manifest.files.map(r=>[r.name,r.sha256]));let bindings=0;
function scan(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,ent.name);if(ent.isDirectory())scan(p);else if(ent.name==='source-binding.json'){const binding=JSON.parse(fs.readFileSync(p));assert.equal(binding.version,'v22.23.2');for(const [name,hash]of Object.entries(binding.files))assert.equal(hash,fileHashes.get(name),name+' binding differs');bindings++;}}}
scan(path.join(root,'final'));fileHashes.clear();for(const r of accepted.files)fileHashes.set(r.name,r.sha256);scan(path.join(root,'accepted'));assert.ok(bindings>=18);const changed=manifest.files.filter(r=>accepted.files.find(a=>a.name===r.name)?.sha256!==r.sha256).map(r=>r.name);assert.deepEqual(changed,['verification/quotedone/audit-repairs-browser.mjs']);
const result={passed:true,testedApplicationCommit:manifest.head,browserAndReviewCommit:accepted.head,engineTree:manifest.engineTree,archiveMembers:archive.files.length,sourceFiles:manifest.files.length,lineEndingConversions,bindings,groups,adapterControls:20,quoteCapableControls:16,moneyControls:money.length};console.log(JSON.stringify(result,null,2));
