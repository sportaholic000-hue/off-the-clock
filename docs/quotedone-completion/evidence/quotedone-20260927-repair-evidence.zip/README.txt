Off The Clock AI verified repair evidence, September 27, 2026

Start with Off_The_Clock_Verified_Repairs_2026-09-27.md. It contains verified repairs, limitations and all 73 audit dispositions. This is synthetic local verification, not a production deployment.

Accepted groups:
- final/runtime-01: native runtime, genuine app startup and authentication.
- final/application-01: eight workflows including contact and HTTP precision.
- accepted/browser-01: five browser workflows, rerun after the Country locator fix.
- final/regression-01: original suites, replay, current integration check and build.

final/browser-01 is the preserved FAILED expanded browser attempt. Use accepted/browser-01 for its successful rerun. development/ contains prior attempts and tax-text-before. Do not report failed attempts as passes.

The two source-manifest.json files record both immutable test commits. accepted/source-equivalence.json proves that their sole difference is the browser test Country selector. Application, engine and ordinary-test bytes match. The 19-file accepted engine is unchanged. The inspector records Git checkout line-ending conversions for .gitignore and three historical Python scripts; executed application bindings must still match their manifest hashes exactly.

Run the read-only inspector from a checkout containing both commits:
  node inspect-repair-evidence.cjs <extracted-directory> <repository>
Set QUOTEDONE_GIT to an available Git executable if needed. ARCHIVE_MANIFEST.json lists all payload hashes. The inspector checks archive hashes, Git source blobs, accepted command groups, targeted assertions and executed bindings.

Reproduction uses the committed verification/quotedone/run-completion.mjs with the compatible locked native runtime, existing browser and esbuild paths documented in REPRODUCE.md. Use fresh synthetic stores. No paid provider calls occur. The schema-upgrade fixture is synthetic. scripts/ records this machine's setup; adapt paths for another machine.

No runtime executables, dependencies, credentials or SQLite databases are included. Contacts, customer records and screenshots are synthetic; request-log secrets are omitted. The historical no-import gate's one-bridge rejection is expected exit 1, not a passing gate.
