# Independent expected outcomes, recorded before implementation

Authorization: 51e5125297a58ca75695120fee0d20dbebb1ca07 docs/quotedone-completion/START_HERE.md and ACCEPTANCE.md.

- Original regression script must match its committed SHA-256 byte-for-byte on Windows and Linux. A one-byte change must still fail the manifest check. Only checkout line endings are corrected; no fixture or runner expectations change.
- Preview A held in flight while input or service changes to B: only B may render. Late A success, error and finally completion cannot replace B or clear its loading state. Changing B to invalid input immediately removes any ready result. Unchanged focus/blur leaves the result and book unchanged.
- Price-book write failures must preserve complete prior bytes. A successful save must reload the exact new book and revision; unchanged numeric values/placements/IDs/disabled choices remain unchanged.
- Trusted server identity and selected saved service ID govern every quote. Customer/staff output contains no internal rates/evidence. Duplicate same-content requests within one tenant return one persisted outcome; changed content with the same key conflicts.
- Every submitted unquotable scope becomes a durably saved complete lead before acknowledgement. Restart retains books, approval state, results and idempotency records.
- Independent arithmetic: 10000 square feet at $0.0049/$0.0050/$0.0051 with neutral confirmed multipliers gives $49/$50/$51 before any explicitly configured adjustments. A $200.01 effective minimum remains $200.01 under the accepted exact-result display contract. $100 of eligible cost with 1200% markup adds $1200 and totals $1300; a sell-price category does not receive cost markup.

Broader per-service arithmetic will be recorded before those executions. Component/fault-injection checks cannot establish authenticated application acceptance.
