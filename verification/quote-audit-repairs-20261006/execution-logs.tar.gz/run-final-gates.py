from pathlib import Path
import os, subprocess, json, re, sys

root = Path('/workspace/scratch/a52f6105f92a')
repo = root / 'repair-repo'
evidence = root / 'repair-evidence'
env = os.environ.copy()
env.update(PATH=str(root/'audit-tools/node_modules/node/bin')+os.pathsep+env['PATH'],
           TMPDIR=str(evidence/'tmp'), ALLOW_PROVIDER_WRITES='false',
           PLAYWRIGHT_BROWSERS_PATH=str(root/'audit-tools/browsers'),
           TEST_RESULTS_FILE='../repair-evidence/full-final.tap')
results = []
for name, command in [('npm-ci-final', ['npm','ci']),
                      ('build-final', ['npm','run','build']),
                      ('test-quote-final', ['npm','run','test:quote']),
                      ('test-full-final', ['npm','test'])]:
    with (evidence/(name+'.log')).open('w') as output:
        result = subprocess.run(command, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
    log = (evidence/(name+'.log')).read_text()
    counts = {key:int(value) for key,value in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', log, re.M)}
    results.append({'command':command,'exitCode':result.returncode,'counts':counts})
    (evidence/'final-gates.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
    if name=='npm-ci-final' and result.returncode==0:
        for package in ['playwright','playwright-core']:
            (repo/'node_modules'/package).symlink_to(root/'audit-tools/node_modules'/package, target_is_directory=True)
    if name in ['npm-ci-final','build-final'] and result.returncode!=0:
        sys.exit(result.returncode)
sys.exit(1 if any(row['exitCode'] for row in results) else 0)
