import './pricebookTestEnv.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {generateQuoteVNext,sanitizeForCustomerVNext} from '../server/quote-engine-vnext/engine.js';
import {customerContractForVNext,validateCustomerInputs,validatePricingStructuresDetailed} from '../server/quote-engine-vnext/contracts.js';
import {surfaceGeometry,coatLaborParts,surfaceOwnerDiagnostics} from '../server/quote-engine-vnext/surfacePricing.js';
import {exactToNumber} from '../server/quote-engine-vnext/exactMath.js';
import {fixture,siding} from '../verification/engine-independent/fixtures.mjs';
import {offeringFixture} from './configuredOfferingsFixtures.mjs';
import {voiceQuestionContract} from '../server/src/voice/voiceQuoteContract.js';
import {projectVoiceQuote} from '../server/src/voice/voiceQuotePresentation.js';
import {discloseQuoteScope} from '../server/src/quoteScopeDisclosure.js';

// Handwritten arithmetic and boundary expectations precede every execution.
// See verification/qe-lane-c-20261016/EXPECTED.md; no expectations are generated
// by the implementation under test.
function basic(){
 const f=fixture('INTERIOR_PAINTING',{laborPerWallSqftPerCoat:100,materialPerWallSqftPerCoat:30,minimumJob:0},{areaInputMethod:'wall_sqft',wallAreaSqft:400,wallHeight:'standard',wallScopeUniform:true,surfaceCondition:'good',coats:2,ceilingsIncluded:false,trimIncluded:false});
 f.ownerPricing.priceBasisByCategory.material='sell_price';return f;
}
function quote(f){const q=generateQuoteVNext(f);assert.equal(q.resultType,'INSTANT_ESTIMATE_READY',JSON.stringify(q));return q;}
const lines=q=>q.options[0].lineItems;
const amounts=(q,path)=>lines(q).filter(l=>l.calculation.ratePath===path).map(l=>l.amountCents);
const sum=values=>values.reduce((n,v)=>n+v,0);
const house={areaInputMethod:'building_dimensions',buildingPerimeterFeet:140,wallHeightFeet:10,gables:[{widthFeet:30,heightFeet:8},{widthFeet:30,heightFeet:8}],doorCount:2,windowCount:10,garageDoorCount:1,garageDoorWidthFeet:16,garageDoorHeightFeet:7};

for(const [coats,expected] of [[1,[44444]],[2,[44444,35556]],[3,[44444,71111]]])test('surface Oct16: exact wall coat split '+coats,()=>{
 // 400 × 100 × 2/1.8 = 44,444.444...; extra coat(s) 35,555.555... / 71,111.111...
 const f=basic();f.customerInputs.coats=coats;f.ownerPricing.pricing.paintingSettings={wallAdditionalCoatRatio:0.8};
 assert.deepEqual(amounts(quote(f),'laborPerWallSqftPerCoat'),expected);
});
for(const [coats,expected] of [[1,40000],[2,80000],[3,120000]])test('surface Oct16: blank ratio retains linear coats '+coats,()=>{
 const f=basic();f.customerInputs.coats=coats;assert.deepEqual(amounts(quote(f),'laborPerWallSqftPerCoat'),[expected]);
});
test('surface Oct16: converted rates retain exact fractional cents and approved independent rounding',()=>{
 const [first,additional]=coatLaborParts(1,2,0.8);
 assert.deepEqual(first.multipliers[0].exactValue,{numerator:'10',denominator:'9'});
 assert.deepEqual(additional.multipliers[0].exactValue,{numerator:'8',denominator:'9'});
 const f=basic();f.customerInputs.wallAreaSqft=1;f.ownerPricing.pricing.laborPerWallSqftPerCoat=0.25;
 assert.deepEqual(amounts(quote(f),'laborPerWallSqftPerCoat'),[1]);
 f.ownerPricing.pricing.paintingSettings={wallAdditionalCoatRatio:1};
 assert.deepEqual(amounts(quote(f),'laborPerWallSqftPerCoat'),[0,0]);
});
test('surface Oct16: poor wall preparation and good ceiling coats are independent',()=>{
 // Poor wall prep 1000×120=120000; ceiling labor 400×60×1=24000.
 const f=offeringFixture('INTERIOR_PAINTING','itemized'),p=f.ownerPricing.pricing;
 Object.assign(f.customerInputs,{wallAreaSqft:1000,coats:2,surfaceCondition:'poor',ceilingAreaSqft:400,ceilingCoats:1,ceilingSurfaceCondition:'good',trimIncluded:false});delete f.customerInputs.trimLengthLF;
 Object.assign(p.offeringRates,{prepLaborPerSqft_poor:120,prepMaterialPerSqft_poor:10,prepLaborPerSqft_good:20,prepMaterialPerSqft_good:5,ceilingLaborPerSqftPerCoat:60});
 const q=quote(f);assert.deepEqual(amounts(q,'offeringRates.prepLaborPerSqft_poor'),[120000]);assert.deepEqual(amounts(q,'offeringRates.prepLaborPerSqft_good'),[8000]);assert.deepEqual(amounts(q,'offeringRates.ceilingLaborPerSqftPerCoat'),[24000]);
});
test('surface Oct16: basic painting still sends fair and poor walls to review',()=>{
 for(const condition of ['fair','poor']){const f=basic();f.customerInputs.surfaceCondition=condition;assert.notEqual(generateQuoteVNext(f).resultType,'INSTANT_ESTIMATE_READY');}
});
test('surface Oct16: room dimensions separate labor from net paint without blocking a best guess',()=>{
 // 2×(12+12)×8=384; 384−20−2×15=334; ceiling=144; labor76800+paint22044.
 const f=basic();delete f.customerInputs.wallAreaSqft;delete f.customerInputs.wallScopeUniform;
 Object.assign(f.customerInputs,{areaInputMethod:'room_dimensions',rooms:[{lengthFeet:12,widthFeet:12,heightFeet:8,doorCount:1,windowCount:2}]});
 const g=surfaceGeometry(f.serviceType,f.customerInputs,f.ownerPricing.pricing);
 assert.deepEqual([g.labor,g.paint,g.ceiling].map(exactToNumber),[384,334,144]);
 const q=quote(f);assert.deepEqual(amounts(q,'laborPerWallSqftPerCoat'),[76800]);assert.deepEqual(amounts(q,'materialPerWallSqftPerCoat'),[22044]);assert.equal(q.options[0].midEstimate,988.44);
 const response=sanitizeForCustomerVNext(q),voice=projectVoiceQuote(response,'[SYNTHETIC]surface-quote',[],{callerMeasurementsEstimated:true});
 assert.ok(voice.voiceSummary.includes('This price is based on the measurements you gave us. The business will confirm them on site.'));
});
for(const [basis,area,cents] of [['openings_left_in',1584,332640],['openings_subtracted',1338,280980]])test('surface Oct16: siding '+basis+' convention and gables',()=>{
 const f=siding();f.customerInputs={...f.customerInputs,...house};delete f.customerInputs.sidingAreaSqft;
 Object.assign(f.ownerPricing.pricing,{laborPerSqft:{vinyl:100},materialPerSqft:{vinyl:100},sidingSettings:{areaConventionByType:{vinyl:basis}}});
 assert.equal(exactToNumber(surfaceGeometry(f.serviceType,f.customerInputs,f.ownerPricing.pricing).labor),area);
 assert.equal(quote(f).options[0].midEstimate,cents/100);
});
test('surface Oct16: exterior labor leaves ordinary openings in and paint subtracts all openings',()=>{
 // Gross1640; garage112 is >100, so labor1528; net material1338.
 const f=offeringFixture('EXTERIOR_PAINTING','itemized');f.customerInputs={...f.customerInputs,...house};delete f.customerInputs.exteriorAreaSqft;
 const g=surfaceGeometry(f.serviceType,f.customerInputs,f.ownerPricing.pricing);assert.deepEqual([g.gross,g.labor,g.paint].map(exactToNumber),[1640,1528,1338]);
 assert.equal(quote(f).resultType,'INSTANT_ESTIMATE_READY');
});
test('surface Oct16: priced door sides and fascia extend once; unpriced requested doors are excluded',()=>{
 const f=basic();f.customerInputs.paintDoorSides=4;f.ownerPricing.pricing.surfaceExtraRates={doorSides:11500};
 assert.deepEqual(amounts(quote(f),'surfaceExtraRates.doorSides'),[46000]);
 delete f.ownerPricing.pricing.surfaceExtraRates;
 const raw=quote(f),q=sanitizeForCustomerVNext(raw);assert.deepEqual(q.options[0].skippedAddons,['Door sides']);assert.equal(q.options[0].midEstimate,1064);
 const contract=customerContractForVNext(f.serviceType,f.ownerPricing.pricing),definition={customerFields:Object.entries(contract.fields).map(([name,d])=>({name,...d}))};
 const presented=discloseQuoteScope(q,f.ownerPricing,definition,{customerInputs:f.customerInputs},1);
 assert.equal(presented.resultType,'PARTIAL_ESTIMATE_READY');assert.equal(presented.fullJobTotal,null);assert.equal(presented.additionalWork[0].description,'Door sides');
 const e=offeringFixture('EXTERIOR_PAINTING','itemized');e.customerInputs.fasciaLengthLF=140;e.ownerPricing.pricing.surfaceExtraRates={fascia:800};assert.deepEqual(amounts(quote(e),'surfaceExtraRates.fascia'),[112000]);
});
test('surface Oct16: owner height bands price each room and ceiling, never height-adjusting trim',()=>{
 // Walls32000+44000=76000; ceilings6000+6600=12600. Trim100LF×200=20000.
 const f=basic(),p=f.ownerPricing.pricing;
 Object.assign(p,{ceilingLaborPerSqftPerCoat:60,ceilingMaterialPerSqftPerCoat:20,trimLaborPerLF:200,trimMaterialPerLF:20,paintingSettings:{heightBands:{standardMaxFeet:8,highMaxFeet:10,vaultedMaxFeet:20}}});
 delete f.customerInputs.wallAreaSqft;delete f.customerInputs.wallHeight;delete f.customerInputs.wallScopeUniform;
 Object.assign(f.customerInputs,{areaInputMethod:'room_dimensions',coats:1,ceilingsIncluded:true,ceilingCoats:1,ceilingSurfaceCondition:'good',trimIncluded:true,trimLengthLF:100,trimCoats:1,trimSurfaceCondition:'good',rooms:[8,10].map(heightFeet=>({lengthFeet:10,widthFeet:10,heightFeet,doorCount:0,windowCount:0}))});
 const q=quote(f);assert.equal(sum(amounts(q,'laborPerWallSqftPerCoat')),76000);assert.equal(sum(amounts(q,'ceilingLaborPerSqftPerCoat')),12600);assert.equal(sum(amounts(q,'trimLaborPerLF')),20000);
});
test('surface Oct16: legacy no-new-input prices keep baseline cents',()=>{
 // Handwritten old controls: 106400,252400,179400,1170000 cents respectively.
 for(const [f,cents] of [[basic(),106400],[offeringFixture('INTERIOR_PAINTING','itemized'),252400],[offeringFixture('EXTERIOR_PAINTING','itemized'),179400],[siding(),1170000]])assert.equal(quote(f).options[0].midEstimate,cents/100);
});
test('surface Oct16: missing siding convention names owner pricing rather than guessing a basis',()=>{
 const f=siding();f.customerInputs={...f.customerInputs,...house};delete f.customerInputs.sidingAreaSqft;
 const q=generateQuoteVNext(f);assert.notEqual(q.resultType,'INSTANT_ESTIMATE_READY');assert.ok(JSON.stringify(q).includes('sidingSettings.areaConventionByType.vinyl'));
});
test('surface Oct16: malformed new fields and inconsistent measurements cannot quote',()=>{
 for(const bad of [-1,NaN,Infinity]){const f=basic();f.customerInputs.paintDoorSides=bad;assert.notEqual(generateQuoteVNext(f).resultType,'INSTANT_ESTIMATE_READY');}
 for(const bad of [-1,NaN,Infinity,'0.8']){const f=basic();f.ownerPricing.pricing.paintingSettings={wallAdditionalCoatRatio:bad};assert.notEqual(generateQuoteVNext(f).resultType,'INSTANT_ESTIMATE_READY');}
 const f=basic();Object.assign(f.customerInputs,{areaInputMethod:'room_dimensions',rooms:[{lengthFeet:12,widthFeet:12,heightFeet:8,doorCount:1,windowCount:2}]});
 assert.equal(validateCustomerInputs(f.serviceType,f.customerInputs,f.ownerPricing.pricing).ok,false,'duplicate direct area must not silently win');
 const p={paintingSettings:{heightBands:{standardMaxFeet:10,highMaxFeet:8,vaultedMaxFeet:20}}};assert.ok(surfaceOwnerDiagnostics('INTERIOR_PAINTING',p).length);assert.ok(validatePricingStructuresDetailed('INTERIOR_PAINTING',p).some(d=>d.path==='paintingSettings.heightBands'));
});
test('surface Oct16: widget and voice expose the same room and per-surface names without private rates',()=>{
 const f=basic(),contract=customerContractForVNext(f.serviceType,f.ownerPricing.pricing);
 const definition={customerFields:Object.entries(contract.fields).map(([name,d])=>({name,...d}))};
 const voice=voiceQuestionContract(f.ownerPricing,definition);
 for(const name of ['rooms','ceilingCoats','ceilingSurfaceCondition','trimCoats','trimSurfaceCondition','paintDoorSides'])assert.ok(voice.fields.some(q=>q.field===name));
 assert.match(voice.fields.find(q=>q.field==='rooms').details.join(' '),/lengthFeet.*widthFeet.*heightFeet/);
 assert.equal(JSON.stringify(voice).includes('wallAdditionalCoatRatio'),false);assert.equal(JSON.stringify(voice).includes('laborPerWallSqftPerCoat'),false);
});
