import {scopeBaseKey,scopeEntriesFor,scopeMatchesRequest,basicInteriorPainting,BASIC_PAINT_PREPARATION_NOTICE} from '../scopeConfiguration.js';
import crypto from 'node:crypto';
import {resolvedQuoteTimeZone,quoteDefaultsForTimeZone,peakSurchargeConfigured,MISSING_PEAK_TIME_ZONE} from '../src/quoteDate.js';
import {installedPriceDefinitions,installedLaborFactorPath} from '../installedPriceConfiguration.js';
import {scopeActivationInputs,scopeDefinitions,scopeKeysForRequest,scopeRateDefinitions,scopeStructureDiagnostics,scopeCustomerErrors} from './scopePricing.js';
import {OFFERING_TYPES, configuredOffering, offeringContract, offeringActivationScenarios, offeringRateDefinitions, offeringGateDefinitions} from './configuredOfferings.js';
import {exactCompare} from './exactMath.js';
import {fenceType,fenceCatalog,fenceOfferingEntries,fenceCatalogVariants} from './fencePricing.js';
import {boundaryMeasurements,repairBoundaryMeasurements} from './activationBoundaries.js';
import {
  CLASS2_DEFINITIONS,
  createActivationValidationVNext,
  valueAtPath,
  ownerRequirements,
  SERVICE_TYPES,
  aiConfirmationFieldsVNext,
  hasCurrentApprovalVNext,
  freeOfferingVNext,
  validServiceIdVNext,
  canonicalServiceIdentityVNext,
  inspectionOwnerDecisionsVNext,
  allowedPricingFields,
  contractMetadata,
  validateClass2FactorsDetailed,
  validateBusinessDefaults,
  validateCustomerInputs,
  validateOwnerPricing,
  validatePricingStructuresDetailed,
  pricingDiagnosticsForSelection,
  validateServiceRules,
  validateServiceRulesDetailed,
  vinylUnderlaymentApplies
} from './contracts.js';
import {
  generateQuoteVNext,
  createActivationQuoteCheckVNext,
  installedMaterialShareDiagnosticsVNext,
  validateFeeSelectionRequest,
  ENGINE_VERSION,
  mergePricingForValidationVNext,
  sanitizeForCustomerVNext,
  validateTierDefinitionsVNext,
  validateTierDefinitionsDetailedVNext
} from './engine.js';
import { QuoteReviewError, calculateServiceVNext } from './templates.js';
import { denseArrayIssue, ownDataValue, snapshotPlainData } from './safeData.js';
import { ownerFieldCopy } from '../priceBookCopy.js';

const AI_SOURCES = new Set(['AI_SUGGESTED', 'AI_INTERVIEW']);
const PRICEBOOK_QUOTE_REQUEST_FIELDS = new Set([
  'pricebook', 'serviceType', 'customerInputs', 'callerType',
  'feeSelections', 'currentMonth', 'allowInactiveOwnerPreview'
]);

function isPlainRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  try {
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  } catch {
    return false;
  }
}

const SERVICE_NAMES = {
  ROOFING_REPLACEMENT: 'Roof replacement',
  ROOFING_REPAIR: 'Roof repair',
  FLAT_ROOF_REPLACEMENT: 'Flat roof replacement',
  FLAT_ROOF_REPAIR: 'Flat roof repair',
  INTERIOR_PAINTING: 'Interior painting',
  EXTERIOR_PAINTING: 'Exterior painting',
  FLOORING_INSTALL: 'Flooring installation',
  FLOORING_REPLACEMENT: 'Flooring replacement',
  FENCING_INSTALL: 'Fencing installation',
  FENCING_REPLACEMENT: 'Fencing replacement',
  SIDING_REPLACEMENT: 'Siding replacement',
  SIDING_REPAIR: 'Siding repair',
  CONCRETE_DRIVEWAY: 'Concrete driveway',
  CONCRETE_PATIO_SLAB: 'Concrete patio slab',
  LANDSCAPING_CLEANUP: 'Landscaping cleanup',
  LANDSCAPING_MULCH: 'Mulch installation',
  LANDSCAPING_SOD: 'Sod installation',
  LANDSCAPING_PLANTING: 'Planting',
  LANDSCAPING_MOWING: 'Mowing',
  CUSTOM: 'Custom service'
};

const NEW_FIELD_COPY = {
  offeringMode:{label:'Offering pricing',help:'Choose complete installed pricing or itemized measured components for this owner offering.'},
  offeringDetails:{label:'What this offering includes',help:'Define the covered fence or painting scope, with explicit inclusions and separately offered extras.'},
  offeringRates:{label:'Prices for this offering',help:'Owner-entered unit prices. Installed packages and gates are final selling prices. Itemized paint materials use measured-area selling prices.'},
  baggingSurchargePercent: {label:'Clipping bagging and disposal surcharge (%)',help:'Optional extra. Missing pricing keeps the main quote and explicitly excludes clipping bagging and disposal from that option. An explicit zero percentage means this optional scope is free; a positive percentage applies to mowing labor once and replaces common disposal.'},
  edgingPerLinearFoot: {label:'Landscape edging labor price per measured linear foot',help:'Mowing edging is an optional extra: missing pricing keeps the main quote and explicitly excludes lawn edging from that option. Mulch edging remains required scope. An explicit zero rate means the extra is free; a positive rate uses the confirmed edging length.'},
  pondingWaterSurcharge: {label:'Selected ponding-water treatment fixed price',help:'Optional extra. Missing pricing keeps the main quote and explicitly excludes ponding-water treatment from that option. An explicit zero price means this optional scope is free; a positive fixed price is charged once.'},

  disposalScope: {label:'Separate sod-project debris disposal',help:'Only separate_project_debris is supported. Customer separateDisposalSelected must be explicitly true or false. Old-lawn disposal stays included in ground preparation.'},
  knownOfferings: {label:'Explicitly known price-selecting offerings',help:'Register stable offering UUIDs separately from pricing. Matching price-map keys do not establish customer facts.'},
  zeroPricePolicy: {label:'Explicit free offerings and included required prices',help:'Audited service and owner approval is required. Zero core rates without this classification are incomplete; zero minima mean no minimum.'},
  origin: {label:'Immutable service creation receipt',help:'Protected persisted serviceId, serviceType, source, ownerId, operationId, and createdAt; ordinary edits cannot change origin.'},
  materialCostPerSquare: {label:'Roof base material price per square for the selected accessory method',help:'In per_square_allin mode the base includes starter, drip edge, ridge cap, flashing, and vents. In itemized mode the base must EXCLUDE separately priced starter, drip edge, and ridge cap; explicit materialAccessoryBasis confirmation is required before activation.'},
  materialAccessoryBasis: {label:'Base material excludes itemized roof accessories',help:'Confirm excludes_itemized_accessories only after checking the current base rate excludes the separately priced starter, drip edge, and ridge cap. Legacy all-in rates must be re-entered or explicitly reviewed.'},
  mowingBaseRatePerSqft: {label:'Mowing labor cents per measured square foot (fractional cents supported)',help:'Enter cents, including fractional cents: 0.5 cents per square foot is $50 per 10,000 square feet before confirmed frequency and grass-condition adjustments. Existing whole-cent rates retain their units.'},
  laborPerWallSqftPerCoat: { label: 'Wall painting labor price per measured wall square foot, per coat', help: 'Labor price multiplied by measured paintable wall area and the confirmed number of finish coats.' },
  materialPerWallSqftPerCoat: { label: 'Wall paint material price per measured wall square foot, per coat', help: 'Paint and material price multiplied by measured paintable wall area and the confirmed number of finish coats.' },
  ceilingLaborPerSqftPerCoat: { label: 'Ceiling painting labor price per measured ceiling square foot, per coat', help: 'Labor price used only when ceilings are included, multiplied by measured ceiling area and confirmed coats.' },
  ceilingMaterialPerSqftPerCoat: { label: 'Ceiling paint material price per measured ceiling square foot, per coat', help: 'Paint and material price used only when ceilings are included, multiplied by measured ceiling area and confirmed coats.' },
  exteriorLaborPerSqftPerCoat: { label: 'Exterior painting labor price per measured wall square foot, per applied coat', help: 'Labor price multiplied by measured paintable exterior wall area, confirmed finish coats, and the configured story factor. Poor surfaces remain review-only until primer pricing is approved.' },
  starterPerLF: { label: 'Starter strip material price per measured linear foot', help: 'Used only with itemized roof accessories and multiplied by the confirmed starter-strip length.' },
  dripEdgePerLF: { label: 'Drip edge material price per measured linear foot', help: 'Used only with itemized roof accessories and multiplied by the confirmed drip-edge length.' },
  ridgeCapPerLF: { label: 'Ridge cap material price per measured linear foot', help: 'Used only with itemized roof accessories and multiplied by the confirmed ridge-cap length.' },
  postPrice: { label: 'Fence post material price per derived planned post', help: 'Held for review until post quantity can be derived from measured geometry and approved spacing, end, corner, and gate-post rules.' },
  underlaymentPerSquare: { label: 'Installed-area underlayment sell price per roofing square', help: 'Used only when this underlayment rate is owner-classified as a final installed-area sell price. A cost-based underlayment rate requires product coverage and purchasable-quantity facts and is held for review.' },
  underlaymentPerSqft: { label: 'Installed-area underlayment sell price per square foot', help: 'Used only when this underlayment rate is owner-classified as a final installed-area sell price. A cost-based underlayment rate requires product coverage and purchasable-quantity facts and is held for review.' },
  underlaymentPriceBasis: { label: 'Underlayment price basis', help: 'Classifies only the underlayment field. Installed-area sell prices use measured installed area; cost prices remain review-only until package coverage and purchasable quantities are configured.' },
  concretePerPost: { label: 'Concrete + digging cost per post at your local frost/set depth.', help: 'This mixed charge cannot be quoted until separate labor and material prices or an explicit owner-confirmed allocation rule is approved.' },
  gatePrice: { label: "Installed price per gate INCLUDING gate posts' hardware; gate posts themselves are counted below.", help: 'Selected gates remain review-only until the owner approves a measured-width pricing model and rates; the existing per-gate value is not reinterpreted.' },
  trimPerLinearFoot: { label: 'Siding trim installation price per measured linear foot', help: 'Held for owner review until labor and material are separately priced or an explicit category and allocation rule is approved.' },
  subfloorAllowancePerSqft: { label: 'Subfloor repair allowance per measured affected square foot', help: 'Applied only when subfloor issues are reported and only to the measured affected area.' },
  deckingPerSheet: { label: 'Decking replacement price per confirmed sheet', help: 'Applied to confirmed replacement sheets. Only confirmed sell-price units may be disclosed; raw cost units are never customer prices.' },
  roomSizeThresholds: { label: 'Flooring average-room size thresholds', help: 'Average room area at or below the small maximum uses the small-room labor factor; above it and at or below the medium maximum uses medium. Above the medium maximum uses large. Defaults: up to and including 150, over 150 through 300, and over 300 square feet.' },

  vinylPlankUnderlaymentRule: { label: 'Vinyl-plank underlayment rule', help: 'Choose always included, never included, subfloor-condition based, customer-selectable, or owner review.' },
  customPricingMode: { label: 'Custom service pricing structure', help: 'Choose a fixed unit price, a configured unit-price range, or inspection-first pricing.' },
  customChargeClassification: { label: 'Custom service charge category', help: 'Choose the line category for this complete service charge. Its saved price basis, taxability, markup and seasonal settings apply. A final selling price is not marked up again. No labor/material split is inferred.' },
  price: { label: 'Fixed customer price per configured unit', help: 'Final configured amount before any explicitly selected cost-basis markup.' },
  priceBasisByCategory: { label: 'Rate meaning by line category', help: 'State whether each category contains owner cost or final sell price so the engine cannot mark up a sell price twice.' },
  taxabilityByCategory: { label: 'Taxability by line category', help: 'Set the tax treatment for every line category used by this service.' },
  feeRules: { label: 'Common-fee applicability', help: 'Choose when travel, disposal, permit, and overhead charges apply to this service.' }
};

function pricingOf(service) {
  return isPlainRecord(service?.pricing)
    ? service.pricing
    : {};
}

function cloneForStatus(value, fallback = {}) {
  try {
    return structuredClone(value);
  } catch {
    return structuredClone(fallback);
  }
}


function keysOf(value, fallback) {
  return isPlainRecord(value) && Object.keys(value).length
    ? Object.keys(value)
    : [fallback];
}

function greatestConfiguredKey(value, supportedKeys, fallback) {
  if (!isPlainRecord(value)) return fallback;
  const candidates = supportedKeys.filter(key => Object.hasOwn(value, key) && typeof value[key] === 'number' && Number.isFinite(value[key]));
  if (!candidates.length) return fallback;
  return candidates.reduce((greatest, key) => value[key] > value[greatest] ? key : greatest);
}

function flooringRoomBands(pricing) {
  const thresholds = pricing.roomSizeThresholds;
  if (!isPlainRecord(thresholds) ||
      typeof thresholds.smallMaxSqft !== 'number' || !Number.isFinite(thresholds.smallMaxSqft) ||
      typeof thresholds.mediumMaxSqft !== 'number' || !Number.isFinite(thresholds.mediumMaxSqft) ||
      thresholds.smallMaxSqft <= 0 || thresholds.mediumMaxSqft <= thresholds.smallMaxSqft) {
    return [{ sqft: 1_000_000, roomCount: 1 }];
  }
  const scenarioForAverage = average => {
    const roomCount = Math.max(1, Math.min(10_000, Math.floor(1_000_000 / average)));
    return { sqft: average * roomCount, roomCount };
  };
  return [
    scenarioForAverage(thresholds.smallMaxSqft / 2),
    scenarioForAverage((thresholds.smallMaxSqft + thresholds.mediumMaxSqft) / 2),
    ...[thresholds.smallMaxSqft,thresholds.mediumMaxSqft].flatMap(boundaryMeasurements).filter(average=>average>0).map(average=>average<1?{sqft:average*2,roomCount:2}:{sqft:average,roomCount:1}),
    { sqft: 1_000_000, roomCount: 1 }
  ];
}

function repairScenarios(serviceType, cube, fallbacks, makeScenario, largeLimit) {
  const affectedAreas = serviceType === 'ROOFING_REPAIR'
    ? { small: 25, medium: 100, large: 250 }
    : { small: 10, medium: 50, large: 100 };
  if (typeof largeLimit === 'number' && Number.isFinite(largeLimit) && largeLimit < affectedAreas.large) affectedAreas.large = largeLimit;
  const out = [];
  for (const first of keysOf(cube, fallbacks[0])) {
    for (const second of keysOf(cube?.[first], fallbacks[1])) {
      const areas=[...new Set([...Object.values(affectedAreas),...repairBoundaryMeasurements(serviceType,largeLimit).filter(area=>typeof largeLimit!=='number'||area<=largeLimit)])];
      for (const area of areas) out.push(makeScenario(first, second, area));
    }
  }
  return out;
}

// Optional work is checked only when its complete pricing is configured.
// Missing optional work stays visible as lead-only coverage. Every actual
// request still goes through validateOwnerPricing and the unchanged calculator.
function optionalPricingRequests(service, base) {
  const type=service.serviceType,p=pricingOf(service);
  if(configuredOffering(type,p)){
    const d=p.offeringDetails||{},fields=offeringContract(type,p,service).fields;
    if(type==='INTERIOR_PAINTING')return [
      ...(d.ceilingsOffered?[{key:'ceiling_prices',label:fields.ceilingsIncluded.label,changes:{ceilingsIncluded:true,ceilingAreaSqft:100}}]:[]),
      ...(d.trimOffered?[{key:'trim_prices',label:fields.trimIncluded.label,changes:{trimIncluded:true,trimLengthLF:100}}]:[])
    ];
    if(type.startsWith('FENCING_')){
      const rates=offeringRateDefinitions(type,p);
      return [
        ...Object.keys(d.gates||{}).map(key=>({key:'gate_prices_'+key,label:rates['gate_'+key]?.label||fields.gates.label,changes:{gates:{[key]:1}}})),
        ...(type==='FENCING_REPLACEMENT'&&d.removalOffered?[{key:'removal_prices',label:rates.removalPerLF.label,changes:{oldFenceRemoval:true,removalLengthLF:50}}]:[])
      ];
    }
    return [];
  }
  if(type==='INTERIOR_PAINTING')return [
    {key:'ceiling_prices',label:'Ceiling painting',changes:{ceilingsIncluded:true,ceilingAreaSqft:1_000_000,ceilingCoats:3}},
    {key:'trim_prices',label:'Trim painting',changes:{trimIncluded:true,trimLengthLF:1_000_000}}
  ];
  if(type.startsWith('FLOORING_'))return [
    ...Object.keys(p.removalPerSqft||{}).map(existingFloorType=>({key:'floor_removal_'+existingFloorType,label:'Floor removal: '+existingFloorType.replaceAll('_',' '),changes:{existingFloorType,removalNeeded:true,removalAreaSqft:base?.sqft}})),
    ...(Object.hasOwn(p.laborPerSqft||{},'vinyl_plank')&&['customer_selectable_addon','subfloor_condition'].includes(p.vinylPlankUnderlaymentRule)?[{key:'vinyl_underlayment_prices',label:'Installed vinyl-plank underlayment',changes:{newFlooringType:'vinyl_plank',...(p.vinylPlankUnderlaymentRule==='customer_selectable_addon'?{underlaymentSelected:true}:{subfloorCondition:'requires_underlayment'})}}]:[]),
    ...(type==='FLOORING_REPLACEMENT'&&p.subfloorAllowancePerSqft!==undefined?[{key:'subfloor_repair_prices',label:'Subfloor repair allowance',changes:{subfloorIssues:true,subfloorRepairAreaSqft:base?.sqft}}]:[])
  ];
  if(type.startsWith('CONCRETE_'))return [
    {key:'base_prices',label:'Concrete base preparation',changes:{baseNeeded:true}},
    {key:'wire_prices',label:'Wire mesh reinforcement',changes:{reinforcement:'wire_mesh'}},
    {key:'rebar_prices',label:'Rebar reinforcement',changes:{reinforcement:'rebar'}},
    {key:'stamped_prices',label:'Stamped concrete finish',changes:{finishType:'stamped'}}
  ];
  if(type==='LANDSCAPING_CLEANUP')return [{key:'haul_prices',label:'Additional cleanup haul-away',changes:{haulAway:true}}];
  if(type==='LANDSCAPING_SOD')return [{key:'ground_prep_prices',label:'Sod ground preparation',changes:{groundPrepNeeded:true}}];
  if(type==='LANDSCAPING_PLANTING')return [
    ...['needs_weeding','overgrown'].map(condition=>({key:'planting_bed_'+condition,label:condition==='needs_weeding'?'Planting bed weeding':'Overgrown planting bed preparation',changes:{bedCondition:condition,bedSqft:10_000_000}})),
    ...keysOf(pricingOf(service).mulchMaterialPerYard,'standard').map(mulchType=>({key:'planting_mulch_'+mulchType,label:'Planting with '+mulchType.replaceAll('_',' ')+' mulch',changes:{mulchNeeded:true,mulchType,mulchYards:100_000}}))
  ];
  if(type==='LANDSCAPING_MULCH')return [
    {key:'edging_prices',label:'Mulch bed edging',changes:{edgingNeeded:true,edgeLF:1_000_000}},
    ...['needs_weeding','overgrown'].map(condition=>({key:'bed_'+condition,label:condition==='needs_weeding'?'Mulch bed weeding':'Overgrown mulch bed preparation',changes:{bedCondition:condition,bedSqft:10_000_000}}))
  ];
  return [];
}
function selectedShareDiagnostics(service, inputs, pricing, defaults) {
  return installedMaterialShareDiagnosticsVNext(service.serviceType,pricing,defaults,ownerRequirements(service.serviceType,inputs,pricing,service).map(item=>item.path));
}
function completeOptionalPricing(service, inputs, pricing=pricingOf(service),tierName=null,defaults=null) {
  const normalized=scopeActivationInputs(service.serviceType,inputs,pricing,service);
  return validateOwnerPricing(service.serviceType,normalized,pricing,service,tierName).ok&&!scopeCustomerErrors(service.serviceType,normalized,pricing,service).length&&!selectedShareDiagnostics(service,normalized,pricing,defaults).length;
}

function baseActivationScenarios(service,confirmedService=service,selection=null) {
  const serviceType = service.serviceType;
  const p = pricingOf(service);
  if(configuredOffering(serviceType,p))return offeringActivationScenarios(serviceType,p,confirmedService);
  if (serviceType === 'ROOFING_REPLACEMENT') {
    const replacements = selection ? [selection.replacementRoofType] : keysOf(p.laborPerSquare, 'asphalt_shingle');
    const existingTypes = selection ? [selection.existingRoofType] : keysOf(p.tearOffPerSquare, 'asphalt_shingle');
    const pitch = greatestConfiguredKey(p.pitchMultiplier, ['low', 'medium', 'steep', 'very_steep'], 'medium');
    const stories = greatestConfiguredKey(p.storyMultiplier, [1, 2, 3], 2);
    const roofComplexity = greatestConfiguredKey(p.wasteFactorByComplexity, ['simple', 'moderate', 'complex'], 'moderate');
    return replacements.flatMap(replacement => existingTypes.map(existing => ({
      roofSizeMethod: 'roof_measured', roofSizeInput: 1_000_000,
      existingRoofType: existing, replacementRoofType: replacement,
      pitch, stories, existingLayers: 10,
      roofComplexity, serviceScope: 'full',
      ...(p.accessoryPricingMode === 'itemized'
        ? { starterLengthLF: 1_000_000, dripEdgeLengthLF: 1_000_000, ridgeCapLengthLF: 1_000_000 }
        : {}),
      ...(p.deckingPerSheet !== undefined ? { deckingSheets: 100_000 } : {})
    })));
  }
  if (serviceType === 'ROOFING_REPAIR') {
    const pitch = greatestConfiguredKey(p.pitchMultiplier, ['low', 'medium', 'steep', 'very_steep'], 'medium');
    const stories = greatestConfiguredKey(p.storyMultiplier, [1, 2, 3], 2);
    return repairScenarios(serviceType, p.repairHours, ['asphalt_shingle', 'patch'], (roofType, repairType, affectedArea) => ({ repairType, affectedArea, roofType, pitch, stories, leakPresent: false }), p.largeRepairMaxSqft);
  }
  if (serviceType === 'FLAT_ROOF_REPLACEMENT') {
    const configured = keysOf(p.laborPerSqft, 'epdm').filter(key => key !== 'average');
    const membraneTypes = selection ? [selection.replacementMembraneType] : configured.length ? configured : ['epdm'];
    const accessDifficulty = greatestConfiguredKey(p.accessMultiplier, ['easy', 'moderate', 'difficult'], 'moderate');
    const configuredExistingTypes = keysOf(p.tearOffPerSqft,'epdm').filter(key=>key!=='average');
    const existingTypes = selection ? [selection.membraneType] : configuredExistingTypes.length ? configuredExistingTypes : membraneTypes;
    const scenarios = membraneTypes.flatMap(replacementMembraneType=>existingTypes.map(membraneType=>({roofSqft:2_000_000,sqftMethod:'exact',membraneType,replacementMembraneType,existingLayers:10,accessDifficulty,serviceScope:'full',buildingType:'residential',insulationNeeded:false,coverboardNeeded:false})));

    return scenarios;
  }
  if (serviceType === 'FLAT_ROOF_REPAIR') {
    const base = repairScenarios(serviceType, p.patchRepairHours, ['epdm', 'patch'], (membraneType, repairType, affectedArea) => ({ repairType, affectedArea, membraneType, leakPresent: false, pondingWater: false, accessDifficulty: greatestConfiguredKey(p.accessMultiplier,['easy','moderate','difficult'],'difficult') }), p.largeRepairMaxSqft);
    // Probe optional treatment when configured; real selected requests always
    // require its price. An unpriced extra does not disable complete base repairs.
    return [undefined, null, ''].includes(p.pondingWaterSurcharge) ? base : base.flatMap(inputs => [
      inputs,
      { ...inputs, pondingWater: true }
    ]);
  }
  if (serviceType === 'INTERIOR_PAINTING') {
    const wallHeight = greatestConfiguredKey(p.wallHeightLaborMultiplier, ['standard', 'high', 'vaulted'], 'high');
    const base={areaInputMethod:'wall_sqft',wallAreaSqft:2_000_000,wallHeight,wallScopeUniform:true,surfaceCondition:'good',coats:3,ceilingsIncluded:false,trimIncluded:false};
    const extras=optionalPricingRequests(service,base).filter(row=>completeOptionalPricing(service,{...base,...row.changes}));
    return [base,...extras.map(row=>({...base,...row.changes})),...(extras.length>1?[Object.assign({},base,...extras.map(row=>row.changes))]:[])];
  }
  if (serviceType === 'EXTERIOR_PAINTING') {
    const stories = greatestConfiguredKey(p.storyMultiplier, [1, 2, 3], 2);
    return [{ areaInputMethod: 'wall_sqft', exteriorAreaSqft: 2_000_000, stories, surfaceCondition: 'fair', coats: 3 }];
  }
  if (serviceType === 'FLOORING_INSTALL' || serviceType === 'FLOORING_REPLACEMENT') {
    const flooringTypes = keysOf(p.laborPerSqft, 'tile');
    const replacement = serviceType === 'FLOORING_REPLACEMENT';
    const layoutPattern = greatestConfiguredKey(p.patternWasteAdder, ['straight', 'diagonal_or_pattern'], 'diagonal_or_pattern');
    const roomBands = flooringRoomBands(p);
    const scenario = (flooringType, existingFloorType, removalNeeded, roomBand) => ({
      sqft: roomBand.sqft, sqftMethod: 'exact', newFlooringType: flooringType,
      existingFloorType, removalNeeded, ...(removalNeeded?{removalAreaSqft:roomBand.sqft}:{}),
      roomCount: roomBand.roomCount, layoutPattern, stairSteps: 0,
      ...(flooringType === 'vinyl_plank' && p.vinylPlankUnderlaymentRule === 'customer_selectable_addon' ? { underlaymentSelected: false } : {}),
      ...(flooringType === 'vinyl_plank' && p.vinylPlankUnderlaymentRule === 'subfloor_condition' ? { subfloorCondition: 'does_not_require_underlayment' } : {}),
      ...(replacement ? { subfloorIssues: false } : {})
    });
    return flooringTypes.flatMap(flooringType => roomBands.flatMap(roomBand => [
      scenario(flooringType, 'none', false, roomBand)
    ]));
  }
  if (serviceType === 'FENCING_INSTALL' || serviceType === 'FENCING_REPLACEMENT') {
    const fenceTypes = keysOf(p.laborPerLinearFoot, 'wood');
    return fenceTypes.map(fenceType => ({ linearFeet: 120, lfMethod: 'exact', fenceType, fenceHeight: 6, gateCount: 0, terrainSlope: 'moderate', ...(serviceType === 'FENCING_REPLACEMENT' ? { oldFenceRemoval: p.removalPerLinearFoot !== undefined } : {}) }));
  }
  if (serviceType === 'CONCRETE_DRIVEWAY' || serviceType === 'CONCRETE_PATIO_SLAB') {
    const accessDifficulty = greatestConfiguredKey(p.accessMultiplier, ['easy', 'moderate', 'difficult'], 'moderate');
    const dimensions = [
      { dimensionMethod: 'exact', length: 10_000, width: 1_000 },
      // Measured synthetic comb: base 200000*20 plus four fingers totals
      // exactly 10,000,000 sqft; base perimeter plus twice finger heights is 1,000,000 LF.
      { dimensionMethod:'measured_outline', outlinePoints:[
        {x:-100000,y:-20},{x:100000,y:-20},{x:100000,y:0},
        {x:4020,y:0},{x:4020,y:74995},{x:4000,y:74995},{x:4000,y:0},
        {x:3020,y:0},{x:3020,y:74995},{x:3000,y:74995},{x:3000,y:0},
        {x:2019,y:0},{x:2019,y:74795},{x:2000,y:74795},{x:2000,y:0},
        {x:1021,y:0},{x:1021,y:75195},{x:1000,y:75195},{x:1000,y:0},
        {x:-100000,y:0},{x:-100000,y:-20}
      ] }
    ];
    return dimensions.flatMap(dimension => {
      const base={...dimension,thickness:24,finishType:'broom',demolitionNeeded:false,reinforcement:'none',accessDifficulty,baseNeeded:false,adjoinsExistingConcrete:false};
      const candidates=['broom','smooth','stamped'].flatMap(finishType=>['none','wire_mesh','rebar'].flatMap(reinforcement=>[false,true].map(baseNeeded=>({...base,finishType,reinforcement,baseNeeded}))));
      return [base,...candidates.filter(input=>completeOptionalPricing(service,input))];
    });
  }
  if (serviceType === 'LANDSCAPING_CLEANUP') {
    const slope = greatestConfiguredKey(p.slopeMultiplier, ['flat', 'moderate', 'steep'], 'moderate');
    return ['light','moderate','heavy'].flatMap(debrisLevel=>{
      const base={yardSqft:10_000_000,sqftMethod:'exact',debrisLevel,slope,haulAway:false},extra={...base,haulAway:true};
      return [base,...(completeOptionalPricing(service,extra)?[extra]:[])];
    });
  }
  if (serviceType === 'LANDSCAPING_MULCH') return keysOf(p.mulchMaterialPerYard,'standard').flatMap(mulchType=>['sqft','yards'].flatMap(inputMethod=>{
    const base={accessDifficulty:greatestConfiguredKey(p.accessMultiplier,['easy','moderate','difficult'],'difficult'),inputMethod,mulchArea:10_000_000,...(inputMethod==='sqft'?{mulchDepth:24}:{}),mulchType,bedCondition:'clean',edgingNeeded:false};
    const candidates=['clean','needs_weeding','overgrown'].flatMap(bedCondition=>[false,true].map(edgingNeeded=>({...base,bedCondition,...(bedCondition!=='clean'?{bedSqft:10_000_000}:{}),edgingNeeded,...(edgingNeeded?{edgeLF:1_000_000}:{})})));
    return [base,...candidates.filter(input=>completeOptionalPricing(service,input))];
  }));
  if (serviceType === 'LANDSCAPING_SOD') {
    const slope = greatestConfiguredKey(p.slopeMultiplier, ['flat', 'moderate', 'steep'], 'moderate');
    const accessDifficulty = greatestConfiguredKey(p.accessMultiplier, ['easy', 'moderate', 'difficult'], 'moderate');
    const base={sodSqft:10_000_000,sqftMethod:'exact',groundPrepNeeded:false,slope,accessDifficulty},extra={...base,groundPrepNeeded:true};
    const scenarios=[base,...(completeOptionalPricing(service,extra)?[extra]:[])];
    return scenarios.flatMap(scenario=>service.disposalScope==='separate_project_debris'?[false,true].map(separateDisposalSelected=>({...scenario,separateDisposalSelected})):[scenario]);
  }
  if (serviceType === 'LANDSCAPING_PLANTING') {
    const base={accessDifficulty:greatestConfiguredKey(p.accessMultiplier,['easy','moderate','difficult'],'difficult'),plantsBySize:{small:1_000_000,medium:1_000_000,large:1_000_000},bedCondition:'clean',mulchNeeded:false};
    const mulch=[{},...keysOf(p.mulchMaterialPerYard,'standard').map(mulchType=>({mulchNeeded:true,mulchYards:100_000,mulchType}))];
    const candidates=['clean','needs_weeding','overgrown'].flatMap(bedCondition=>mulch.map(extra=>({...base,bedCondition,...(bedCondition!=='clean'?{bedSqft:10_000_000}:{}),...extra})));
    return [base,...candidates.filter(input=>completeOptionalPricing(service,input))];
  }
  if (serviceType === 'LANDSCAPING_MOWING') {
    const serviceFrequency = greatestConfiguredKey(p.frequencyMultipliers, ['weekly', 'biweekly', 'monthly', 'one_time'], 'weekly');
    const grassCondition = greatestConfiguredKey(p.overgrowthMultipliers, ['maintained', 'overgrown', 'severe'], 'maintained');
    const base = { yardSqft: 10_000_000, sqftMethod: 'exact', serviceFrequency, grassCondition, bagClippings: false, edgingIncluded: false };
    const bagClippings = ![undefined, null, ''].includes(p.baggingSurchargePercent);
    const edgingIncluded = ![undefined, null, ''].includes(p.edgingPerLinearFoot);
    return !bagClippings && !edgingIncluded ? [base] : [base, {
      ...base, bagClippings, edgingIncluded, ...(edgingIncluded ? { edgingLengthLF: 1_000_000 } : {})
    }];
  }
  if (serviceType === 'SIDING_REPLACEMENT') {
    const stories = greatestConfiguredKey(p.storyMultiplier, [1, 2, 3], 2);
    return keysOf(p.laborPerSqft, 'vinyl').map(sidingType => ({ areaInputMethod: 'sqft', sidingAreaSqft: 2_000_000, sidingType, stories, oldSidingRemoval: false, trimIncluded: false }));
  }
  if (serviceType === 'SIDING_REPAIR') {
    const stories = greatestConfiguredKey(p.storyMultiplier, [1, 2, 3], 2);
    return repairScenarios(serviceType, p.repairHours, ['vinyl', 'minor'], (sidingType, damageLevel, affectedArea) => ({ sidingType, damageLevel, affectedArea, stories }), p.largeRepairMaxSqft);
  }
  if (serviceType === 'CUSTOM') return [{ service: service.service, serviceConfirmed: true, unit: p.unit || 'flat', ...({ per_hour: { hours: 4 }, per_unit: { itemCount: 3 }, per_sqft: { areaSqft: 500 }, per_LF: { linearFeet: 120 }, per_square: { roofSquares: 20 } }[p.unit] || {}) }];
  return [];
}

export function activationScenarios(service,confirmedService=service,tierName=null,selection=null,includeOptionalScopes=true,defaults=null) {
 const p=pricingOf(service),type=service.serviceType,extra=[];
 const scenarios=baseActivationScenarios(service,confirmedService,selection).map(input=>({...input,...(type==='FLAT_ROOF_REPLACEMENT'?{insulationNeeded:false,coverboardNeeded:false}:{}),...(type.startsWith('CONCRETE_')?{adjoinsExistingConcrete:false}:{})})).filter(input=>{
  if(!configuredOffering(type,p))return true;
  const additional=input.ceilingsIncluded||input.trimIncluded||input.oldFenceRemoval||Object.values(input.gates||{}).some(count=>count>0);
  return !additional||completeOptionalPricing(confirmedService,input,p,tierName,defaults);
 });
 if(!includeOptionalScopes)return scenarios;
 if(type.startsWith('FLOORING_'))for(const input of scenarios){
  // Preserve every room boundary for configured optional work, without making
  // an unfinished extra a prerequisite for the base product. Do not turn a
  // different flooring product into a vinyl scenario during this pass.
  for(const optional of optionalPricingRequests(service,input))if(!optional.changes.newFlooringType||optional.changes.newFlooringType===input.newFlooringType)extra.push({...input,...optional.changes});
 }
 const add=changes=>{if(scenarios[0])extra.push({...scenarios[0],...changes});};
 for(const [key,d] of Object.entries(p.scopeDetails||{})){
  const base=scopeBaseKey(key);
  if(base==='stairs'){const seed=scenarios.find(c=>c.newFlooringType===d.flooringType&&!c.removalNeeded);if(seed)for(const width of [...new Set([d.minimumWidthLF??0,d.maximumWidthLF].flatMap(boundaryMeasurements))].filter(n=>n>=0.1))extra.push({...seed,stairSteps:5,stairWidthLF:width,stairRemovalNeeded:d.removalIncluded,stairDisposalNeeded:d.disposalIncluded});}
  if(base==='floor_overlay'){const seed=scenarios.find(c=>c.newFlooringType===d.newFlooringType&&!c.removalNeeded);if(seed)extra.push({...seed,existingFloorType:d.existingFloorType});}
  if(base==='siding_removal')add({oldSidingRemoval:true,existingSidingType:d.existingSidingType,sidingRemovalStories:d.stories});
  if(base==='demolition')for(const thickness of [...new Set([d.minimumThickness??0,d.maximumThickness].flatMap(boundaryMeasurements))].filter(n=>n>=0.1))add({demolitionNeeded:true,demolitionAreaSqft:200,demolitionThickness:thickness,demolitionReinforcement:d.reinforcement,demolitionAccessDifficulty:d.accessDifficulty});
  if(key==='siding_trim')add({trimIncluded:true,trimLengthLF:200});
  if(key==='exposed_aggregate')add({finishType:'exposed_aggregate'});
  if(key==='insulation')for(const layer of ['insulation','coverboard'])add({[layer+'Needed']:true});
 }
 // Missing optional scope prices are reported by scopeCoverage. Probe their
 // calculations once configured, without making unfinished additions a gate
 // on the independently priced base work.
 return [...scenarios,...extra.filter(input=>completeOptionalPricing(confirmedService,input,p,tierName,defaults))];
}

// Unsupported sides of bands are intentional review probes. They must not
// disable supported work, and they must never be normalized into a priced band.
export function activationReviewScenarios(service) {
 const type=service.serviceType,p=pricingOf(service),repair=['ROOFING_REPAIR','FLAT_ROOF_REPAIR','SIDING_REPAIR'].includes(type);
 if(!repair&&!Object.keys(p.scopeDetails||{}).some(key=>['stairs','demolition'].includes(scopeBaseKey(key))))return [];
 const base=baseActivationScenarios(service),out=[];
 if(repair&&Number.isFinite(p.largeRepairMaxSqft)){
  for(const c of base.filter((c,i,a)=>a.findIndex(other=>JSON.stringify({...other,affectedArea:0})===JSON.stringify({...c,affectedArea:0}))===i))out.push({...c,affectedArea:boundaryMeasurements(p.largeRepairMaxSqft)[2]});
 }
 for(const [key,d] of Object.entries(p.scopeDetails||{})){
  const scope=scopeBaseKey(key);if(!['stairs','demolition'].includes(scope))continue;
  const seed=scope==='stairs'?base.find(c=>c.newFlooringType===d.flooringType&&!c.removalNeeded):base[0];if(!seed)continue;
  const limits=scope==='stairs'?[d.minimumWidthLF??0,d.maximumWidthLF]:[d.minimumThickness??0,d.maximumThickness];
  for(const value of [...new Set(limits.flatMap(boundaryMeasurements))].filter(n=>n>=0.1)){
   const c={...seed,...(scope==='stairs'?{stairSteps:5,stairWidthLF:value,stairRemovalNeeded:d.removalIncluded,stairDisposalNeeded:d.disposalIncluded,floorAreaExcludesStairs:true}:{demolitionNeeded:true,demolitionAreaSqft:200,demolitionThickness:value,demolitionReinforcement:d.reinforcement,demolitionAccessDifficulty:d.accessDifficulty,adjoinsExistingConcrete:false})};
   if(!scopeEntriesFor(p,scope).some(([entry,detail])=>scopeMatchesRequest(entry,detail,c)))out.push(c);
  }
 }
 return out;
}

function uniqueStatusDiagnostics(items) {
  const seen = new Set();
  return items.filter(item => {
    const key = `${item.type}:${item.kind || ''}:${item.path}:${item.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function isUnpricedPreparation(item) {
  return item.type === 'missing' && /^offeringRates\.prep(?:Labor|Material)PerSqft(?:_(?:good|fair|poor))?$/.test(item.path);
}

function conditionStatusDiagnostics(variant) {
  if (!variant.products?.length || !variant.products.every(product => Object.hasOwn(product.selection, 'surfaceCondition'))) return variant.diagnostics;
  // Readiness still uses the unmodified activation results. Missing prices for
  // an optional condition belong in coverage, not in the required setup list.
  const diagnostics = variant.diagnostics.filter(item => !isUnpricedPreparation(item));
  if (variant.products.every(product => product.diagnostics.some(isUnpricedPreparation))) {
    diagnostics.push({ type: 'missing', kind: 'condition_coverage', path: 'offeringRates',
      message: 'Price preparation for at least one surface condition before this offering can quote.' });
  }
  return diagnostics;
}

function productStatusCoverage(variant, product) {
  const coverage = { tierName: variant.tierName, selection: product.selection,
    configurationComplete: product.ok, ownerDiagnostics: product.diagnostics };
  if(product.coverageMode==='product_axis')return {...coverage,coverageMode:product.coverageMode};
  if (product.coverageMode === 'reference_pair') return { ...coverage, coverageMode: product.coverageMode,
    coverageMessage: product.ok ? 'Ready to quote for the two products shown.' : 'Needs setup for the two products shown: ' + product.diagnostics.map(item => item.message).join(' ') };
  if (!Object.hasOwn(product.selection, 'surfaceCondition')) return coverage;
  const unpricedOwnerFields = [...new Set(product.diagnostics.filter(isUnpricedPreparation).map(item => item.path))];
  return { ...coverage, ownerDiagnostics: product.diagnostics.filter(item => !isUnpricedPreparation(item)), unpricedOwnerFields,
    ...(unpricedOwnerFields.length ? { coverageMessage: 'Not yet priced. Requests for this condition go to review.' } : {}) };
}

function scopeCoverageForService(service,defaults=null) {
  if (!service || !SERVICE_TYPES.includes(service.serviceType) || validateTierDefinitionsDetailedVNext(service, service.serviceType).length) return [];
  const type = service.serviceType, base = pricingOf(service);
  const variants = service.tiers?.length ? service.tiers.map(t => ({ name: t.name, pricing: mergePricingForValidationVNext(base, t.overrides || {}) })) : [{ name: null, pricing: base }];
  const rows = new Map();
  for (const variant of variants) {
    const p = variant.pricing, definitions = scopeDefinitions(type, p);
    if(type.startsWith('FENCING_')&&configuredOffering(type,p))for(const [key,gate] of Object.entries(p.offeringDetails?.gates||{})){
      const measured=offeringGateDefinitions(base,service)[key];
      if(typeof gate?.widthLF==='number'&&typeof measured?.widthLF==='number'&&exactCompare(gate.widthLF,measured.widthLF)!==0){
        const id='gate_width_'+key;if(!rows.has(id))rows.set(id,{key:id,label:'Gate opening width: '+key.replaceAll('_',' '),configurationComplete:false,variants:[],message:'This price option changes the confirmed gate-opening width. Requests using this gate need a matching option or owner review.'});
        rows.get(id).variants.push({tierName:variant.name,configurationComplete:false,missingFields:['offeringDetails.gates.'+key+'.widthLF']});
      }
    }
    for (const [key, definition] of Object.entries(definitions).flatMap(([key,def])=>key==='insulation'?['insulation','coverboard'].map(layer=>[layer,{...def,layer,label:'Roof '+layer}]):[[key,def]])) {
      const configurationKey=definition.layer?'insulation':key;
      const scope=scopeBaseKey(key),detail=p.scopeDetails?.[key]||{};
      if(scope===key&&!isPlainRecord(p.scopeDetails?.[key])&&scopeEntriesFor(p,scope).length)continue;
      const floor = key.startsWith('floor_underlayment_') ? key.slice('floor_underlayment_'.length) : undefined;
      const roof = key.startsWith('roof_underlayment_') ? key.slice('roof_underlayment_'.length) : undefined;
      const probe = { existingFloorType: 'none', ...(floor ? { newFlooringType: floor, underlaymentSelected: true, subfloorCondition: 'requires_underlayment' } : {}), ...(roof ? { replacementRoofType: roof } : {}) };
      if (scope === 'stairs') Object.assign(probe, { stairSteps: 1, newFlooringType:detail.flooringType,stairWidthLF:detail.maximumWidthLF,stairRemovalNeeded:detail.removalIncluded,stairDisposalNeeded:detail.disposalIncluded });
      if (scope === 'floor_overlay') Object.assign(probe, { removalNeeded: false, existingFloorType: detail.existingFloorType || 'existing_floor',newFlooringType:detail.newFlooringType });
      if (scope === 'siding_removal') Object.assign(probe,{oldSidingRemoval:true,existingSidingType:detail.existingSidingType,sidingRemovalStories:detail.stories});
      if (key === 'siding_trim') probe.trimIncluded = true;
      if (scope === 'demolition') Object.assign(probe,{demolitionNeeded:true,demolitionThickness:detail.maximumThickness,demolitionReinforcement:detail.reinforcement,demolitionAccessDifficulty:detail.accessDifficulty});
      if (key === 'exposed_aggregate') probe.finishType = 'exposed_aggregate';
      if (definition.layer) Object.assign(probe,{insulationNeeded:false,coverboardNeeded:false,[definition.layer+'Needed']:true});
      if (key.includes('ceiling')) { if (type !== 'INTERIOR_PAINTING' || p.offeringMode && p.offeringDetails?.ceilingsOffered !== true) continue; probe.ceilingsIncluded = true; }
      if (key === 'paint_trim') { if (type !== 'INTERIOR_PAINTING') continue; probe.trimIncluded = true; }
      if (!scopeKeysForRequest(type, probe, p, service).includes(configurationKey)) continue;
      const rates = Object.entries(scopeRateDefinitions(type, p)).filter(([, field]) => field.scopeKey === configurationKey&&(!definition.layer||field.layer===definition.layer)).map(([name]) => 'scopeRates.' + name);
      const related = d => {if(definition.layer&&d.path==='scopeDetails.insulation.'+(definition.layer==='insulation'?'coverboard':'insulation')+'System')return false;return d.path === 'scopeDetails' || d.path === 'scopeRates' || d.path === 'scopeDetails.' + configurationKey || d.path?.startsWith('scopeDetails.' + configurationKey + '.') || rates.includes(d.path);};
      const shareErrors=selectedShareDiagnostics(service,probe,p,defaults).filter(d=>rates.some(path=>d.path==='installedMaterialsPercent.'+path));
      const errors = [...scopeStructureDiagnostics(type, p), ...validateOwnerPricing(type, scopeActivationInputs(type, probe, p, service), p, service, variant.name).ownerDiagnostics].filter(related).concat(shareErrors);
      const complete = isPlainRecord(p.scopeDetails?.[configurationKey]) && (rates.length > 0 || p.scopeDetails[configurationKey].mode === 'included_in_floor_price') && errors.length === 0;
      if (!rows.has(key)) rows.set(key, { key, label: definition.label, configurationComplete: false, variants: [] });
      const row = rows.get(key); row.configurationComplete ||= complete; row.variants.push({ tierName: variant.name, configurationComplete: complete, missingFields: [...new Set(errors.map(d => d.path))] });
    }
  }
  for(const variant of variants){
    const p=variant.pricing,configured={...service,pricing:p},scenarios=baseActivationScenarios(configured,configured,firstCatalogSelection(configured));
    // Itemized painting can price only some conditions. Optional coverage uses
    // a priced base condition when one exists, not necessarily the first one.
    const base=configuredOffering(type,p)?scenarios.find(input=>completeOptionalPricing(configured,input,p,variant.name))||scenarios[0]:scenarios[0];
    for(const optional of optionalPricingRequests(configured,base)){
      const inputs=scopeActivationInputs(type,{...base,...optional.changes},p,service);
      const validation=validateOwnerPricing(type,inputs,p,service,variant.name);
      const gateErrors=type.startsWith('FENCING_')&&configuredOffering(type,p)?offeringContract(type,p,service).crossValidate(inputs):[];
      const shareErrors=selectedShareDiagnostics(service,inputs,p,defaults);
      const complete=validation.ok&&gateErrors.length===0&&shareErrors.length===0;
      if(!rows.has(optional.key))rows.set(optional.key,{key:optional.key,label:optional.label,configurationComplete:false,setupSection:'optional_prices',variants:[]});
      const row=rows.get(optional.key);row.configurationComplete ||= complete;
      row.variants.push({tierName:variant.name,configurationComplete:complete,missingFields:[...new Set([...validation.ownerDiagnostics.map(d=>d.path),...gateErrors.map(d=>'customerInputs.'+d.field),...shareErrors.map(d=>d.path)])]});
    }
  }
  return [...rows.values()].map(row => ({ ...row, message: row.message || (row.configurationComplete
    ? 'Scope configured. Matching measured requests can quote when the required pricing and saved approval are complete.' + (row.variants.some(v => !v.configurationComplete) ? ' Some price options still need scope setup.' : '')
    : row.label + ' requests arrive as leads until you configure this scope and its prices.') }));
}

function laborAdjustmentCoverage(service) {
  if(!service||!SERVICE_TYPES.includes(service.serviceType)||validateTierDefinitionsDetailedVNext(service,service.serviceType).length)return [];
  const type=service.serviceType,base=pricingOf(service),rows=[];
  const selections=type.startsWith('FENCING_')?[{terrainSlope:'flat'},{terrainSlope:'moderate'},{terrainSlope:'steep'}]:type==='INTERIOR_PAINTING'?[{wallHeight:'standard'},{wallHeight:'high'},{wallHeight:'vaulted'}]:type==='EXTERIOR_PAINTING'?[{stories:1},{stories:2},{stories:3}]:[];
  const variants=service.tiers?.length?service.tiers.map(t=>({name:t.name,pricing:mergePricingForValidationVNext(base,t.overrides||{})})):[{name:null,pricing:base}];
  for(const {name,pricing:p} of variants)for(const selection of selections){
    const missing=Object.entries(installedPriceDefinitions(type,p)).filter(([path])=>{const factorPath=installedLaborFactorPath(type,selection,path),factor=factorPath?.split('.').reduce((v,k)=>v?.[k],p);return factorPath&&typeof factor==='number'&&factor!==1&&p.installedLaborPercent?.[path]===undefined;});
    if(missing.length)rows.push({tierName:name,selection,missingOwnerFields:missing.map(([path])=>'installedLaborPercent.'+path),components:missing.map(([,label])=>label),message:'Requests for this condition that include these installed prices need review until you enter their labor portions.'});
  }
  return rows;
}

function basicPaintNotices(service, validTierNames) {
  if(service?.serviceType!=='INTERIOR_PAINTING')return [];
  const base=pricingOf(service);
  // Tier definitions already have their own blocking diagnostics. Do not infer
  // a base-only limitation from an invalid or unreadable option definition.
  if(validateTierDefinitionsDetailedVNext(service,service.serviceType).length)return [];
  const variants=service.tiers?.length
    ? service.tiers.map(tier=>({name:tier.name,pricing:mergePricingForValidationVNext(base,tier.overrides||{})}))
    : [{name:null,pricing:base}];
  const available=validTierNames.length?variants.filter(v=>validTierNames.includes(v.name)):variants;
  const basic=available.filter(v=>basicInteriorPainting(service.serviceType,v.pricing));
  if(!basic.length)return [];
  if(basic.length===available.length)return [BASIC_PAINT_PREPARATION_NOTICE];
  return basic.map(v=>v.name+': '+BASIC_PAINT_PREPARATION_NOTICE);
}

function statusFromDiagnostics(service, diagnostics, failedTierDiagnostics = [], validTierNames = []) {
  const blocking = uniqueStatusDiagnostics(diagnostics);
  const live = service?.active === true && blocking.length === 0 && validTierNames.length > 0;
  const invalidTypes = new Set(['invalid', 'unsupported', 'cross_field', 'owner_decision']);
  return {
    serviceType: service?.serviceType,
    service: service?.service || SERVICE_NAMES[service?.serviceType] || 'Service',
    statusNotices: basicPaintNotices(service,validTierNames),
    scopeCoverage: scopeCoverageForService(service),
    laborAdjustmentCoverage: laborAdjustmentCoverage(service),
    status: live ? 'QUOTING LIVE' : 'NEEDS PRICING',
    missingOwnerFields: [...new Set(blocking.filter(item => item.type === 'missing').map(item => item.path))],
    invalidOwnerFields: [...new Set(blocking.filter(item => invalidTypes.has(item.type)).map(item => item.path))],
    unsupportedOwnerFields: [...new Set(blocking.filter(item => item.type === 'unsupported').map(item => item.path))],
    crossFieldOwnerFields: [...new Set(blocking.filter(item => item.type === 'cross_field').map(item => item.path))],
    ownerDecisionRequired: blocking.filter(item => item.type === 'owner_decision').map(({ path, kind, message }) => ({ path, kind, message })),
    ownerDiagnostics: blocking,
    validationErrors: [...new Set(blocking.map(item => item.message))],
    failedTierDiagnostics,
    validTierNames,
    ...(live && failedTierDiagnostics.length ? { optionAvailabilityNotice: 'Fewer options are available because one or more configured options need owner review.' } : {})
  };
}

function activationFeeSelections(service, options) {
  const selections = { owner: {}, customer: {} };
  const savedOwnerChoices = Object.hasOwn(options, 'ownerFeeSelections');
  if (savedOwnerChoices) selections.owner = options.ownerFeeSelections;
  for (const fee of ['travel', 'disposal', 'permit', 'overhead']) {
    const mode = service.feeRules?.[fee];
    if (mode === 'owner_selected' && !savedOwnerChoices) selections.owner[fee] = true;
    if (mode === 'customer_selected') selections.customer[fee] = true;
  }
  return selections;
}

function appendActivationReviewDiagnostics(diagnostics, result) {
  const before = diagnostics.length;
  const message = result.reviewReason || 'Activation scenario could not complete the quote pipeline safely.';
  diagnostics.push(...(result.ownerDiagnostics || []).map(item => ({ ...item, kind: item.kind || 'activation_pipeline' })));
  for (const path of result.missingOwnerFields || []) diagnostics.push({ type: 'missing', kind: 'activation_pipeline', path, message });
  for (const path of result.invalidOwnerFields || []) diagnostics.push({ type: 'invalid', kind: 'activation_pipeline', path, message });
  for (const path of result.unsupportedOwnerFields || []) diagnostics.push({ type: 'unsupported', kind: 'activation_pipeline', path, message });
  for (const path of result.crossFieldOwnerFields || []) diagnostics.push({ type: 'cross_field', kind: 'activation_pipeline', path, message });
  for (const path of result.missingCustomerFields || []) diagnostics.push({ type: 'missing', kind: 'activation_scenario', path: `customerInputs.${path}`, message });
  for (const path of result.invalidCustomerFields || []) diagnostics.push({ type: 'invalid', kind: 'activation_scenario', path: `customerInputs.${path}`, message });
  for (const decision of result.ownerDecisionRequired || []) diagnostics.push({ type: 'owner_decision', kind: decision.kind, path: decision.path, message: decision.message });
  if (result.inspectionFirst && diagnostics.length === before) diagnostics.push({ type: 'invalid', kind: 'pricing_policy', path: 'pricingPolicy', message });
  if (diagnostics.length === before) diagnostics.push({ type: 'invalid', kind: 'activation_pipeline', path: 'pricingCalculation', message });
}

function activationMonth(service, defaults) {
  const months = service.peakMonths !== undefined ? service.peakMonths : defaults.peakMonths;
  return Array.isArray(months) && months.length ? months[0] : 1;
}

// Readiness evaluates every product (pair) exactly. Owner-facing status reports
// coverage for every product; customer-facing checks only need to know whether
// the service can quote at all, so they may stop at the first live product
// (options.firstLiveProduct). The answer to "is this service live" is identical
// either way; only the per-product detail is skipped.
// Roof and flat-roof replacement are priced per replacement product and per
// existing product. Up to PAIR_DETAIL_LIMIT combinations, the owner sees every
// pair checked exactly. Larger catalogs show checked reference combinations:
// each replacement product is checked against a complete existing product and
// each existing product against a complete replacement product. Both products
// remain in each result, so readiness is never implied for an untested pairing.
// Every requested customer pair is still fully checked by the quote engine.
const PAIR_SELECTORS={ROOFING_REPLACEMENT:['replacementRoofType','existingRoofType'],FLAT_ROOF_REPLACEMENT:['replacementMembraneType','membraneType']};
const PAIR_DETAIL_LIMIT=100;
function roofCatalogAxes(service) {
  const type=service.serviceType,p=pricingOf(service),fields=PAIR_SELECTORS[type];
  if(!fields)return null;
  if(type==='ROOFING_REPLACEMENT')return {fields,values:[keysOf(p.laborPerSquare,'asphalt_shingle'),keysOf(p.tearOffPerSquare,'asphalt_shingle')],roots:[['laborPerSquare','materialCostPerSquare','underlaymentPerSquare','underlaymentPriceBasis'],['tearOffPerSquare']]};
  const replacements=keysOf(p.laborPerSqft,'epdm').filter(key=>key!=='average'),existing=keysOf(p.tearOffPerSqft,'epdm').filter(key=>key!=='average');
  const R=replacements.length?replacements:['epdm'];
  return {fields,values:[R,existing.length?existing:R],roots:[['laborPerSqft','membraneCostPerSqft'],['tearOffPerSqft']]};
}
function firstCatalogSelection(service) {
  const axes=roofCatalogAxes(service);
  return axes?Object.fromEntries(axes.fields.map((field,i)=>[field,axes.values[i][0]])):null;
}

// Remove only proven, counterpart-independent failures before searching. A zero
// included in a price on the other axis is deliberately NOT pruned: its validity
// depends on the requested pair. Actual candidate pairs still use every existing
// customer, owner, template and financial-pipeline check.
function evaluateRoofCatalog(service,p,tierName,tierIndex,defaults,options,axes) {
  const type=service.serviceType,configured={...service,pricing:p},[rField,eField]=axes.fields,[R,E]=axes.values;
  const first=firstCatalogSelection(configured),prototype=baseActivationScenarios(configured,service,first)[0];
  const validation=createActivationValidationVNext(type,p,service,tierName),structures=validatePricingStructuresDetailed(type,p),factors=validateClass2FactorsDetailed(type,p);
  const shareFailures=new Map(installedMaterialShareDiagnosticsVNext(type,p,defaults,Object.keys(installedPriceDefinitions(type,p))).map(d=>[d.path.slice('installedMaterialsPercent.'.length),d]));
  const failures=[new Map(),new Map()],dependencies=[new Map(),new Map()];
  const productAtPath=(path,axis)=>{
    if(typeof path!=='string')return null;
    const [root,product,...rest]=path.split('.');
    return !rest.length&&axes.roots[axis].includes(root)?product:null;
  };
  const sharedPaths=new Set(ownerRequirements(type,prototype,p,service).map(item=>item.path).filter(path=>!path.includes('.')));
  const shared=validation.owner(prototype).ownerDiagnostics.filter(d=>sharedPaths.has(d.path)&&
    !(d.kind==='unclassified_zero_core_price'&&axes.roots.some((_,axis)=>productAtPath(service.zeroPricePolicy?.includedPrices?.[d.path],axis))));
  if(shared.length)return {ok:false,tierName,tierIndex,diagnostics:shared,reviewReason:shared[0].message};
  // These two roof catalogs share their disposal replacement across products.
  // Ask the real template once, so deferring disposal decisions does not turn
  // a missing shared fee choice into another exhaustive product-pair search.
  try{
    const feeProbe={...prototype,confirmedFacts:Object.fromEntries(axes.fields.filter(field=>Object.hasOwn(service.knownOfferings?.[field]||{},prototype[field])).map(field=>[field,{status:'identified',field,value:prototype[field],offeringId:service.knownOfferings[field][prototype[field]]}]))};
    const template=calculateServiceVNext(type,feeProbe,p,{ownerPricing:service,tierName,skipAddon(){}});
    const feeCheck=validateFeeSelectionRequest(service,activationFeeSelections(service,options),template.replacedCommonFees,true);
    const diagnostics=[...feeCheck.invalidOwnerFields,...feeCheck.invalidCustomerFields].map(path=>({type:'invalid',kind:'activation_pipeline',path,message:'Common fee selection is missing or invalid.'}));
    if(diagnostics.length)return {ok:false,tierName,tierIndex,diagnostics,reviewReason:diagnostics[0].message};
  }catch(error){if(!(error instanceof QuoteReviewError))throw error;}
  for(let axis=0;axis<2;axis++)for(const product of axes.values[axis]){
    const field=axes.fields[axis],inputs=scopeActivationInputs(type,{...prototype,[field]:product},p,service);
    inputs.confirmedFacts=Object.fromEntries(axes.fields.filter(name=>Object.hasOwn(service.knownOfferings?.[name]||{},inputs[name])).map(name=>[name,{status:'identified',field:name,value:inputs[name],offeringId:service.knownOfferings[name][inputs[name]]}]));
    const paths=axes.roots[axis].map(root=>root+'.'+product);
    if(axis===0&&type==='ROOFING_REPLACEMENT')paths.push('scopeDetails.roof_underlayment_'+product,'scopeRates.roof_underlayment_'+product);
    // A selected included zero can only be covered by its declared product.
    // Read the actual requirements so replaced cost-underlayment prices do not
    // impose dependencies for lines that the quote would never bill.
    const needed=new Set();
    for(const item of ownerRequirements(type,inputs,p,service)){
      if(valueAtPath(p,item.path)!==0||!(paths.includes(item.path)||sharedPaths.has(item.path)))continue;
      const covering=productAtPath(service.zeroPricePolicy?.includedPrices?.[item.path],1-axis);
      if(covering)needed.add(covering);
    }
    dependencies[axis].set(product,needed);
    const owner=validation.owner(inputs).ownerDiagnostics.filter(d=>{
      if(!paths.some(path=>d.path===path||d.path.startsWith(path+'.')))return false;
      const includedIn=service.zeroPricePolicy?.includedPrices?.[d.path];
      return !(d.kind==='unclassified_zero_core_price'&&typeof includedIn==='string'&&axes.roots[1-axis].some(root=>includedIn.startsWith(root+'.'))&&valueAtPath(p,includedIn)>0);
    });
    const registry=(validation.customer(inputs).ownerDiagnostics||[]).filter(d=>d.path==='knownOfferings.'+field||d.path.startsWith('knownOfferings.'+field+'.'));
    const shares=paths.flatMap(path=>shareFailures.has(path)?[shareFailures.get(path)]:[]);
    const diagnostics=uniqueStatusDiagnostics([...owner,...registry,...shares]);
    if(diagnostics.length)failures[axis].set(product,{selection:{[field]:product},ok:false,diagnostics,reviewReason:diagnostics[0].message,coverageMode:'product_axis'});
  }
  const candidates=axes.values.map((values,axis)=>values.filter(value=>!failures[axis].has(value)));
  const pipelineCheck=defaults?createActivationQuoteCheckVNext(activationPipelineRequest(service,p,tierName,defaults,options),tierName):null;
  const cache=new Map(),representatives=[new Map(),new Map()];
  const check=(r,e)=>{
    const key=JSON.stringify([r,e]);if(cache.has(key))return cache.get(key);
    const selection={[rField]:r,[eField]:e};
    // Optional-scope probes belong to the original first pair, exactly as in
    // the former eager scenario list. A missing sibling never gains new work.
    const scenarios=activationScenarios(configured,service,tierName,selection,r===R[0]&&e===E[0],defaults);
    const result={selection,...evaluateActivationVariant(service,p,tierName,tierIndex,defaults,{...options,structures,factors,validation,pipelineCheck,productScenarios:scenarios}),coverageMode:'reference_pair'};
    if(cache.size<2*(R.length+E.length))cache.set(key,result);
    if(!result.ok){if(!representatives[0].has(r))representatives[0].set(r,result);if(!representatives[1].has(e))representatives[1].set(e,result);}
    return result;
  };
  let reference=null;
  const matches=(axis,product,other)=>[...dependencies[axis].get(product)].every(needed=>needed===other);
  const rememberAllocation=(result,r,e)=>{
    for(let axis=0;axis<2;axis++){
      const product=axis===0?r:e;
      const diagnostics=result.diagnostics.filter(d=>{
        if(d.kind!=='included_price_allocation')return false;
        const path=d.path.replace(/^zeroPricePolicy\.includedPrices\./,'');
        return productAtPath(path,axis)===product&&productAtPath(service.zeroPricePolicy?.includedPrices?.[path],axis)===product;
      });
      if(diagnostics.length)failures[axis].set(product,{selection:{[axes.fields[axis]]:product},ok:false,diagnostics,reviewReason:diagnostics[0].message,coverageMode:'product_axis'});
    }
  };
  search:for(const r of candidates[0]){
    let checked=false;
    for(const e of candidates[1]){
      if(failures[1].has(e)||!matches(0,r,e)||!matches(1,e,r))continue;
      const result=check(r,e);checked=true;
      if(result.ok){reference=result;break search;}
      rememberAllocation(result,r,e);
      if(failures[0].has(r))break;
    }
    // Retain an actual failed reference when all covering products are absent
    // or blocked. It supplies diagnostics without claiming an untested pair.
    if(!checked&&candidates[1].length)check(r,candidates[1][0]);
  }
  const products=new Map(),add=row=>products.set(JSON.stringify(row.selection),row);
  if(reference&&options.firstLiveProduct)add(reference);
  else {
    for(const map of failures)for(const row of map.values())add(row);
    if(reference){for(const r of candidates[0])if(!failures[0].has(r))add(check(r,reference.selection[eField]));for(const e of candidates[1])if(!failures[1].has(e))add(check(reference.selection[rField],e));}
    else for(const map of representatives)for(const row of map.values())if(!failures[0].has(row.selection[rField])&&!failures[1].has(row.selection[eField]))add(row);
  }
  const rows=[...products.values()],diagnostics=uniqueStatusDiagnostics(rows.filter(row=>!row.ok).flatMap(row=>row.diagnostics));
  return {ok:!!reference,tierName,tierIndex,products:rows,diagnostics,reviewReason:diagnostics[0]?.message||null};
}
function activationPipelineRequest(service, pricing, tierName, businessDefaults, options) {
  return {
    serviceType: service.serviceType,
    ownerPricing: { ...service, active: true },
    businessDefaults, callerType: 'owner',
    feeSelections: activationFeeSelections(service, options),
    currentMonth: activationMonth(service, businessDefaults),
    allowInactiveOwnerPreview: true
  };
}
function evaluateActivationVariant(service, effectivePricing, tierName, tierIndex, businessDefaults, options) {
  if(!options.productScenarios){
    for(const probe of activationReviewScenarios({...service,pricing:effectivePricing})){
      const c=scopeActivationInputs(service.serviceType,probe,effectivePricing,service);
      c.confirmedFacts=Object.fromEntries(Object.entries(service.knownOfferings||{}).filter(([field,values])=>Object.hasOwn(values,c[field])).map(([field,values])=>[field,{status:'identified',field,value:c[field],offeringId:values[c[field]]}]));
      if(validateCustomerInputs(service.serviceType,c,effectivePricing,service).ok&&validateOwnerPricing(service.serviceType,c,effectivePricing,service,tierName).ok){
        const diagnostics=[{type:'invalid',kind:'activation_boundary',path:'pricingCalculation',message:'An unsupported scope boundary was accepted during activation.'}];
        return {ok:false,tierName,tierIndex,diagnostics,reviewReason:diagnostics[0].message};
      }
    }
  }
  // Reject selection-independent blockers on this tier's already-merged prices
  // before constructing/searching product pairs. A tier may repair base prices;
  // explicit zero minima remain valid. The existing selection filter treats
  // malformed structures as global, but scopes missing map entries to products.
  // Keep that distinction: an incomplete sibling must not block a live pair.
  if (PAIR_SELECTORS[service.serviceType] && !options.productScenarios) {
    const sharedPaths = new Set(['minimumJob', 'accessoryPricingMode', 'materialAccessoryBasis']);
    const shared = validateOwnerPricing(service.serviceType, {}, effectivePricing, service, tierName)
      .ownerDiagnostics.filter(item => item.kind === 'class2' || sharedPaths.has(item.path) ||
        (item.type === 'unsupported' && item.kind === 'field'));
    const structures = validatePricingStructuresDetailed(service.serviceType, effectivePricing);
    const diagnostics = uniqueStatusDiagnostics([...shared, ...structures.filter(item => item.type !== 'missing')]);
    if (diagnostics.length) return { ok: false, tierName, tierIndex, diagnostics, reviewReason: diagnostics[0].message };
  }
  // Fee decisions are shared by the entire catalog. Check them once, before
  // repeated product calculations. Disposal may be replaced by an included
  // measured scope; leave its presence to the actual scenario in that case.
  // Only the calculated template knows whether disposal is replaced. Syntax
  // and other required fee decisions remain global; disposal presence is
  // checked against the real replacement list in each complete quote below.
  const fees=validateFeeSelectionRequest(service,activationFeeSelections(service,options),['disposal'],true);
  if(fees.invalidOwnerFields.length||fees.invalidCustomerFields.length){
    const diagnostics=[...fees.invalidOwnerFields,...fees.invalidCustomerFields].map(path=>({type:'invalid',kind:'activation_pipeline',path,message:'Common fee selection is missing or invalid.'}));
    return {ok:false,tierName,tierIndex,diagnostics,reviewReason:diagnostics[0].message};
  }
  const axes=!options.productScenarios&&roofCatalogAxes({...service,pricing:effectivePricing});
  if(axes&&axes.values[0].length*axes.values[1].length>PAIR_DETAIL_LIMIT)return evaluateRoofCatalog(service,effectivePricing,tierName,tierIndex,businessDefaults,options,axes);
  // All boundary probes within one product must pass; incomplete siblings do not block it.
  const selectors=service.serviceType==='ROOFING_REPLACEMENT'?['replacementRoofType','existingRoofType']:service.serviceType==='FLAT_ROOF_REPLACEMENT'?['replacementMembraneType','membraneType']:service.serviceType.startsWith('FLOORING_')?['newFlooringType']:['INTERIOR_PAINTING','EXTERIOR_PAINTING'].includes(service.serviceType)&&effectivePricing.offeringMode==='itemized'?['surfaceCondition']:[];
  if(selectors.length&&!options.productScenarios){
    const groups=new Map();
    for(const scenario of activationScenarios({...service,pricing:effectivePricing},service,tierName,null,true,businessDefaults)){
      const key=JSON.stringify(selectors.map(field=>scenario[field]));
      if(!groups.has(key))groups.set(key,[]);groups.get(key).push(scenario);
    }
    const structures=validatePricingStructuresDetailed(service.serviceType,effectivePricing);
    const list=[...groups.values()].map(scenarios=>({scenarios,selection:Object.fromEntries(selectors.map(field=>[field,scenarios[0][field]]))}));
    const validation = createActivationValidationVNext(service.serviceType, effectivePricing, service, tierName);
    const factors = validateClass2FactorsDetailed(service.serviceType, effectivePricing);
    const evaluate=g=>({selection:g.selection,...evaluateActivationVariant(service,effectivePricing,tierName,tierIndex,businessDefaults,{...options,structures,factors,validation,productScenarios:g.scenarios})});
    let products=[];
    for(const group of list){const product=evaluate(group);products.push(product);if(options.firstLiveProduct&&product.ok)break;}
    if(products.length)return {ok:products.some(product=>product.ok),tierName,tierIndex,diagnostics:uniqueStatusDiagnostics(products.filter(product=>!product.ok).flatMap(product=>product.diagnostics)),reviewReason:products.find(product=>!product.ok)?.reviewReason||null,products};
  }
  const diagnostics = [];
  const scenarios = options.productScenarios || activationScenarios({ ...service, pricing: effectivePricing },service,tierName,null,true,businessDefaults);
  const pipelineCheck=options.pipelineCheck||(businessDefaults?createActivationQuoteCheckVNext(activationPipelineRequest(service,effectivePricing,tierName,businessDefaults,options),tierName):null);
  let successfulScenarios=0;
  if (!scenarios.length) diagnostics.push({ type: 'invalid', kind: 'activation_scenario', path: 'pricingPolicy', message: 'No activation scenario is available for this configured service.' });
  const allowed = new Set(allowedPricingFields(service.serviceType));
  for (const key of Object.keys(effectivePricing)) {
    if (!allowed.has(key)) diagnostics.push({ type: 'unsupported', kind: 'field', path: key, message: 'This pricing field is not supported for the selected service.' });
  }
  diagnostics.push(
    ...pricingDiagnosticsForSelection(service.serviceType,options.structures||validatePricingStructuresDetailed(service.serviceType, effectivePricing),scenarios[0]||{},effectivePricing,service),
    ...(options.factors || validateClass2FactorsDetailed(service.serviceType, effectivePricing))
  );
  for (const scenarioInputs of scenarios) {
    const customerInputs = { ...scopeActivationInputs(service.serviceType,scenarioInputs,effectivePricing,service), ...(service.feeRules?.permit==='when_scope_selected'?{permitRequired:true}:{}) };
    // Synthetic activation probes test only explicitly registered offerings. They
    // establish no facts about a real customer project.
    const confirmations = Object.fromEntries(Object.entries(service.knownOfferings || {}).filter(([field, values]) => Object.hasOwn(values, customerInputs[field])).map(([field, values]) => [field, { status: 'identified', field, value: customerInputs[field], offeringId: values[customerInputs[field]] }]));
    if (Object.keys(confirmations).length) customerInputs.confirmedFacts = confirmations;
    const customer = options.validation ? options.validation.customer(customerInputs) : validateCustomerInputs(service.serviceType, customerInputs, effectivePricing, service);
    if (!customer.ok) {
      for (const path of customer.missingOwnerFields || []) diagnostics.push({type:'missing',kind:'known_offerings',path,message:customer.reviewReason});
      for (const path of customer.invalidOwnerFields || []) diagnostics.push({type:'invalid',kind:'known_offerings',path,message:customer.reviewReason});
      for (const path of customer.missingCustomerFields || []) diagnostics.push({ type: 'missing', kind: 'activation_scenario', path: `customerInputs.${path}`, message: customer.reviewReason });
      for (const path of customer.invalidCustomerFields || []) diagnostics.push({ type: 'invalid', kind: 'activation_scenario', path: `customerInputs.${path}`, message: customer.reviewReason });
      if (customer.inspectionFirst) diagnostics.push({ type: 'invalid', kind: 'pricing_policy', path: 'pricingPolicy', message: customer.reviewReason });
      continue;
    }
    const owner = options.validation ? options.validation.owner(customerInputs) : validateOwnerPricing(service.serviceType, customerInputs, effectivePricing, service, tierName);
    diagnostics.push(...owner.ownerDiagnostics);
    if (!owner.ok) continue;
    try {
      const template = calculateServiceVNext(service.serviceType, customer.normalized, options.validation?.pricing || effectivePricing, { ownerPricing: options.validation?.serviceRules || service, tierName, skipAddon() {} });
      const subtotalCents = template.lineItems.reduce((sum, line) => sum + line.amountCents, 0);
      if (!Number.isSafeInteger(subtotalCents) || subtotalCents < 0) {
        throw new QuoteReviewError('Activation scenario produced an unsafe service subtotal.', { invalidOwnerFields: ['pricingCalculation'] });
      }
      if (businessDefaults) {
        const pipelineResult = pipelineCheck(customer.normalized);
        if (pipelineResult.resultType !== 'INSTANT_ESTIMATE_READY') appendActivationReviewDiagnostics(diagnostics, pipelineResult);
        else successfulScenarios++;
      }
    } catch (error) {
      if (!(error instanceof QuoteReviewError)) {
        diagnostics.push({ type: 'invalid', kind: 'activation_calculation', path: 'pricingCalculation', message: 'Activation scenario could not be calculated safely.' });
        continue;
      }
      const before = diagnostics.length;
      for (const path of error.missingOwnerFields || []) diagnostics.push({ type: 'missing', kind: 'activation_calculation', path, message: error.reviewReason });
      for (const path of error.invalidOwnerFields || []) diagnostics.push({ type: 'invalid', kind: 'activation_calculation', path, message: error.reviewReason });
      for (const path of [...(error.unsupportedOwnerFields || []), ...(error.unexpectedOwnerFields || [])]) diagnostics.push({ type: 'unsupported', kind: 'activation_calculation', path, message: error.reviewReason });
      for (const path of error.crossFieldOwnerFields || []) diagnostics.push({ type: 'cross_field', kind: 'activation_calculation', path, message: error.reviewReason });
      for (const path of error.invalidCustomerFields || []) diagnostics.push({ type: 'invalid', kind: 'activation_scenario', path: `customerInputs.${path}`, message: error.reviewReason });
      for (const decision of error.ownerDecisionRequired || []) diagnostics.push({ type: 'owner_decision', kind: decision.kind, path: decision.path, message: decision.message });
      if (diagnostics.length === before) diagnostics.push({ type: 'invalid', kind: 'activation_calculation', path: 'pricingCalculation', message: error.reviewReason });
    }
  }
  // A priced removal scope can replace disposal even when the owner has not
  // supplied the choice needed for other work. Keep that valid scope available;
  // every real no-removal request still validates its own fee decisions.
  const unique = uniqueStatusDiagnostics(diagnostics).filter(d=>!successfulScenarios||d.path!=='feeSelections.owner.disposal');
  return {
    ok: unique.length === 0,
    tierName,
    tierIndex,
    diagnostics: unique,
    reviewReason: unique[0]?.message || null
  };
}

// Application readiness supplies saved owner fee decisions. Engine-only callers
// without saved decisions retain synthetic probes of the per-request contract.
export function vNextServiceStatus(service, businessDefaults = null, options = {}) {
  const snapshot = snapshotPlainData(service, 'service');
  if (!snapshot.ok) return statusFromDiagnostics(null, [{
    type: 'invalid', kind: 'service', path: snapshot.errorPath,
    message: `Service could not be read safely: ${snapshot.reason}.`
  }]);
  const blockingServicePath = snapshot.nonPlainPaths[0];
  if (blockingServicePath) {
    let path = blockingServicePath;
    if (path.startsWith('service.pricing.')) {
      path = path.slice('service.pricing.'.length);
    } else if (path.startsWith('service.')) {
      path = path.slice('service.'.length);
    }
    return statusFromDiagnostics(null, [
      { type: 'invalid', kind: 'service', path, message: `${path} must be a plain data value.` }
    ]);
  }
  service = snapshot.value;
  if (!isPlainRecord(service)) return statusFromDiagnostics(service, [{ type: 'invalid', kind: 'service', path: 'service', message: 'Service must be an object.' }]);
  service = canonicalServiceIdentityVNext(service);
  if (!SERVICE_TYPES.includes(service.serviceType)) return statusFromDiagnostics(service, [{ type: 'invalid', kind: 'service', path: 'serviceType', message: 'Service type is unsupported.' }]);
  const pricing = pricingOf(service);
  const hasDateContext=Object.hasOwn(options,'dateContext');
  const timeZone=hasDateContext?resolvedQuoteTimeZone(businessDefaults||{},options.dateContext?.timeZone):null;
  const missingPeakZone=hasDateContext&&timeZone===null&&peakSurchargeConfigured(service,businessDefaults||{});
  if(hasDateContext&&businessDefaults!==null&&businessDefaults!==undefined)businessDefaults=quoteDefaultsForTimeZone(businessDefaults,timeZone);
  const defaultValidation = businessDefaults === null || businessDefaults === undefined
    ? {
        ok: false,
        diagnostics: [{ type: 'missing', kind: 'business_default', path: 'businessDefaults', message: 'Complete business defaults are required before quoting can be live.' }]
      }
    : validateBusinessDefaults(businessDefaults);
  const defaultDiagnostics = defaultValidation.diagnostics.map(item => ({
    ...item,
    path: item.path === 'businessDefaults' || item.path.startsWith('businessDefaults.')
      ? item.path
      : `businessDefaults.${item.path}`
  }));
  const diagnostics = [...validateServiceRulesDetailed(service, service.serviceType), ...defaultDiagnostics];
  if(missingPeakZone)diagnostics.push({type:'missing',kind:'quote_date',path:'businessDefaults.quoteTimeZone',message:MISSING_PEAK_TIME_ZONE});
  if (service.active !== true) diagnostics.push({ type: 'invalid', kind: 'activation', path: 'active', message: 'Service is not enabled for customer quoting.' });
  if (service.serviceType === 'CUSTOM' && (typeof service.service !== 'string' || !service.service.trim() || service.service.trim() === 'CUSTOM')) diagnostics.push({ type: 'invalid', kind: 'service', path: 'service', message: 'Custom service requires a specific configured offering name.' });

  const tierDefinitionDiagnostics = validateTierDefinitionsDetailedVNext(service, service.serviceType);
  diagnostics.push(...tierDefinitionDiagnostics);
  if (AI_SOURCES.has(service.source)) {
    const confirmed = isPlainRecord(service.confirmedFields) ? service.confirmedFields : {};
    for (const field of aiConfirmationFieldsVNext(service, pricing)) {
      if (!hasCurrentApprovalVNext(service, pricing, field)) diagnostics.push({ type: 'missing', kind: 'ai_confirmation', path: `confirmedFields.${field}`, message: `${field} must be individually confirmed before customer quoting.` });
    }
  }

  if (tierDefinitionDiagnostics.length) return statusFromDiagnostics(service, diagnostics);
  // Customer catalogs need only live/not-live. Disabled or globally blocked
  // drafts cannot become live through a product calculation. Owner diagnostics
  // still evaluate the saved draft when detailed coverage is requested.
  if(options.firstLiveProduct&&diagnostics.length)return statusFromDiagnostics(service,diagnostics);
  if(fenceType(service.serviceType)&&fenceCatalog(pricing)){
    const structure=validatePricingStructuresDetailed(service.serviceType,pricing);
    if(structure.length)return statusFromDiagnostics(service,[...diagnostics,...structure]);
  }
  const fenceVariants=fenceType(service.serviceType)&&fenceCatalog(pricing)?fenceCatalogVariants(pricing):null;
  const tierEntries = fenceVariants?fenceVariants.map((fenceVariant,index)=>({tier:{name:fenceVariant.tierName,overrides:{}},index,fenceVariant})):Array.isArray(service.tiers) && service.tiers.length
    ? service.tiers.map((tier, index) => ({ tier, index }))
    : [{ tier: { name: null, overrides: {} }, index: null }];
  const variants = tierEntries.map(({ tier, index, fenceVariant }) => {
    try {
      if(fenceVariant){
        const {fenceOfferings,heightRows,...base}=fenceVariant.pricing;
        const selected={...base,heightRows:{[fenceVariant.rowKey]:fenceVariant.row}};
        const scenarios=offeringActivationScenarios(service.serviceType,selected,service);
        const result=evaluateActivationVariant(service,selected,tier.name,index,defaultValidation.ok?businessDefaults:null,{...options,productScenarios:scenarios});
        return {...result,products:[{...result,selection:{fenceType:fenceVariant.type,fenceHeight:fenceVariant.height}}]};
      }
      return evaluateActivationVariant(service, mergePricingForValidationVNext(pricing, tier.overrides || {}), tier.name, index, defaultValidation.ok ? businessDefaults : null, options);
    } catch {
      const path = index === null ? 'pricing' : `tiers.${index}.overrides`;
      return {
        ok: false,
        tierName: tier.name,
        tierIndex: index,
        diagnostics: [{ type: 'invalid', kind: 'tier_pricing', path, message: 'Tier pricing contains values that cannot be validated safely.' }],
        reviewReason: 'Tier pricing contains values that cannot be validated safely.'
      };
    }
  });
  const validVariants = variants.filter(variant => variant.ok);
  const statusVariants = variants.map(variant => {
    const diagnostics = conditionStatusDiagnostics(variant);
    return { ...variant, diagnostics, reviewReason: diagnostics === variant.diagnostics ? variant.reviewReason : diagnostics[0]?.message || variant.reviewReason };
  });
  const failedTierDiagnostics = statusVariants.filter(variant => !variant.ok).map(variant => ({
    tierName: variant.tierName,
    reviewReason: variant.reviewReason,
    missingOwnerFields: [...new Set(variant.diagnostics.filter(item => item.type === 'missing').map(item => item.path))],
    invalidOwnerFields: [...new Set(variant.diagnostics.filter(item => ['invalid', 'unsupported', 'cross_field', 'owner_decision'].includes(item.type)).map(item => item.path))],
    unsupportedOwnerFields: [...new Set(variant.diagnostics.filter(item => item.type === 'unsupported').map(item => item.path))],
    crossFieldOwnerFields: [...new Set(variant.diagnostics.filter(item => item.type === 'cross_field').map(item => item.path))],
    ownerDiagnostics: variant.diagnostics,
    ownerDecisionRequired: variant.diagnostics.filter(item => item.type === 'owner_decision').map(({ path, kind, message }) => ({ path, kind, message })),
    validationMessages: variant.diagnostics.map(item => item.message)
  }));
  if (!validVariants.length) diagnostics.push(...statusVariants.flatMap(variant => variant.diagnostics));
  return {...statusFromDiagnostics(service, diagnostics, failedTierDiagnostics, validVariants.map(variant => variant.tierName)),scopeCoverage:scopeCoverageForService(service,businessDefaults),productCoverage:variants.flatMap(variant=>(variant.products||[]).map(product=>productStatusCoverage(variant,product))),
    ...(fenceType(service.serviceType)&&configuredOffering(service.serviceType,pricing)&&!fenceCatalog(pricing)&&!pricing.heightRows?{fenceHeightNotice:'Only the saved fence height is priced. Add rows for the other heights you build.'}:{})};
}
function serviceIdentity(service) {
  if (!isPlainRecord(service)) return null;
  if (service.serviceType === 'CUSTOM') {
    const name = typeof service.service === 'string' ? service.service.trim().toLowerCase() : '';
    return name ? `CUSTOM:${name}` : null;
  }
  return SERVICE_TYPES.includes(service.serviceType) ? `BUILTIN:${service.serviceType}` : null;
}

export function vNextPricebookStatuses(pricebook) {
  if (!isPlainRecord(pricebook)) return [];
  const snapshot = snapshotPlainData(pricebook, 'pricebook');
  if (!snapshot.ok) return [statusFromDiagnostics(null, [{
    type: 'invalid', kind: 'pricebook', path: snapshot.errorPath,
    message: `Price book could not be read safely: ${snapshot.reason}.`
  }])];
  const blockingPricebookPath = snapshot.nonPlainPaths[0];
  if (blockingPricebookPath) {
    const path = blockingPricebookPath;
    return [statusFromDiagnostics(null, [{
      type: 'invalid', kind: 'pricebook', path,
      message: `${path} must be a plain data value.`
    }])];
  }
  pricebook = snapshot.value;
  const services = isPlainRecord(pricebook) && Array.isArray(pricebook.services) ? pricebook.services : [];
  const servicesIssue = denseArrayIssue(services);
  if (servicesIssue) {
    const path = servicesIssue.path ? `pricebook.services.${servicesIssue.path}` : 'pricebook.services';
    return [statusFromDiagnostics(null, [{
      type: 'invalid', kind: 'pricebook_services', path,
      message: `Price book services are invalid at ${path}: ${servicesIssue.reason}.`
    }])];
  }
  const defaultSource = isPlainRecord(pricebook) && Object.hasOwn(pricebook, 'defaults') ? pricebook.defaults : {};
  const defaultValidation = validateBusinessDefaults(defaultSource);
  const defaultDiagnostics = defaultValidation.diagnostics.map(item => ({
    ...item,
    path: item.path === 'businessDefaults' || item.path.startsWith('businessDefaults.') ? item.path : `businessDefaults.${item.path}`
  }));
  const identities = Array.from(services, serviceIdentity);
  const counts = new Map();
  for (const identity of identities) if (identity) counts.set(identity, (counts.get(identity) || 0) + 1);

  const duplicateIds = duplicateServiceIdDiagnostics(services);
  return Array.from(services, (service, index) => {
    const status = vNextServiceStatus(service, defaultSource);
    const fenceNames=fenceType(service?.serviceType)?fenceOfferingEntries(service.pricing||{}).map(([key])=>key):null;
    const ambiguous=fenceNames?services.some((other,i)=>i!==index&&other.serviceType===service.serviceType&&fenceOfferingEntries(other.pricing||{}).some(([key])=>fenceNames.includes(key))):identities[index]&&counts.get(identities[index])>1;
    const duplicateDiagnostics = ambiguous
      ? [{ type: 'invalid', kind: 'duplicate_service', path: `services.${index}`, message: 'Price book contains an ambiguous duplicate service definition.' }]
      : [];
    const diagnostics = uniqueStatusDiagnostics([...status.ownerDiagnostics, ...defaultDiagnostics, ...duplicateDiagnostics, ...duplicateIds.filter(d=>d.path===`services.${index}.id`)]);
    const invalidTypes = new Set(['invalid', 'unsupported', 'cross_field', 'owner_decision']);
    return {
      ...status,
      status: diagnostics.length ? 'NEEDS PRICING' : status.status,
      missingOwnerFields: [...new Set([...status.missingOwnerFields, ...diagnostics.filter(item => item.type === 'missing').map(item => item.path)])],
      invalidOwnerFields: [...new Set([...status.invalidOwnerFields, ...diagnostics.filter(item => invalidTypes.has(item.type)).map(item => item.path)])],
      unsupportedOwnerFields: [...new Set([...(status.unsupportedOwnerFields || []), ...diagnostics.filter(item => item.type === 'unsupported').map(item => item.path)])],
      crossFieldOwnerFields: [...new Set([...(status.crossFieldOwnerFields || []), ...diagnostics.filter(item => item.type === 'cross_field').map(item => item.path)])],
      ownerDiagnostics: diagnostics,
      validationErrors: [...new Set(diagnostics.map(item => item.message))]
    };
  });
}

function duplicateServiceIdDiagnostics(services) {
  const groups=new Map(),out=[];
  services.forEach((service,index)=>{if(!validServiceIdVNext(service?.id))return;const id=service.id.toLowerCase();if(!groups.has(id))groups.set(id,[]);groups.get(id).push(index);});
  for(const indexes of groups.values())if(indexes.length>1)for(const index of indexes)out.push({type:'invalid',kind:'duplicate_service_id',path:'services.'+index+'.id',message:'A persisted service UUID must identify exactly one service in this price book.'});
  return out;
}

export function validateVNextPricebook(pricebook) {
  const errors = [];
  if (!isPlainRecord(pricebook)) return { ok: false, errors: ['Price book must be an object.'], statuses: [] };
  const snapshot = snapshotPlainData(pricebook, 'pricebook');
  if (!snapshot.ok) return {
    ok: false, errors: [`Price book could not be read safely at ${snapshot.errorPath}: ${snapshot.reason}.`], statuses: []
  };
  const blockingValidationPath = snapshot.nonPlainPaths[0];
  if (blockingValidationPath) {
    const path = blockingValidationPath;
    return {
      ok: false,
      errors: [`Price book contains a non-plain value at ${path}.`],
      statuses: [statusFromDiagnostics(null, [{
        type: 'invalid', kind: 'pricebook', path, message: `${path} must be a plain data value.`
      }])]
    };
  }
  pricebook = snapshot.value;
  if (!Array.isArray(pricebook.services)) return { ok: false, errors: ['Price book services must be an array.'], statuses: [] };
  const servicesIssue = denseArrayIssue(pricebook.services);
  if (servicesIssue) {
    const path = servicesIssue.path ? `pricebook.services.${servicesIssue.path}` : 'pricebook.services';
    return {
      ok: false,
      errors: [`Price book services are invalid at ${path}: ${servicesIssue.reason}.`],
      statuses: vNextPricebookStatuses(pricebook)
    };
  }
  const defaultSource = Object.hasOwn(pricebook, 'defaults') ? pricebook.defaults : {};
  const defaults = validateBusinessDefaults(defaultSource);
  errors.push(...defaults.missingFields.map(field => `businessDefaults.${field} is required.`), ...defaults.errors);
  const statuses = vNextPricebookStatuses(pricebook);
  for (const status of statuses) {
    const prefix = status.serviceType || 'UNKNOWN_SERVICE';
    errors.push(
      ...status.validationErrors.map(error => `${prefix}: ${error}`),
      ...status.missingOwnerFields.map(field => `${prefix}.${field} is required.`),
      ...status.invalidOwnerFields.map(field => `${prefix}.${field} is invalid.`)
    );
  }
  return { ok: errors.length === 0, errors: [...new Set(errors)], statuses };
}

function serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason, path, kind, diagnosticOwner = 'owner', diagnostics = null }) {
  const ownerDiagnostic = { type: 'invalid', kind, path, message: reviewReason };
  const result = {
    resultType: 'ESTIMATE_REQUIRES_REVIEW',
    engineVersion: ENGINE_VERSION,
    serviceId: null,
    serviceResolution: { status: kind === 'missing_service' ? 'missing' : ['duplicate_service','duplicate_service_id'].includes(kind) ? 'ambiguous' : 'invalid', serviceId: null },
    quoteId: crypto.randomUUID(),
    serviceType,
    submittedCustomerInputs: cloneForStatus(customerInputs, {}),
    normalizedScope: null,
    validatedMeasurements: [],
    reviewReason,
    missingCustomerFields: [],
    invalidCustomerFields: diagnosticOwner === 'customer' ? [path] : [],
    missingOwnerFields: [],
    invalidOwnerFields: diagnosticOwner === 'owner' ? diagnostics ? diagnostics.map(d=>d.path) : [path] : [],
    unsupportedOwnerFields: [],
    crossFieldOwnerFields: [],
    ownerDiagnostics: diagnosticOwner === 'owner' ? diagnostics || [ownerDiagnostic] : [],
    ownerDecisionRequired: [],
    failedTierDiagnostics: [],
    validationMessages: [reviewReason],
    inspectionFirst: false,
    appliedRules: [],
    urgencyFlags: ['ROOFING_REPAIR', 'FLAT_ROOF_REPAIR'].includes(serviceType) && customerInputs?.leakPresent === true ? ['Active leak reported'] : []
  };
  return callerType === 'owner' ? result : sanitizeForCustomerVNext(result);
}
function pricebookRequestDiagnosticOwner(path) {
  const relativePath = String(path || '').replace(/^quoteRequest\./, '');
  return /^(pricebook|feeSelections\.owner)(?:\.|$)/.test(relativePath) ? 'owner' : 'customer';
}


export function quoteFromVNextPricebook(input = {}) {
  const requestSnapshot = snapshotPlainData(input, 'quoteRequest');
  const requestIsPlainObject = requestSnapshot.ok;
  const callerDescriptor = ownDataValue(input, 'callerType');
  const fallbackRequest = { callerType: callerDescriptor.ok && callerDescriptor.value === 'owner' ? 'owner' : 'customer' };
  const {
    pricebook,
    serviceType,
    customerInputs,
    callerType = 'customer',
    feeSelections,
    currentMonth,
    allowInactiveOwnerPreview = false
  } = requestIsPlainObject ? requestSnapshot.value : fallbackRequest;
  if (!requestIsPlainObject) return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: `Quote request could not be read safely: ${requestSnapshot.reason}.`, path: requestSnapshot.errorPath, kind: 'invalid_request', diagnosticOwner: pricebookRequestDiagnosticOwner(requestSnapshot.errorPath) });
  const blockingNonPlainPath = requestSnapshot.nonPlainPaths[0];
  if (blockingNonPlainPath) {
    let path = blockingNonPlainPath;
    if (path.startsWith('quoteRequest.')) path = path.slice('quoteRequest.'.length);
    return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: 'Price-book quote request must contain only plain data objects.', path, kind: 'invalid_request', diagnosticOwner: pricebookRequestDiagnosticOwner(path) });
  }
  const unsupportedRequestField = Object.keys(requestSnapshot.value).find(field => !PRICEBOOK_QUOTE_REQUEST_FIELDS.has(field));
  if (unsupportedRequestField) return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: 'Price-book quote request contains an unsupported field.', path: `quoteRequest.${unsupportedRequestField}`, kind: 'invalid_request', diagnosticOwner: 'customer' });
  const services = isPlainRecord(pricebook) && Array.isArray(pricebook.services) ? pricebook.services : [];
  const servicesIssue = denseArrayIssue(services);
  if (servicesIssue) {
    const path = servicesIssue.path ? `pricebook.services.${servicesIssue.path}` : 'pricebook.services';
    return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: `Price book services are invalid at ${path}: ${servicesIssue.reason}.`, path, kind: 'pricebook_services' });
  }
  if (!SERVICE_TYPES.includes(serviceType)) return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: `Unsupported service type: ${serviceType}.`, path: 'serviceType', kind: 'unsupported_service', diagnosticOwner: 'customer' });
  const builtIn = serviceType !== 'CUSTOM';
  const requestedCustomService = isPlainRecord(customerInputs) && typeof customerInputs.service === 'string' ? customerInputs.service : '';
  const requestedCustomName = requestedCustomService.trim().toLowerCase();
  let matches = builtIn
    ? services.filter(entry => entry?.serviceType === serviceType)
    : services.filter(entry => entry?.serviceType === 'CUSTOM' && typeof entry.service === 'string' && entry.service.trim().toLowerCase() === requestedCustomName);
  if(fenceType(serviceType)&&matches.length>1&&customerInputs?.fenceType){
    const selected=matches.filter(entry=>fenceOfferingEntries(entry.pricing||{}).some(([type])=>type===customerInputs.fenceType));
    matches=selected.length?selected:matches.filter(entry=>!configuredOffering(serviceType,entry.pricing||{}));
  }
  if (matches.length === 0) {
    const description = builtIn ? serviceType : `custom service "${requestedCustomService}"`;
    return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: `No matching service is configured for ${description}.`, path: 'services', kind: 'missing_service' });
  }
  if (matches.length > 1) {
    const description = builtIn ? serviceType : `custom service "${requestedCustomService}"`;
    return serviceLookupReview({ serviceType, customerInputs, callerType, reviewReason: `Multiple matching service definitions make ${description} ambiguous.`, path: 'services', kind: 'duplicate_service' });
  }
  const duplicateIds=duplicateServiceIdDiagnostics(services);
  if(duplicateIds.length)return serviceLookupReview({serviceType,customerInputs,callerType,reviewReason:'Price book contains colliding persisted service identities.',path:duplicateIds[0].path,kind:'duplicate_service_id',diagnostics:duplicateIds});
  const service = matches[0];
  return generateQuoteVNext({
    serviceType: service.serviceType,
    customerInputs,
    ownerPricing: service,
    businessDefaults: isPlainRecord(pricebook) && Object.hasOwn(pricebook, 'defaults') ? pricebook.defaults : {},
    callerType,
    feeSelections,
    currentMonth,
    allowInactiveOwnerPreview
  });
}

function previewRequestFromSnapshot(input, snapshot) {
  if (!snapshot.nonPlainPaths.length) return snapshot.value;
  const request = {};
  for (const key of Object.keys(snapshot.value)) {
    const descriptor = ownDataValue(input, key);
    if (!descriptor.ok || !descriptor.present) return null;
    Object.defineProperty(request, key, {
      value: descriptor.value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  }
  return request;
}

export function previewFromVNextPricebook(input) {
  const snapshot = snapshotPlainData(input, 'quoteRequest');
  if (!snapshot.ok) return quoteFromVNextPricebook(input);
  const request = previewRequestFromSnapshot(input, snapshot);
  if (!request) return quoteFromVNextPricebook(input);
  return quoteFromVNextPricebook({ ...request, callerType: 'owner', allowInactiveOwnerPreview: true });
}

export function reviewOnlyScopesVNext(serviceType) {
  const definitions = [];
  const add = (when, inputs, fields, always = false) => definitions.push({when, inputs, fields, always});
  if (serviceType.startsWith('FLOORING_')) add('Stairs selected', {stairSteps:1}, ['perStepPrice']);
  if (serviceType === 'SIDING_REPLACEMENT') {
    add('Existing siding removal selected', {oldSidingRemoval:true}, ['removalPerSqft','disposalPerSqft']);
    add('Trim selected', {trimIncluded:true}, ['trimPerLinearFoot']);
  }
  if (serviceType.startsWith('CONCRETE_')) {
    add('Demolition selected', {demolitionNeeded:true}, ['demolitionPerSqft','disposalPerSqft']);
    add('Exposed aggregate selected', {finishType:'exposed_aggregate'}, ['finishMultiplier']);
  }
  if (serviceType === 'FLAT_ROOF_REPLACEMENT') for(const layer of ['insulation','coverboard'])add(layer+' scope', {[layer+'Needed']:true}, ['insulationPerSqft']);
  if (serviceType.startsWith('FENCING_')) add('Every fence request', {}, [], true);
  if (serviceType === 'EXTERIOR_PAINTING') add('Every exterior painting request', {}, [], true);
  return definitions.map(({inputs, ...entry}) => ({...entry, ownerDecisions: uniqueStatusDiagnostics([
    ...inspectionOwnerDecisionsVNext(serviceType, inputs),
    ...validateOwnerPricing(serviceType, inputs, {}, {}).ownerDecisionRequired
  ])}));
}

function fieldCopy(serviceType, field) {
  if(['paintingSettings','paintingRates','surfaceExtraRates','sidingSettings'].includes(field))return {label:{paintingSettings:'Painting coats and height bands',paintingRates:'Additional painting component prices',surfaceExtraRates:'Optional surface work prices',sidingSettings:'Siding measurement conventions'}[field],type:'surface_configuration',help:'Optional owner-entered settings. No starting ratios or prices are supplied.'};
  if(field==='installedLaborPercent')return {label:'Labor portion of installed prices',help:'Owner-set percentages used for labor adjustments.'};
  if(field==='installedMaterialsPercent')return {label:'Materials share of installed prices',help:'Owner-set percentages used for materials-only tax.'};
  if(['scopeDetails','scopeRates'].includes(field))return {label:field==='scopeDetails'?'Additional priced scope':'Additional scope prices',help:'Explicit owner-defined work, inclusions and measured prices.'};
  if(['offeringMode','offeringDetails','offeringRates'].includes(field))return NEW_FIELD_COPY[field];
  const scopes = reviewOnlyScopesVNext(serviceType).filter(scope => scope.always || scope.fields.includes(field));
  if (scopes.length) return {
    label: (NEW_FIELD_COPY[field]?.label || ownerFieldCopy(serviceType, field).title || ownerFieldCopy(serviceType, field).label || field) + ' — review only',
    help: scopes.map(scope => scope.when + ': this legacy scalar alone is incomplete. Configure the work under Additional priced scope (or Fence and painting offering). ' + scope.ownerDecisions.map(d => d.message).join(' ')).join(' '),
    reviewOnly: true,
    ownerDecisions: scopes.flatMap(scope => scope.ownerDecisions)
  };
  if (serviceType === 'FLAT_ROOF_REPLACEMENT' && ['laborPerSqft','membraneCostPerSqft','tearOffPerSqft'].includes(field)) return {
    label: {laborPerSqft:'Installation labor price per square foot by replacement membrane',membraneCostPerSqft:'Material price per square foot by replacement membrane',tearOffPerSqft:'Tear-off labor price per square foot by existing membrane'}[field],
    help:'Enter named, identified membrane rates. Unknown materials require verification; no fallback rate is used.'
  };
  if (NEW_FIELD_COPY[field]) return NEW_FIELD_COPY[field];
  const current = ownerFieldCopy(serviceType, field);
  return {
    label: current.title || current.label,
    help: current.help,
    ...(current.definition ? { definition: current.definition } : {})
  };
}

export function getVNextPriceBookMetadata() {
  return contractMetadata().map(contract => ({
    ...contract,
    customerFields:contract.customerFields.filter(field=>field.name!=='permitRequired'),
    ...(OFFERING_TYPES.includes(contract.serviceType)?{
      offeringCustomerFields:Object.fromEntries(['installed','itemized'].map(mode=>[mode,Object.entries(offeringContract(contract.serviceType,{offeringMode:mode}).fields).filter(([name])=>name!=='permitRequired').map(([name,field])=>({name,...field}))])),
      offeringRateFields:Object.fromEntries(['installed','itemized'].map(mode=>[mode,offeringRateDefinitions(contract.serviceType,{offeringMode:mode,offeringDetails:{primerCoats:1,ceilingsOffered:true,ceilingPrimerCoats:1,trimOffered:true,removalOffered:true}})]))
    }:{}),
    service: SERVICE_NAMES[contract.serviceType],
    supportsScopeConfiguration:Object.keys(scopeDefinitions(contract.serviceType,{materialCostPerSquare:{configured_roof_type:1}})).length>0,
    reviewOnlyScopes: reviewOnlyScopesVNext(contract.serviceType),
    pricingFields: contract.allowedPricingFields.filter(field => !contract.class2Fields.some(definition => definition.name === field)).map(field => ({ field, ...fieldCopy(contract.serviceType, field) })),
    ruleFields: ['priceBasisByCategory', 'taxabilityByCategory', 'feeRules', 'knownOfferings', 'origin', 'zeroPricePolicy', ...(contract.serviceType === 'LANDSCAPING_SOD' ? ['disposalScope'] : [])].map(field => ({ field, ...NEW_FIELD_COPY[field] })),
    class2Fields: contract.class2Fields.filter(definition=>!(contract.serviceType==='LANDSCAPING_PLANTING'&&definition.name==='mulchOverageFactor')).map(definition => ({
      ...definition,
      help: `Owner-editable ${definition.unit} control for ${definition.label.toLowerCase()}. The exact value used is recorded in the internal calculation evidence. ${NEW_FIELD_COPY[definition.name]?.help || reviewOnlyScopesVNext(contract.serviceType).map(scope => scope.when + ' requires a configured owner scope.').join(' ')}`
    }))
  }));
}

export function materializeVNextService(service) {
  const snapshot = snapshotPlainData(service, 'service');
  if (!snapshot.ok) {
    if (!isPlainRecord(service)) throw new TypeError('Service must be an object.');
    throw new TypeError(`Service could not be read safely at ${snapshot.errorPath}: ${snapshot.reason}.`);
  }
  if (snapshot.nonPlainPaths.length) {
    const path = snapshot.nonPlainPaths[0];
    throw new TypeError(`Service must contain only plain data objects; ${path} is not plain data.`);
  }
  service = snapshot.value;
  if (!isPlainRecord(service)) throw new TypeError('Service must be an object.');
  if (!SERVICE_TYPES.includes(service.serviceType)) throw new TypeError('Service type is unsupported.');
  if (service.pricing !== undefined && !isPlainRecord(service.pricing)) throw new TypeError('Service pricing must be an object.');
  const next = canonicalServiceIdentityVNext(service);
  next.pricing ||= {};
  for (const [field, definition] of Object.entries(CLASS2_DEFINITIONS[next.serviceType] || {})) {
    if (next.pricing[field] === undefined) next.pricing[field] = structuredClone(definition.defaultValue);
  }
  return next;
}
