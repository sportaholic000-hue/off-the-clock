import {registeredProductKey} from '../../server/productNames.js';
import {customerFieldVisible,customerFieldForInputs,clearChangedScopeConfirmations} from '../../server/scopeConfiguration.js';
import React,{useEffect,useRef,useState} from 'react';
import {Field,Select,TextInput,Button,Notice,Textarea,ErrorMessage} from './ui.jsx';
import {ExactNumericInput,FenceHeightInput} from './pricebookInputs.jsx';
import {FenceRunsInput} from './FenceRunsInput.jsx';
import {fenceCatalog,fenceTierKeys} from '../../server/quote-engine-vnext/fencePricing.js';
import {treeKeysAt,requiredTreeKeysAt} from '../../server/priceBookTree.js';
import {humanPricingKey,productKeyFromName,DUPLICATE_NAME_MESSAGE} from './pricebookFormatting.js';
import {parseOwnerNumericInput} from '../../server/priceBookMoney.js';
import {api} from './api.js';
import {isRevisionConflict} from './pricebookConflict.js';
import {changeFeeRule,removeOwnerFeeSelection,outdatedOwnerFeeSelections,approvalMatchesDraft} from './pricebookEditing.js';
import {reviewRows,reviewLabel,priceChoices,displayAmount,retainedRows} from './pricebookReview.js';
const human=humanPricingKey;
const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
const treeLabel=key=>/[A-Z]/.test(key)?humanPricingKey(key):human(key);
const own=(value,key)=>Object.hasOwn(value||{},key);

export function PricingTree({value,onChange,definition,level=1,label=definition.label}) {
 const tree=definition.tree||{},depth=tree.depth||1;
 const map=value&&typeof value==='object'&&!Array.isArray(value)?value:{};
 const [newKey,setNewKey]=useState(''),[keyError,setKeyError]=useState('');
 const allowed=treeKeysAt(tree,level),required=requiredTreeKeysAt(tree,level);
 const keys=[...new Set([...Object.keys(map),...required])];
 const available=allowed?.filter(key=>!own(map,key)&&!required.includes(key));
 const update=(key,item)=>{const next={...map};if(item===undefined)delete next[key];else next[key]=item;onChange(item===undefined&&!Object.keys(next).length&&!tree.allowEmpty?undefined:next);};
 return <div className="field-stack">{tree.allowEmpty&&!keys.length&&<small>{available?.length?'No allocation percentages entered. Add a listed installed price only when you want to classify its labor or materials portion; this empty allocation map can be saved explicitly.':'No installed prices currently need a materials or labor allocation. This empty allocation map can be saved explicitly.'}</small>}{keys.map(key=><div key={key}>
  {level<depth?<><strong>{treeLabel(key)}</strong><PricingTree value={map[key]} onChange={v=>update(key,v)} definition={definition} level={level+1} label={label+' '+treeLabel(key)}/></>:
   <Field label={tree.leafLabels?.[key]||treeLabel(key)}>{tree.leafType==='enum'?<Select aria-label={label+' '+treeLabel(key)} value={map[key]??''} onChange={e=>update(key,e.target.value||undefined)}><option value="">Choose</option>{tree.options.map(v=><option key={v} value={v}>{human(v)}</option>)}</Select>:
    tree.leafType==='boolean'?<Select aria-label={label+' '+treeLabel(key)} value={map[key]===undefined?'':String(map[key])} onChange={e=>update(key,e.target.value===''?undefined:e.target.value==='true')}><option value="">Choose</option><option value="true">Yes</option><option value="false">No</option></Select>:
    <ExactNumericInput aria-label={label+' '+treeLabel(key)} value={map[key]} kind={tree.leafMoneyKinds?.[key]??definition.moneyKind} wholeCents={definition.wholeCents} onChange={v=>update(key,v)}/>}</Field>}
   {!required.includes(key)&&<Button variant="quiet" onClick={()=>update(key,undefined)}>Remove {treeLabel(key)}</Button>}
 </div>)}{(!allowed||available.length>0)&&<div className="field-stack">{allowed?<Select aria-label={label+' product name'} value={newKey} onChange={e=>setNewKey(e.target.value)}><option value="">Choose</option>{available.map(key=><option key={key} value={key}>{treeLabel(key)}</option>)}</Select>:<TextInput aria-label={label+' product name'} value={newKey} onChange={e=>{setNewKey(e.target.value);setKeyError('');}}/>}<Button variant="secondary" onClick={()=>{const named=allowed?{key:newKey}:productKeyFromName(newKey),key=named.key;if(named.error){setKeyError(named.error);return;}if(own(map,key)){setKeyError(DUPLICATE_NAME_MESSAGE);return;}if(allowed&&!available.includes(key))return;update(key,level<depth?{}:null);setNewKey('');setKeyError('');}}>Add offering</Button>{keyError&&<span className="field-error" role="alert">{keyError}</span>}<small>Use the same product name in its labor and material prices and in Registered products.</small></div>}</div>;
}

// Coordinates may be negative. Reuse the exact decimal parser for the magnitude;
// never turn an incomplete or unrepresentable entry into a previous valid point.
function parseCoordinate(raw) {
 const text=String(raw??'').trim();
 if(!text)return undefined;
 const negative=text.startsWith('-'),magnitude=negative?text.slice(1):text;
 if(negative&&(!magnitude||/^[+\s-]/.test(magnitude)))throw Error('Enter a finite decimal coordinate.');
 const number=parseOwnerNumericInput(magnitude);
 if(number===undefined)throw Error('Enter a finite decimal coordinate.');
 return negative?-number:number;
}
function CoordinateInput({value,onChange,...props}) {
 const [raw,setRaw]=useState(value===undefined?'':String(value)),[error,setError]=useState(''),emitted=useRef(value);
 useEffect(()=>{const text=value===undefined?'':String(value);if(!Object.is(value,emitted.current)){emitted.current=value;setRaw(text);}try{parseCoordinate(text);setError('');}catch(e){setError(e.message);}},[value]);
 function change(text){setRaw(text);try{const next=parseCoordinate(text);setError('');emitted.current=next;onChange(next);}catch(e){setError(e.message);emitted.current=text;onChange(text);}}
 return <><TextInput {...props} type="text" inputMode="decimal" value={raw} aria-invalid={Boolean(error)} onChange={e=>change(e.target.value)}/>{error&&<span className="field-error" role="alert">{error}</span>}</>;
}
function MeasuredOutline({field,value,onChange}) {
 const points=Array.isArray(value)?value:[];
 function edit(index,axis,next){onChange(points.map((point,i)=>{if(i!==index)return point;const updated={...point};if(next===undefined)delete updated[axis];else updated[axis]=next;return updated;}));}
 return <div className="field-stack"><small>Enter every measured corner in order, in feet, then repeat the first point to close the outline. Use straight horizontal or vertical edges only. Negative coordinates are allowed. Missing or conflicting measurements require review.</small>
 {points.map((point,i)=><div key={i} className="field-stack">{['x','y'].map(axis=><Field key={axis} label={'Point '+(i+1)+' '+axis.toUpperCase()+' (ft)'}><CoordinateInput aria-label={field.label+' point '+(i+1)+' '+axis.toUpperCase()+' (ft)'} value={point[axis]} onChange={next=>edit(i,axis,next)}/></Field>)}<Button variant="quiet" onClick={()=>onChange(points.filter((_,index)=>index!==i))}>Remove point {i+1}</Button></div>)}
 <Button variant="secondary" onClick={()=>onChange([...points,{}])}>Add measured point</Button></div>;
}

// A native choice list supports both selecting and typing a product name. The
// same exact (non-fuzzy) matcher binds phone answers; only the checkbox issues
// the product confirmation receipt, and every edit clears it in update().
function ProductMeasurement({field,value,registered,update,onChange}) {
 const keys=Object.keys(registered),key=registeredProductKey(value[field.name],keys);
 const label=k=>k.replaceAll('_',' ').replace(/^./,first=>first.toUpperCase());
 const fact=value.confirmedFacts?.[field.name];
 // Preserve typed text until confirmation, including a trailing space after a
 // registered name that is also the beginning of a longer product name.
 return <><TextInput aria-label={field.label} list={'offerings-'+field.name} value={key&&value[field.name]===key?label(key):value[field.name]??''}
  onChange={event=>update(field.name,event.target.value||undefined)}/>
  <datalist id={'offerings-'+field.name}>{keys.map(k=><option key={k} value={label(k)}/>)}</datalist>
  {key&&<label><input type="checkbox" checked={fact?.status==='identified'&&fact?.value===key&&fact?.offeringId===registered[key]}
   onChange={event=>{const confirmedFacts={...(value.confirmedFacts||{})};
    if(event.target.checked)confirmedFacts[field.name]={field:field.name,value:key,status:'identified',offeringId:registered[key]};else delete confirmedFacts[field.name];
    onChange({...value,[field.name]:key,confirmedFacts});}}/> I have identified this exact offering.</label>}
 </>;
}

export function CustomerMeasurements({fields=[],scopeFields=fields,value={},onChange,knownOfferings={}}) {
 const fencing=fields.some(f=>f.type==='fence_runs');
 const [totalOnly,setTotalOnly]=useState(value.fenceRuns===undefined&&value.linearFeet!==undefined);
 const sectionMode=fencing&&!totalOnly;
 const measuredRuns=value.fenceRuns||Array.from({length:Number.isSafeInteger(value.fenceRunCount)&&value.fenceRunCount>0&&value.fenceRunCount<=1000?value.fenceRunCount:1},()=>({sections:[{}]}));
 const layoutChange=(runs,{removedRun=false}={})=>{const next={...value,fenceRuns:runs,fenceRunCount:removedRun||value.fenceRunCount===undefined?runs.length:value.fenceRunCount};for(const k of ['linearFeet','gates','cornerCount','lfMethod'])delete next[k];onChange(clearChangedScopeConfirmations(scopeFields,value,next));};
 const update=(name,next)=>{const updated={...value};if(next===undefined)delete updated[name];else updated[name]=next;
  if(name==='areaInputMethod'&&next!==value.areaInputMethod&&fields.some(f=>f.type==='surface_rows'))for(const key of ['wallAreaSqft','exteriorAreaSqft','sidingAreaSqft','rooms','buildingPerimeterFeet','doorCount','windowCount','garageDoorCount','garageDoorWidthFeet','garageDoorHeightFeet','garageOpenings','gables','largeOpenings','ceilingAreaSqft','wallHeightFeet'])delete updated[key];
  if(sectionMode&&name==='fenceRunCount'){
   if(Number.isSafeInteger(next)&&next>=1&&next<=1000)updated.fenceRuns=Array.from({length:Math.max(next,measuredRuns.length)},(_,i)=>measuredRuns[i]||{sections:[{}]});
   for(const k of ['linearFeet','gates','cornerCount','lfMethod'])delete updated[k];
  }
  if(own(updated.confirmedFacts,name)){updated.confirmedFacts={...updated.confirmedFacts};delete updated.confirmedFacts[name];if(!Object.keys(updated.confirmedFacts).length)delete updated.confirmedFacts;}
  onChange(clearChangedScopeConfirmations(scopeFields,value,updated));
 };
 return <div className="field-stack">{fencing&&<Button variant="secondary" onClick={()=>{setTotalOnly(!totalOnly);const next={...value};for(const k of ['linearFeet','gates','cornerCount','lfMethod','fenceRuns'])delete next[k];onChange(next);}}>{totalOnly?'Use section measurements':'I only know the total length'}</Button>}{fields.filter(f=>f.type!=='confirmed_facts'&&f.name!=='permitRequired'&&(!fencing||(sectionMode?!['linearFeet','gates','cornerCount','lfMethod'].includes(f.name):f.name!=='fenceRuns'))&&customerFieldVisible(f,value)).map(f=>customerFieldForInputs(f,value)).map(f=><div key={f.name} className="field"><span className="field-label">{f.label}</span>{f.unit&&<span className="field-help">{f.unit}</span>}{f.details?.map((detail,i)=><p className="field-help" key={i}>{detail}</p>)}
  {f.type==='boolean'?<Select aria-label={f.label} value={value[f.name]===undefined?'':String(value[f.name])} onChange={e=>update(f.name,e.target.value===''?undefined:e.target.value==='true')}><option value="">Unknown / not supplied</option><option value="true">Yes</option><option value="false">No</option></Select>:
   f.type==='enum'?<Select aria-label={f.label} value={value[f.name]??''} onChange={e=>update(f.name,e.target.value===''?undefined:f.values.find(v=>String(v)===e.target.value))}><option value="">Unknown / not supplied</option>{(f.values||[]).map(v=><option key={v} value={v}>{f.optionLabels?.[v]||human(v)}</option>)}</Select>:
   f.type==='integer_or_unknown'?<Select aria-label={f.label} value={value[f.name]??''} onChange={e=>update(f.name,e.target.value===''?undefined:e.target.value==='unknown'?'unknown':Number(e.target.value))}><option value="">Not supplied</option><option value="unknown">Unknown — requires review</option>{Array.from({length:f.max-f.min+1},(_,i)=>f.min+i).map(n=><option key={n} value={n}>{n}</option>)}</Select>:
   f.type==='orthogonal_outline'?<MeasuredOutline field={f} value={value[f.name]} onChange={v=>update(f.name,v)}/>:
   f.type==='surface_rows'?<SurfaceRowsInput field={f} value={value[f.name]} onChange={v=>update(f.name,v)}/>:
   f.type==='fence_runs'?<FenceRunsInput field={f} runs={measuredRuns} runCount={value.fenceRunCount} onChange={layoutChange}/>:
   f.type==='string'?<TextInput aria-label={f.label} value={value[f.name]??''} onChange={e=>update(f.name,e.target.value||undefined)}/>:
   f.type==='offering_counts'?<>{(f.values||[]).map(key=><Field key={key} label={f.options?.[key]||human(key)}><ExactNumericInput aria-label={'Gate count '+key} value={value[f.name]?.[key]} onChange={v=>{const next={...(value[f.name]||{})};if(v===undefined)delete next[key];else next[key]=v;update(f.name,next);}}/></Field>)}<Button variant="secondary" onClick={()=>update(f.name,{})}>No gates</Button>{value[f.name]&&Object.values(value[f.name]).every(n=>n===0)&&<span>No gates selected</span>}</>:
   f.type==='plant_counts'?<>{['small','medium','large'].map(size=><Field key={size} label={human(size)}><ExactNumericInput aria-label={f.label+' '+human(size)} value={value[f.name]?.[size]} onChange={v=>{const next={...(value[f.name]||{})};if(v===undefined)delete next[size];else next[size]=v;update(f.name,next);}}/></Field>)}</>:
   f.type==='slug'?<ProductMeasurement field={f} value={value} registered={knownOfferings[f.name]||{}} update={update} onChange={onChange}/>:
   f.name==='fenceHeight'?<FenceHeightInput label={f.label} value={value[f.name]} onChange={v=>update(f.name,v)}/>:f.type==='number'?<ExactNumericInput aria-label={f.label} value={value[f.name]} onChange={v=>update(f.name,v)}/>:<Notice>This measurement requires owner review.</Notice>}
 </div>)}</div>;
}

export function ServiceStatusNotices({status}) {
 if(status.status==='DISABLED')return null;
 // A null tier is the engine's synthetic base offering, not a price option.
 const failedOptions=(status.failedTierDiagnostics||[]).filter(option=>option.tierName);
 return <>{status.fenceHeightNotice&&<Notice>{status.fenceHeightNotice}</Notice>}{status.statusNotices?.map(notice=><Notice key={notice}>{notice}</Notice>)}{!!failedOptions.length&&<section className="scope-coverage" aria-label="Price options not offered to customers"><h3>Price options not offered to customers</h3><ul>{failedOptions.map((option,index)=><li key={index}><strong>{option.tierName||'Unnamed option'}</strong><span>{option.ownerFieldLabels?.join('; ')||'Saved price option settings'}. {withheldOptionReason(option)}</span></li>)}</ul></section>}</>;
}

function withheldOptionReason(option) {
 const diagnostics=option.ownerDiagnostics||[];
 if(diagnostics.some(d=>d.kind?.includes('zero')||d.path?.startsWith('zeroPricePolicy')))return 'A zero price needs an explicit included or free choice; otherwise enter a positive price.';
 if(option.crossFieldOwnerFields?.length||diagnostics.some(d=>d.type==='cross_field'))return 'These settings conflict. Correct them before offering this option.';
 if(option.unsupportedOwnerFields?.length||diagnostics.some(d=>d.type==='unsupported'))return 'This option contains unsupported settings. Remove or replace them.';
 if(option.invalidOwnerFields?.length||diagnostics.some(d=>d.type==='invalid'))return 'A saved value is invalid. Correct it before offering this option.';
 if(option.missingOwnerFields?.length)return 'Required pricing or configuration is missing. Complete it before offering this option.';
 return 'Review and confirm this option’s configuration before offering it.';
}

export function priceOptionChipText(status) {
 const withheld=status.failedTierDiagnostics?.length||0,total=withheld+(status.validTierNames?.length||0);
 return status.status==='QUOTING LIVE'&&withheld?`QUOTING LIVE — ${withheld} of ${total} options not offered`:status.status;
}

export function ServiceRules({service,services=[],meta,categories=[],feeNames=[],feeModes=[],defaults,onService,onDefault}) {
  const [offering,setOffering]=useState({}),[offeringError,setOfferingError]=useState({});
 const needsQuoteTimeZone=!defaults.quoteTimeZone&&[defaults.peakMonths,service.peakMonths,...services.map(s=>s.peakMonths)].some(months=>Array.isArray(months)&&months.length>0);
 const label=name=>meta.ruleFields?.find(f=>f.field===name)?.label||name;
 const setMap=(name,key,value)=>onService({...service,[name]:{...(service[name]||{}),[key]:value}});
 return <section className="editor-section"><h2>Quote configuration</h2>
  <p>Choose each rate meaning, tax treatment and charge rule. Missing decisions keep customer requests in review.</p>
  <div className="matrix-scroll"><table className="pricing-matrix"><thead><tr><th>Category</th><th>{label('priceBasisByCategory')}</th><th>{label('taxabilityByCategory')}</th><th>Apply markup / margin</th></tr></thead><tbody>{categories.map(category=><tr key={category}><th>{human(category)}</th><td><Select aria-label={category+' price basis'} value={service.priceBasisByCategory?.[category]||''} onChange={e=>setMap('priceBasisByCategory',category,e.target.value)}><option value="">Choose</option><option value="cost">Owner cost</option><option value="sell_price">Final sell price</option></Select></td><td><Select aria-label={category+' taxability'} value={service.taxabilityByCategory?.[category]===undefined?'':String(service.taxabilityByCategory[category])} onChange={e=>setMap('taxabilityByCategory',category,e.target.value===''?undefined:e.target.value==='true')}><option value="">Choose</option><option value="true">Taxable</option><option value="false">Not taxable</option></Select></td><td><Select aria-label={category+' markup applies'} value={defaults.markupApplies?.[category]===undefined?'':String(defaults.markupApplies[category])} onChange={e=>onDefault('markupApplies',{...(defaults.markupApplies||{}),[category]:e.target.value===''?undefined:e.target.value==='true'})}><option value="">Choose</option><option value="true">Yes</option><option value="false">No</option></Select></td></tr>)}</tbody></table></div>
  <h3>{label('feeRules')}</h3>{feeNames.map(fee=><Field key={fee} label={human(fee)}><Select aria-label={fee+' fee rule'} value={service.feeRules?.[fee]||''} onChange={e=>onService(changeFeeRule(service,fee,e.target.value))}><option value="">Choose</option>{fee==='permit'&&['when_scope_selected','customer_selected'].includes(service.feeRules?.permit)&&<option value={service.feeRules.permit} disabled>Choose an owner-controlled permit rule</option>}{feeModes.filter(mode=>fee!=='permit'||!['when_scope_selected','customer_selected'].includes(mode)).map(mode=><option key={mode} value={mode}>{human(mode)}</option>)}</Select>{service.feeRules?.[fee]==='owner_selected'&&<Field label="Apply this owner-selected fee"><Select aria-label={fee+' owner fee selection'} value={service.ownerFeeSelections?.[fee]===undefined?'':String(service.ownerFeeSelections[fee])} onChange={e=>e.target.value===''?onService(removeOwnerFeeSelection(service,fee)):setMap('ownerFeeSelections',fee,e.target.value==='true')}><option value="">Choose</option><option value="true">Yes</option><option value="false">No</option></Select></Field>}</Field>)}
  {outdatedOwnerFeeSelections(service).map(fee=><Notice key={'outdated-'+fee} tone="warning">The saved {human(fee)} answer ({service.ownerFeeSelections[fee]===false?'No':service.ownerFeeSelections[fee]===true?'Yes':'unrecognized'}) does not match its current fee rule. Remove the outdated answer, or choose the owner-selected rule to keep it. <Button variant="secondary" onClick={()=>onService(removeOwnerFeeSelection(service,fee))}>Remove outdated {human(fee)} answer</Button></Notice>)}
  {meta.customerFields?.some(f=>f.type==='slug')&&<><h3>{label('knownOfferings')}</h3><p>Register only offerings you actually recognize. A product name in a price table does not automatically register that product.</p>{meta.customerFields.filter(f=>f.type==='slug').map(f=><div key={f.name}><strong>{f.label}</strong>{Object.entries(service.knownOfferings?.[f.name]||{}).map(([key,id])=><p key={key}>{human(key)} <Button variant="quiet" onClick={()=>{const entries={...service.knownOfferings[f.name]};delete entries[key];onService({...service,knownOfferings:{...service.knownOfferings,[f.name]:entries}});}}>Remove</Button></p>)}<TextInput aria-label={f.label+' product name'} value={offering[f.name]||''} onChange={e=>{setOffering({...offering,[f.name]:e.target.value});setOfferingError({...offeringError,[f.name]:''});}}/><Button variant="secondary" onClick={()=>{const {key,error}=productKeyFromName(offering[f.name]||'');if(error){setOfferingError({...offeringError,[f.name]:error});return;}if(own(service.knownOfferings?.[f.name],key)){setOfferingError({...offeringError,[f.name]:DUPLICATE_NAME_MESSAGE});return;}onService({...service,knownOfferings:{...(service.knownOfferings||{}),[f.name]:{...(service.knownOfferings?.[f.name]||{}),[key]:crypto.randomUUID()}}});setOffering({...offering,[f.name]:''});setOfferingError({...offeringError,[f.name]:''});}}>Register offering</Button>{offeringError[f.name]&&<span className="field-error" role="alert">{offeringError[f.name]}</span>}</div>)}</>}
  {service.serviceType==='LANDSCAPING_SOD'&&<Field label={label('disposalScope')}><Select value={service.disposalScope||''} onChange={e=>onService({...service,disposalScope:e.target.value||undefined})}><option value="">Not configured</option><option value="separate_project_debris">Separate project debris</option></Select></Field>}
  <h3>Currency</h3><Field label="Currency of your prices" help="Set from your business country during onboarding. Every quote states it."><Select aria-label="Currency of your prices" value={defaults.currency||''} onChange={e=>onDefault('currency',e.target.value||undefined)}>{!defaults.currency&&<option value="">Choose a currency</option>}<option value="CAD">Canadian dollars (CAD)</option><option value="USD">US dollars (USD)</option></Select></Field>
  <h3>Business-wide fixed charges and range</h3>{['overheadFixed','minimumJobPrice','travelFee','disposalFee','permitFee'].map(field=><Field key={field} label={human(field)+' ($)'}><ExactNumericInput kind="fixed_amount" value={defaults[field]} onChange={v=>onDefault(field,v)}/></Field>)}
  <Field label="Estimate range buffer (%)"><ExactNumericInput value={defaults.rangeBufferPercent} onChange={v=>onDefault('rangeBufferPercent',v)}/></Field>
  <h3>Optional busy-season labor surcharge</h3>
  <p>Off unless set; 0 means off; adds the entered percentage to labor in the chosen months.</p>
  <Field label="Peak surcharge (%)"><ExactNumericInput value={defaults.peakSurchargePercent} onChange={v=>onDefault('peakSurchargePercent',v)}/></Field>
  <p>The surcharge applies to labor lines and the entered labor portion of installed prices. Installed prices with no labor portion entered carry no surcharge. Select every month for a year-round labor surcharge.</p>
  <Button variant="quiet" onClick={()=>onDefault('peakMonths',Array.from({length:12},(_,i)=>i+1))}>Use business surcharge every month</Button>
  <Field label="Surcharge settings for this service"><Select aria-label="Surcharge settings for this service" value={service.peakMonths!==undefined||service.peakSurchargePercent!==undefined?'custom':'business'} onChange={event=>{const next={...service};if(event.target.value==='business'){delete next.peakMonths;delete next.peakSurchargePercent;}else{next.peakMonths=[...(defaults.peakMonths||[])];next.peakSurchargePercent=defaults.peakSurchargePercent;}onService(next);}}><option value="business">Use business settings</option><option value="custom">Custom settings for this service</option></Select></Field>
  {(service.peakMonths!==undefined||service.peakSurchargePercent!==undefined)&&<><Field label="This service labor surcharge (%)"><ExactNumericInput aria-label="This service labor surcharge (%)" value={service.peakSurchargePercent??defaults.peakSurchargePercent} onChange={value=>onService({...service,peakSurchargePercent:value})}/></Field><fieldset><legend>This service peak months</legend>{Array.from({length:12},(_,i)=>i+1).map(month=><label key={month}><input type="checkbox" aria-label={'This service month '+monthNames[month-1]} checked={(service.peakMonths??defaults.peakMonths??[]).includes(month)} onChange={event=>{const months=service.peakMonths??defaults.peakMonths??[];onService({...service,peakMonths:event.target.checked?[...months,month].sort((a,b)=>a-b):months.filter(value=>value!==month)});}}/>{monthNames[month-1]} </label>)}</fieldset><Button variant="quiet" onClick={()=>onService({...service,peakMonths:Array.from({length:12},(_,i)=>i+1)})}>Apply to this service every month</Button></>}
  {needsQuoteTimeZone&&<Notice tone="warning">Choose a business time zone for peak pricing. Quotes use a valid saved profile time zone; if neither time zone is valid, quotes with a busy-season surcharge are paused.</Notice>}
  <Field label="Business time zone for quotes" help="Peak pricing uses today's date here, even when the job is scheduled for another month."><Select aria-label="Business time zone for quotes" value={defaults.quoteTimeZone||''} onChange={e=>onDefault('quoteTimeZone',e.target.value||undefined)}><option value="">Choose a business time zone</option>{['UTC',...Intl.supportedValuesOf('timeZone')].map(zone=><option key={zone} value={zone}>{zone.replaceAll('_',' ')}</option>)}</Select></Field>
    <fieldset><legend>Peak months</legend>{Array.from({length:12},(_,i)=>i+1).map(month=><label key={month}><input type="checkbox" checked={defaults.peakMonths?.includes(month)||false} onChange={e=>onDefault('peakMonths',e.target.checked?[...(defaults.peakMonths||[]),month].sort((a,b)=>a-b):(defaults.peakMonths||[]).filter(n=>n!==month))}/>{monthNames[month-1]} </label>)}<Button variant="quiet" onClick={()=>onDefault('peakMonths',[])}>No peak months</Button></fieldset>
 </section>;
}

export function CustomerFeePreview({service,feeNames=[],value={},onChange}) {
 const fees=feeNames.filter(fee=>fee!=='permit'&&service.feeRules?.[fee]==='customer_selected');
 if(!fees.length)return null;
 return <section className="field-stack"><h3>Customer fee answers for preview</h3><p>Answer as the customer for this preview only. These answers are not saved as owner pricing decisions.</p>
  {fees.map(fee=><Field key={fee} label={'Apply '+human(fee)+' fee for this preview?'}><Select aria-label={fee+' customer fee for preview'} value={value[fee]===undefined?'':String(value[fee])} onChange={event=>{const next={...value};if(event.target.value==='')delete next[fee];else next[fee]=event.target.value==='true';onChange(next);}}><option value="">Unanswered</option><option value="true">Yes</option><option value="false">No</option></Select></Field>)}
 </section>;
}

export function SavedApproval({meta,ownerId,serviceId,draft,onApproved,onBusyChange,onRevisionConflict}) {
 const [saved,setSaved]=useState(null),[status,setStatus]=useState(null),[confirmed,setConfirmed]=useState({}),[ack,setAck]=useState(false),[legacy,setLegacy]=useState(false),[source,setSource]=useState(''),[error,setError]=useState(null),[free,setFree]=useState(null);
 async function open(){onBusyChange?.(true);try{const book=await api('/api/pricebook/'+ownerId);if(draft.revision!==book.revision)throw Object.assign(Error('The saved price book changed in another session. Your unsaved edits are still here. Reconcile them with the newer saved version.'),{status:409,details:{code:'REVISION_CONFLICT'},remoteBook:book});const selected=book.services.find(s=>s.id===serviceId);if(!selected)throw Error('Save this service first.');if(!approvalMatchesDraft(draft,{book,service:selected}))throw Error('Save editor changes before reviewing the saved configuration.');const validation=await api('/api/pricebook/validate',{method:'POST',body:book});setSaved({book,service:selected});setStatus(validation.statuses.find(s=>s.serviceId===serviceId));setAck(false);setLegacy(false);setConfirmed({});setSource(selected.source||'');setFree(null);setError(null);}catch(e){if(isRevisionConflict(e)){setError(null);setSaved(null);await onRevisionConflict?.(e);}else setError(e);}finally{onBusyChange?.(false);}}
 useEffect(()=>{setSaved(null);setError(null);},[serviceId]);
 const reviewIsCurrent=approvalMatchesDraft(draft,saved);
 const obsoleteFreeTiers=saved&&fenceCatalog(saved.service.pricing)?(free?.freeTiers||[]).filter(name=>!fenceTierKeys(saved.service.pricing).some(t=>t.key===name)):[];
 async function approve(){if(!reviewIsCurrent){setError(Error('The editor changed after this review opened. Your edits are still here. Save them, then open a new review.'));return;}onBusyChange?.(true);try{const result=await api('/api/pricebook/services/'+serviceId+'/approve',{method:'POST',body:{revision:saved.book.revision,confirmConfiguration:ack,confirmLegacySettings:legacy,source,fields:Object.keys(confirmed).filter(k=>confirmed[k]),...(free?{zeroClassification:free}:{})}});const next=await api('/api/pricebook/'+ownerId);await onApproved({before:saved.book,after:next,serviceId,revision:result.revision});setSaved(null);}catch(e){if(isRevisionConflict(e)){setError(null);setSaved(null);await onRevisionConflict?.(e);}else setError(e);}finally{onBusyChange?.(false);}}
 return <section className="editor-section"><h2>Owner approval</h2><Button variant="secondary" disabled={!serviceId} onClick={open}>Review saved configuration</Button>{saved&&<>
  {!reviewIsCurrent&&<Notice tone="warning">The editor changed after this review opened. Your unsaved edits are still here and are not approved. Save them, then open a new review.</Notice>}
  <Notice>This review shows the saved configuration. Save editor changes before opening a new review. Confirming does not enable a disabled service.</Notice>
  <div className="matrix-scroll"><table className="pricing-matrix saved-price-review" aria-label="Saved prices and configuration"><thead><tr><th>Setting</th><th>Saved value</th></tr></thead><tbody>{reviewRows(saved.service,saved.book.defaults,meta,(status?.legacySettings||[]).map(row=>row.path)).map((row,index)=><tr key={index}><th>{row.label}</th><td>{row.value}</td></tr>)}</tbody></table></div>
  {!saved.service.source&&<Field label="Original pricing source"><Select value={source} onChange={e=>setSource(e.target.value)}><option value="">Choose</option><option value="MANUAL">Entered by owner</option><option value="AI_SUGGESTED">AI suggested</option><option value="AI_INTERVIEW">AI interview</option></Select></Field>}
  {['AI_SUGGESTED','AI_INTERVIEW'].includes(source)&&(status?.confirmationFields||[]).map(field=><label key={field} style={{display:'block'}}><input type="checkbox" checked={confirmed[field]===true} onChange={e=>setConfirmed({...confirmed,[field]:e.target.checked})}/> Confirm {reviewLabel(field,saved.service,meta)}</label>)}
  {!!status?.legacySettings?.length&&<><h3>Retained settings from earlier pricing</h3><p>These saved values are retained and are not used by current quoting rules.</p><ul>{status.legacySettings.filter(row=>!row.path.startsWith('confirmedFields.')&&!row.path.startsWith('approvedValues.')).flatMap(row=>{const root=row.path.startsWith('defaults.')?saved.book.defaults:saved.service,path=row.path.replace(/^defaults\./,'');const value=path.split('.').reduce((v,k)=>v?.[k],root);return retainedRows(row.path,value,saved.service,meta).map(item=><li key={item.path}>{item.label}: {item.value}</li>);})}</ul><label><input type="checkbox" checked={legacy} onChange={e=>setLegacy(e.target.checked)}/> I confirm these retained legacy settings are not used by current quoting rules.</label></>}
  <details><summary>Explicit free offerings and included required prices</summary><p>Use only for an explicitly free complete offering or a required price included in another positive all-in price.</p><Button variant="secondary" onClick={()=>setFree({freeCompleteService:saved.service.zeroPricePolicy?.freeCompleteService||false,freeTiers:saved.service.zeroPricePolicy?.freeTiers||[],includedPrices:saved.service.zeroPricePolicy?.includedPrices||{}})}>Edit explicit zero classification</Button>{free&&<><label><input type="checkbox" checked={free.freeCompleteService} onChange={e=>setFree({...free,freeCompleteService:e.target.checked})}/> Entire base offering explicitly free</label>{(fenceCatalog(saved.service.pricing)?fenceTierKeys(saved.service.pricing):(saved.service.tiers||[]).map(t=>({key:t.name,label:t.name}))).map(t=><label key={t.key}><input type="checkbox" checked={free.freeTiers.includes(t.key)} onChange={e=>setFree({...free,freeTiers:e.target.checked?[...free.freeTiers,t.key]:free.freeTiers.filter(n=>n!==t.key)})}/> Entire {t.label} offering explicitly free</label>)}{obsoleteFreeTiers.map(name=><p key={name}>Saved free option no longer in these offerings: {name} <Button variant="quiet" onClick={()=>setFree({...free,freeTiers:free.freeTiers.filter(n=>n!==name)})}>Remove</Button></p>)}<IncludedPrices service={saved.service} meta={meta} value={free.includedPrices} onChange={includedPrices=>setFree({...free,includedPrices})}/></>}</details>
  <label><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)}/> I confirm these exact saved prices, units, factors and rules, including {saved.book.defaults.markupPercent}% {human(saved.book.defaults.markupMode).toLowerCase()} and the {saved.book.defaults.rangeBufferPercent}% estimate range buffer.</label><Button disabled={!reviewIsCurrent||!ack||(status?.legacySettings?.length&&!legacy)||!source||(['AI_SUGGESTED','AI_INTERVIEW'].includes(source)&&(status?.confirmationFields||[]).some(f=>!confirmed[f]))} onClick={approve}>Confirm saved configuration</Button>
 </>}<ErrorMessage error={error}/></section>;
}
function IncludedPrices({service,meta,value,onChange}) {
 const [from,setFrom]=useState(''),[to,setTo]=useState(''),choices=priceChoices(service,meta);
 const options=positive=>choices.filter(row=>positive?row.value>0:row.value===0).map(row=><option key={row.path+'|'+(row.option||'')} value={row.path}>{row.label} ({displayAmount(row.value)})</option>);
 return <div>{Object.entries(value).map(([a,b])=><p key={a}>{reviewLabel(a,service,meta)} included in {reviewLabel(b,service,meta)} <Button variant="quiet" onClick={()=>{const v={...value};delete v[a];onChange(v);}}>Remove</Button></p>)}<Field label="Price included at no extra charge"><Select aria-label="Price included at no extra charge" value={from} onChange={e=>setFrom(e.target.value)}><option value="">Choose a zero price</option>{options(false)}</Select></Field><Field label="Price that already covers this work"><Select aria-label="Price that already covers this work" value={to} onChange={e=>setTo(e.target.value)}><option value="">Choose the covering price</option>{options(true)}</Select></Field><Button variant="secondary" disabled={!from||!to} onClick={()=>{if(from&&to){onChange({...value,[from]:to});setFrom('');setTo('');}}}>Add explicit inclusion</Button></div>;
}
import {SurfaceRowsInput} from './surfacePricingEditor.jsx';
