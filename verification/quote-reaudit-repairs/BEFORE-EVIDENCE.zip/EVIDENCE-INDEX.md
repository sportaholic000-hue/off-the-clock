# Audit evidence index

The report is `quote-engine-pricebook-reaudit.md`. This bundle contains synthetic audit evidence, not production customer data.

## Authoritative successful runs

- `source-baseline.json`: exact GitHub heads, 300 repository file bindings.
- `source-final-check.json`: final comparison of those files; no application source changes.
- `reproduce.mjs`, `reproduction-results.json`: isolated direct reproductions and controls for R01–R08. Dollar inputs and stored cent values are labeled in the output.
- `arithmetic.mjs`, `base-fixtures-extracted.mjs`, `arithmetic-results.json`: 409 arithmetic/boundary checks, all passing. The extracted base fixtures retain the repository's explicit expected line totals; the financial matrix uses separate integer-ratio calculations.
- `tier-price-control.mjs`, `tier-price-control.json`: actual engine quotes from R09's captured before/after tier values ($550 and $600).
- `focused-suite-rerun.tap`: 454 relevant existing tests, all passing.
- `application-tests/`: 193 additional existing tests, all passing. `flow-precision-native.tap` is authoritative for quoteFlowRepairs and precisionFixtureIntegrity. The other ten files have their own complete TAP summaries.
- `browser.mjs`, `browser-run/public/result.json`: seven successful browser/HTTP defect reproductions for R03–R09.
- `browser-ai-removal.mjs`, `browser-ai-removal-retry/public/result.json`: one successful actual-browser R01 reproduction.
- `browser-tier-name.mjs`, `browser-tier-name-run/public/result.json`: one successful actual-browser R09b reproduction.
- Each browser folder includes HTTP evidence and screenshots; source bindings record the application inputs to that run.

A browser reproduction marked `passed: true` means the suspected defect was successfully reproduced. It is not a passing acceptance test for the product.

Screenshots capture the end-of-scenario viewport. Some show a validation summary or the next interview question. The JSON records are authoritative for the complete before/after values and saved HTTP results.

## Harness adjustments, not product findings

Initial attempts encountered an unavailable default scratch `/tmp`, restricted/incomplete subprocess output, an unsupported Node flag, and a browser wait that ran before asynchronous approval fields were ready. The corrected suite uses the supported Node 22 `--experimental-test-isolation=none` option, explicit scratch TMPDIR, and native execution for the subprocess integrity check. The corrected AI-removal browser script waits for approval fields before selecting them.

`harness-attempts/` retains these unsuccessful/incomplete execution logs separately. They are excluded from the report's passing test totals and finding count. The arithmetic fixture adapter initially supplied test metadata as request fields; that was corrected to send only the actual quote envelope before the 409-check passing run. No application source was edited to make any probe pass.

## Reproduction environment

Node 22.23.2; isolated local app with synthetic accounts/books; local Chromium via Playwright. The scripts use absolute paths in this audit workspace and imports from the pinned combined repository. Adjust those paths and the supported local Node/Chromium paths when replaying elsewhere. No live model/provider call is required.

The two repair heads must be combined before replay: PR16 `a7dd434fd148c86d093cb46222f539020fba974c` plus PR17 `4af1a2cd90fc1996a8be1ae96563a8d47ce0dc1a`, common base `c2e9efcdcc4aaca4a7b8f610e4cdf792cb135010`.

Private synthetic databases, login credentials, and browser profiles are omitted. `MANIFEST.json` lists the included files with SHA-256 hashes.
