// Combined PR16 + PR17 verification. Derived from PR17's browser harness;
// F14 must now save and reload successfully, rather than remain a dependency.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import Database from '/workspace/scratch/db4162af70ba/quote-combined-repairs/node_modules/better-sqlite3/lib/index.js';
import {startApplication} from '/workspace/scratch/db4162af70ba/quote-combined-repairs/client/test/widget-application-harness.mjs';
import {convertApplicationBook,applicationMetadata} from '/workspace/scratch/db4162af70ba/quote-combined-repairs/server/src/quoteDoneBridge.js';
import {wallPainting} from '/workspace/scratch/db4162af70ba/quote-combined-repairs/verification/quote-readiness/fixtures.mjs';
const root=process.cwd(),out=path.resolve(process.argv[2]),pub=path.join(out,'public');
fs.mkdirSync(pub,{recursive:true});
const {chromium}=createRequire(import.meta.url)(process.env.PRICEBOOK_BROWSER_MODULE);
const base='http://127.0.0.1:5510',checks=[],wire=[],errors=[],dependencies=[];
const safe=v=>JSON.parse(JSON.stringify(v,(k,v)=>['password','passwordHash','token','bookingToken','bookingTokenReceipt','bookingTokenHash'].includes(k)?'[SYNTHETIC SECRET OMITTED]':v));
const save=(n,v)=>fs.writeFileSync(path.join(pub,n),JSON.stringify(safe(v),null,2));
let app,browser,proxy,db,page;
async function check(name,fn){try{await fn();checks.push({name,passed:true});}catch(e){checks.push({name,passed:false,error:e.stack});}finally{if(page&&!page.isClosed()){const focus=name.startsWith('F04')?page.getByLabel('travel fee rule',{exact:true}):name.startsWith('F07')?page.locator('#field-laborPerWallSqftPerCoat'):name.startsWith('F11')||name.startsWith('F13')?page.locator('.interview-field'):null;if(focus&&await focus.count())await focus.first().scrollIntoViewIfNeeded().catch(()=>{});await page.screenshot({path:path.join(pub,name+'.png')}).catch(()=>{});save(name+'-screen.json',{text:await page.locator('body').innerText(),inputs:await page.locator('input,select').evaluateAll(nodes=>nodes.map(n=>({label:n.getAttribute('aria-label'),value:n.value,invalid:n.getAttribute('aria-invalid')})))});}}console.log('EDITOR_CHECK '+JSON.stringify(checks.at(-1)));}
async function fixture(label,fee='not_applicable',selection){
 const owner=await app.owner(label),call=async(method,url,body,status=200)=>{const r=await app.request(method,url,body,owner.token);assert.equal(r.status,status,JSON.stringify(r));return r.result;};
 const f=wallPainting(),converted=convertApplicationBook({services:[f.ownerPricing],defaults:f.businessDefaults},'toDollars');
 const services=['A','B'].map(name=>{const s=structuredClone(converted.services[0]);for(const k of ['origin','confirmedFields','approvedValues'])delete s[k];s.id=crypto.randomUUID();s.service='[SYNTHETIC] '+name;s.validationInputs=f.customerInputs;s.feeRules.travel=fee;if(selection!==undefined)s.ownerFeeSelections={travel:selection};return s;});
 let book=await call('GET','/api/pricebook/'+owner.id);Object.assign(book,{services,defaults:{...converted.defaults,travelFee:10}});await call('POST','/api/pricebook/save',book);
 for(const service of services){book=await call('GET','/api/pricebook/'+owner.id);await call('POST','/api/pricebook/services/'+service.id+'/approve',{revision:book.revision,confirmConfiguration:true});}
 await call('GET','/api/onboarding/state');db.prepare('UPDATE businessProfiles SET businessTypesJson=? WHERE ownerId=?').run(JSON.stringify(['INTERIOR_PAINTING','ROOFING_REPLACEMENT','ROOFING_REPAIR','FLOORING_INSTALL','LANDSCAPING_CLEANUP','CUSTOM']),owner.id);
 return {owner,services,read:()=>call('GET','/api/pricebook/'+owner.id),call};
}
async function useOwner(f,url='/pricebook',{clear=true}={}){
 await page.goto(base+'/login');await page.evaluate(({token,clear})=>{localStorage.setItem('otc_token',token);if(clear)sessionStorage.clear();},{token:f.owner.token,clear});await page.goto(base+url);
 if(url==='/pricebook')await page.locator('.service-pick').filter({hasText:'[SYNTHETIC] A'}).click();
}
async function bookState(){return page.evaluate(()=>{
 function walk(node){if(!node)return null;for(let h=node.memoizedState;h&&typeof h==='object';h=h.next){const v=h.memoizedState;if(v&&Array.isArray(v.services)&&v.defaults&&'revision'in v)return v;}return walk(node.child)||walk(node.sibling);}
 const root=document.getElementById('root'),key=Object.keys(root).find(k=>k.startsWith('__reactContainer$'));return walk(root[key]?.stateNode?.current||root[key]);
});}
async function openSection(name){const btn=page.getByRole('button',{name:new RegExp('^'+name)}).first();if(await btn.getAttribute('aria-expanded')==='false')await btn.click();}
async function pick(name){await page.locator('.service-pick').filter({hasText:'[SYNTHETIC] '+name}).click();}
async function approve(id){await page.getByRole('button',{name:'Review saved configuration',exact:true}).click();await page.getByLabel('I confirm these exact saved prices, units, factors and rules.',{exact:true}).check();const received=page.waitForResponse(r=>r.url().endsWith('/'+id+'/approve'));await page.getByRole('button',{name:'Confirm saved configuration',exact:true}).click();assert.equal((await received).status(),200);await page.waitForFunction(()=>!document.querySelector('fieldset[disabled]'));}
async function newInterview(f,type,field,value){
 const created=await f.call('POST','/api/pricebook/interview',{mode:'browser',serviceTypes:[type]},201);
 await f.call('PUT','/api/pricebook/interview/'+created.draft.id,{currentField:type+'.'+field,...(value===undefined?{}:{fields:{[type]:{[field]:value}}})});
 await useOwner(f,'/onboarding?step=7');await page.getByRole('button',{name:'Resume saved draft',exact:true}).click();await page.locator('.interview-field').waitFor();return created.draft.id;
}
try{
 app=await startApplication(root,path.join(out,'private'),{port:5512,browserOrigins:[base]});db=new Database(path.join(out,'private/application.sqlite'));
 const dist=path.join(root,'client/dist');
 proxy=http.createServer(async(req,res)=>{try{
  if(req.url.startsWith('/api/')){const chunks=[];for await(const c of req)chunks.push(c);const b=Buffer.concat(chunks),headers={};for(const k of ['origin','content-type','authorization','cookie','referer','sec-fetch-site','idempotency-key'])if(req.headers[k])headers[k]=req.headers[k];
   const r=await fetch(app.base+req.url,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)&&b.length?{body:b}:{})}),text=await r.text();
   wire.push({method:req.method,path:req.url,request:b.length?JSON.parse(b):null,status:r.status,response:JSON.parse(text||'null')});
   res.statusCode=r.status;r.headers.forEach((v,k)=>{if(!['content-length','content-encoding','connection','transfer-encoding'].includes(k))res.setHeader(k,v);});res.end(text);return;}
  const pathname=new URL(req.url,base).pathname,file=!path.extname(pathname)?path.join(dist,'index.html'):path.resolve(dist,'.'+pathname);
  if(!file.startsWith(dist+path.sep)||!fs.existsSync(file)){res.writeHead(404).end();return;}res.setHeader('content-type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(fs.readFileSync(file));
 }catch(e){res.writeHead(500).end('{}');errors.push(e.message);}});await new Promise(r=>proxy.listen(5510,'127.0.0.1',r));
 browser=await chromium.launch({headless:true,executablePath:process.env.PRICEBOOK_BROWSER_EXECUTABLE,args:['--no-sandbox']});page=await browser.newPage({viewport:{width:1280,height:900}});page.setDefaultTimeout(10000);page.on('pageerror',e=>errors.push(e.message));

 async function apiApprove(f,id){const book=await f.read();const validation=await f.call('POST','/api/pricebook/validate',book);const status=validation.statuses.find(s=>s.serviceId===id);return f.call('POST','/api/pricebook/services/'+id+'/approve',{revision:book.revision,confirmConfiguration:true,confirmLegacySettings:true,fields:status?.confirmationFields||[]});}
 async function uiSave(){const wait=page.waitForResponse(r=>r.url().endsWith('/api/pricebook/save')&&r.request().method()==='POST');await page.getByRole('button',{name:'Save & validate',exact:true}).click();assert.equal((await wait).status(),200);await page.waitForFunction(()=>!document.querySelector('fieldset[disabled]'));}


 await check('R09b-tier-default-name-collision',async()=>{
  const f=await fixture('reaudit-tier-names');let b=await f.read();b.services[0].tiers=['Good','Better','Best'].map(name=>({name,overrides:{}}));await f.call('POST','/api/pricebook/save',b);await apiApprove(f,f.services[0].id);await useOwner(f);await openSection('Good / Better / Best tiers');await page.getByRole('button',{name:'Remove tier',exact:true}).first().click();await page.getByRole('button',{name:'Add tier',exact:true}).click();const draft=await bookState();assert.deepEqual(draft.services[0].tiers.map(t=>t.name),['Better','Best','Best']);await uiSave();const saved=await f.read(),validation=await f.call('POST','/api/pricebook/validate',saved);save('R09b-evidence.json',{draft,saved,validation});assert.ok(validation.statuses[0].invalidOwnerFields.some(f=>f.includes('name')));
 });
}catch(e){checks.push({name:'setup',passed:false,error:e.stack});}
finally{
 if(browser)await browser.close();if(proxy)await new Promise(r=>proxy.close(r));if(db)db.close();if(app){await app.stop();save('http.json',app.requests);fs.copyFileSync(path.join(out,'private/source-binding.json'),path.join(pub,'source-binding.json'));}
 save('browser-wire.json',wire);const result={scope:'Fresh read-only audit defect reproductions; pass means the reported defect reproduced',checks,errors,passed:checks.every(c=>c.passed)&&errors.length===0};save('result.json',result);console.log('AUDIT_BROWSER_RESULT '+JSON.stringify(result));if(!result.passed)process.exitCode=1;
}
