import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve(import.meta.dirname,'../quote-combined-repairs');
const store=path.join(import.meta.dirname,'synthetic-pricebooks');
fs.mkdirSync(store,{recursive:true});
process.env.PRICEBOOK_PATH=store;
process.env.JWT_SECRET='[SYNTHETIC] read-only-quote-audit-local-fixtures';
const {mowing,concrete,fixture}=await import(root+'/verification/engine-independent/fixtures.mjs');
const {offeringFixture}=await import(root+'/test/configuredOfferingsFixtures.mjs');
const {includedFixture,confirmedFixtureInputs}=await import(root+'/test/quoteEngineVNextFixtures.mjs');
const {measuredScopeCases}=await import(root+'/test/measuredScopeFixtures.mjs');
const {generateQuoteVNext,sanitizeForCustomerVNext}=await import(root+'/server/quote-engine-vnext/index.js');
const bridge=await import(root+'/server/src/quoteDoneBridge.js');
const {savePricebook,loadPricebook}=await import(root+'/server/priceBookService.js');
const {parseOwnerNumericInput}=await import(root+'/server/priceBookMoney.js');
const {validateInterviewValue,validateStarterOutput}=await import(root+'/server/src/priceBookAI.js');
const {validateStructuredValue,parseInterviewScalar,describeStructuredValue}=await import(root+'/client/src/interviewStructuredValue.js');
const results=[];
function summary(q){return {resultType:q.resultType,midEstimate:q.midEstimate,reviewReason:q.reviewReason,missing:q.missingOwnerFields,invalid:q.invalidOwnerFields,diagnostics:q.ownerDiagnostics};}
function status(b){return bridge.applicationStatus(b.services[0],b);}
function approve(ownerId){const b=loadPricebook(ownerId);const s=status(b);return bridge.approveApplicationService(ownerId,b.services[0].id,{revision:bridge.bookRevision(b),confirmConfiguration:true,confirmLegacySettings:true,fields:s.confirmationFields});}
function saved(f,source='MANUAL'){
 const ownerId='synthetic-audit-'+crypto.randomUUID();const raw=structuredClone(f.ownerPricing);raw.source=source;delete raw.origin;
 savePricebook(ownerId,{services:[raw],defaults:f.businessDefaults});approve(ownerId);
 return {ownerId,book:loadPricebook(ownerId)};
}
for(const field of ['baggingSurchargePercent','tiers']){
 const f=mowing();if(field==='tiers')f.ownerPricing.tiers=[{name:'Basic',overrides:{}}];else f.ownerPricing.pricing[field]=10;
 const {ownerId,book}=saved(f,'AI_INTERVIEW');const before=status(book);const draft=bridge.readApplicationBook(ownerId);
 if(field==='tiers')draft.services[0].tiers=[];else delete draft.services[0].pricing[field];
 bridge.saveApplicationBook(ownerId,draft);let failure=null;try{approve(ownerId);}catch(e){failure={message:e.message,details:e.details};}
 const afterBook=loadPricebook(ownerId),after=status(afterBook);
 const customer=bridge.calculateApplicationQuote(afterBook,afterBook.services[0],{customerInputs:f.customerInputs,contact:{email:'audit@example.invalid'}},{ownerId}).customerResult;
 results.push({case:'deleted-ai-'+field,before:before.status,after:after.status,approvalError:failure,diagnostics:after.ownerDiagnostics,errors:after.validationErrors,staleConfirmed:afterBook.services[0].confirmedFields[field],staleApproval:!!afterBook.services[0].approvedValues[field],customer});
}
{
 const f=offeringFixture('FENCING_INSTALL','itemized'),before=summary(generateQuoteVNext(f));
 f.ownerPricing.pricing.offeringRates.postMaterialEach=0;
 f.ownerPricing=includedFixture(f.ownerPricing,{'offeringRates.postMaterialEach':'offeringRates.fenceMaterialPerLF'});
 results.push({case:'included-offering-price',before,after:summary(generateQuoteVNext(f)),sameCategory:'material',samePriceBasis:'cost',intended:'post material is explicitly included in positive fence material price'});
}
{
 const f=measuredScopeCases().find(r=>r.id==='stairs-itemized').input;
 f.ownerPricing.pricing.scopeRates.stairs_material=0;
 f.ownerPricing.pricing.scopeRates.stairs_underlayment=1000.5;
 f.ownerPricing=includedFixture(f.ownerPricing,{'scopeRates.stairs_material':'scopeRates.stairs_underlayment'});
 results.push({case:'included-fractional-scope-price',after:summary(generateQuoteVNext(f))});
 f.ownerPricing.pricing.scopeRates.stairs_underlayment=1000;
 results.push({case:'included-integer-scope-control',after:summary(generateQuoteVNext(f))});
}
{
 const f=mowing();Object.assign(f.businessDefaults,{taxMode:'TAX_ALL',taxPercent:15});
 const {ownerId,book}=saved(f);const before=status(book);const draft=bridge.readApplicationBook(ownerId);
 draft.defaults.taxMode='TAX_NONE';bridge.saveApplicationBook(ownerId,draft);approve(ownerId);const next=loadPricebook(ownerId);
 results.push({case:'tax-mode-to-none',before:before.status,after:status(next).status,defaults:next.defaults,diagnostics:status(next).ownerDiagnostics,errors:status(next).validationErrors});
}
for(const [name,f,field] of [
 ['concrete-labor',concrete(),'laborPerSqft'],
 ['interior-wall-labor',fixture('INTERIOR_PAINTING',{laborPerWallSqftPerCoat:100,materialPerWallSqftPerCoat:50,minimumJob:0},{areaInputMethod:'wall_sqft',wallAreaSqft:100,wallHeight:'standard',surfaceCondition:'good',coats:1,wallScopeUniform:true,ceilingsIncluded:false,trimIncluded:false}),'laborPerWallSqftPerCoat']
]){
 if(name.startsWith('interior'))f.ownerPricing.priceBasisByCategory.material='sell_price';
 const {ownerId,book}=saved(f);const draft=bridge.readApplicationBook(ownerId);const meta=bridge.applicationMetadata().services.find(s=>s.serviceType===f.serviceType).fields.find(r=>r.field===field);
 const parsed=parseOwnerNumericInput('1.005',{kind:meta.moneyKind,wholeCents:meta.wholeCents});draft.services[0].pricing[field]=parsed;
 const save=bridge.saveApplicationBook(ownerId,draft);approve(ownerId);const after=loadPricebook(ownerId);
 results.push({case:'fractional-rate-'+name,field,metadata:meta,inputDollars:parsed,savedCents:after.services[0].pricing[field],before:status(book).status,saveSuccess:save.success,after:status(after).status,diagnostics:status(after).ownerDiagnostics,quote:summary(bridge.previewApplicationQuote(ownerId,{revision:bridge.bookRevision(after),serviceId:after.services[0].id,customerInputs:f.customerInputs}))});
}

{
 const field='laborPerSqft',type='FLOORING_INSTALL',value={unobtainium:3};
 const def=bridge.applicationMetadata().services.find(s=>s.serviceType===type).fields.find(d=>d.field===field);
 const accepted=validateInterviewValue(type,field,value);
 const starter=validateStarterOutput([{service:'[SYNTHETIC] Floors',serviceType:type,fields:{[field]:value}}],[type]);
 const f=(await import(root+'/verification/engine-independent/fixtures.mjs')).flooring();
 Object.assign(f.ownerPricing.pricing.laborPerSqft,{unobtainium:300});
 results.push({case:'closed-domain-ignored',definition:def,accepted,starter,clientValidation:validateStructuredValue(value,def.shapedKeys,def.label,def),engine:summary(generateQuoteVNext(f))});
}
{
 const type='LANDSCAPING_CLEANUP',field='debrisPricing';
 const def=bridge.applicationMetadata().services.find(s=>s.serviceType===type).fields.find(d=>d.field===field);
 const valid={light:{laborMultiplier:1,disposalFlat:0},moderate:{laborMultiplier:1.5,disposalFlat:20},heavy:{laborMultiplier:2,disposalFlat:40}};
 const bad=structuredClone(valid);bad.light.disposalFlat=0.005;
 results.push({case:'cleanup-interview-leaf-types',validAnswer:valid,clientValidation:validateStructuredValue(valid,def.shapedKeys,def.label,def),serverAcceptsInvalidFixed:validateInterviewValue(type,field,bad),readback:describeStructuredValue(valid,def.shapedKeys,def.label,def)});
}
{
 const def=bridge.applicationMetadata().services.find(s=>s.serviceType==='CUSTOM').fields.find(d=>d.field==='price');
 let clientError;try{parseInterviewScalar('0.005',def);}catch(e){clientError=e.message;}
 results.push({case:'custom-unit-interview',definition:def,pricing:{unit:'per_sqft'},inputDollars:0.005,clientError,serverAccepts:validateInterviewValue('CUSTOM','price',0.005,{unit:'per_sqft'})});
}
{
 const value={vinyl:1.005};
 results.push({case:'siding-whole-cent-ai-guard',accepted:validateInterviewValue('SIDING_REPLACEMENT','laborPerSqft',value)});
}


{
 const type='LANDSCAPING_PLANTING',fields={plantingLaborPerPlant:{small:10,medium:20,large:30,mixed:20},plantMaterialAllowance:{small:5,medium:10,large:15,mixed:10}};
 const accepted=validateStarterOutput([{service:'[SYNTHETIC] Planting',serviceType:type,fields}],[type]);
 const base=(await import('./base-fixtures-extracted.mjs')).happyCases.find(x=>x.serviceType===type);
 const ownerPricing=structuredClone(base.ownerPricing);ownerPricing.pricing.plantingLaborPerPlant.mixed=2000;ownerPricing.pricing.plantMaterialAllowance.mixed=1000;
 results.push({case:'starter-prompt-planting-mixed-unsupported',accepted,engine:summary(generateQuoteVNext({serviceType:type,customerInputs:confirmedFixtureInputs(base.customerInputs),ownerPricing,businessDefaults:mowing().businessDefaults,currentMonth:1,callerType:'owner'}))});
}

{
 const base=(await import('./base-fixtures-extracted.mjs')).happyCases.find(x=>x.serviceType==='LANDSCAPING_CLEANUP');
 const p=structuredClone(base.ownerPricing);p.pricing.debrisPricing.light.disposalFlat=0;
 results.push({case:'cleanup-zero-disposal-engine-control',quote:summary(generateQuoteVNext({serviceType:base.serviceType,ownerPricing:p,customerInputs:{...base.customerInputs,debrisLevel:'light',haulAway:false},businessDefaults:mowing().businessDefaults,currentMonth:1}))});
}

fs.writeFileSync(path.join(import.meta.dirname,'reproduction-results.json'),JSON.stringify(results,null,2));
for(const r of results)console.log(JSON.stringify(r));
