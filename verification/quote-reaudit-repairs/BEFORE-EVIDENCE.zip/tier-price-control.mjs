import fs from 'node:fs';
import assert from 'node:assert/strict';
import {generateQuoteVNext} from '../quote-combined-repairs/server/quote-engine-vnext/index.js';
import {convertApplicationBook} from '../quote-combined-repairs/server/src/quoteDoneBridge.js';
const e=JSON.parse(fs.readFileSync(new URL('browser-run/public/R09-evidence.json',import.meta.url)));
const out={};
for(const label of ['before','after']){
 const b=convertApplicationBook(e[label],'toCents'),s=b.services[0],c=s.validationInputs;
 for(const key of ['validationInputs','quoteDoneApproval','ownerFeeSelections','starterSuggestion','createdAt','updatedAt'])delete s[key];
 const q=generateQuoteVNext({serviceType:s.serviceType,ownerPricing:s,customerInputs:c,businessDefaults:b.defaults,callerType:'owner',currentMonth:1});
 assert.equal(q.resultType,'INSTANT_ESTIMATE_READY',JSON.stringify(q));out[label]={tier:s.tiers,midEstimate:q.midEstimate};
}
assert.equal(out.before.midEstimate,550);assert.equal(out.after.midEstimate,600);
fs.writeFileSync(new URL('tier-price-control.json',import.meta.url),JSON.stringify(out,null,2));
console.log(JSON.stringify(out));
