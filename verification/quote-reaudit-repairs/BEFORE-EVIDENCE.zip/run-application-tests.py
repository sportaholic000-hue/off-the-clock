import subprocess,os,json,pathlib
root=pathlib.Path('/workspace/scratch/db4162af70ba/quote-combined-repairs');out=root.parent/'reaudit-20261002/application-tests';out.mkdir(exist_ok=True)
env=dict(os.environ,TMPDIR='/workspace/scratch/db4162af70ba/audit-tmp')
files=['opusQuoteRepairs','quoteServerCorrectness','quoteReadinessRepairs','pricebookEditorRepairs','agreedAuditFollowup','quoteFlowRepairs','quoteApplicationBoundary','quoteOriginStorage','pricebookPersistence','quotePresentation','precisionFixtureIntegrity','customerExplanation']
results=[]
for name in files:
 with open(out/(name+'.tap'),'w') as f:
  result=subprocess.run(['/workspace/scratch/db4162af70ba/audit-runtime22/node_modules/node/bin/node','--experimental-test-isolation=none','--test','--test-reporter=tap','test/'+name+'.spec.mjs'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'file':name,'exitCode':result.returncode});(out/'results.json').write_text(json.dumps(results,indent=2))
 print(name,result.returncode,flush=True)
