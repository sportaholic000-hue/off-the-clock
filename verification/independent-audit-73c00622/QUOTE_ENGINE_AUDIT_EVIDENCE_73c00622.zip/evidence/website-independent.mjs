import fs from 'node:fs';
import http from 'node:http';
import {extractWebsitePrices} from '../audit-repo/server/src/websitePriceExtraction.js';
import {createWebsitePriceImporter} from '../audit-repo/server/src/websitePriceImport.js';
import {compileVoiceSystemInstruction} from '../audit-repo/server/src/voice/voicePromptCompiler.js';
const cases=[
{id:'W1',body:'<div><p>[SYNTHETIC] Cleaning $99</p><p>Only homes under 1,000 sq ft; first visit only.</p></div>',needed:['Only homes under 1,000 sq ft; first visit only.']},
{id:'W2',plain:true,body:'[SYNTHETIC] Cleaning $99\nOnly homes under 1,000 sq ft; first visit only.',needed:['Only homes under 1,000 sq ft; first visit only.']},
{id:'W3',body:'<div><p>[SYNTHETIC] Cleaning $99</p><p>Only homes under 1,000 sq ft</p></div><div><p>[SYNTHETIC] Deep clean $199</p><p>Only homes under 2,000 sq ft</p></div>',needed:['Only homes under 1,000 sq ft','Only homes under 2,000 sq ft']},
{id:'W4',body:'<article><p>[SYNTHETIC] Item A $10</p><p>Tax included</p></article><article><p>[SYNTHETIC] Item B $20</p><p>Plus tax</p></article>',needed:[]},
{id:'W5',body:'<p hidden>[SYNTHETIC] Hidden $999</p><p>[SYNTHETIC] Cleaning $99</p>',needed:[]}
];
const guideText=fs.readFileSync(new URL('../audit-repo/specs/voice_quote_flows.md',import.meta.url),'utf8');
let current;
const server=http.createServer((req,res)=>{res.setHeader('Content-Type',current.plain?'text/plain':'text/html');res.end(current.body);});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const importer=createWebsitePriceImporter({lookup:async()=>[{address:'8.8.8.8',family:4}],request:(url,options,cb)=>http.request('http://127.0.0.1:'+server.address().port+'/',{...options,lookup:undefined},cb)});
const results=[];
try{for(const c of cases){current=c;const extracted=extractWebsitePrices(c.body,{plain:c.plain});const draft=await importer('https://synthetic-business.example/');
const savedKnowledge={prices:draft.prices}; // synthetic in-memory equivalent of reviewed owner facts
const prompt=compileVoiceSystemInstruction({guideText,business:{businessName:'Synthetic Audit Business',agentName:'Audit'},services:[],knowledge:savedKnowledge});
const facts=JSON.parse(prompt.split('<OWNER_FACTS_JSON>\n')[1].split('\n</OWNER_FACTS_JSON>')[0]);
results.push({id:c.id,body:c.body,extracted,draft,voiceFacts:facts.knowledge.prices,retainsAllConditions:c.needed.every(x=>draft.prices.includes(x))});
}}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
fs.writeFileSync(new URL('./website-independent-results.json',import.meta.url),JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
