# Synthetic workflow expectations, written before execution

The mowing service uses 100 sq ft × $1 per sq ft = **$100.00 CAD per visit**, no fees, tax, markup, minimum or buffer. No live owner data is used.

For each MANUAL, AI_SUGGESTED and AI_INTERVIEW source: save preserves the precise $1 rate; unapproved configuration cannot quote; owner preview is $100; explicit approval of all current AI fields enables the $100 quote. The customer receipt excludes internal pricing and approval fields.

A fixed request UUID can create only one quote. Identical retry returns the original $100.00 and original quote identifier. Changed content at that UUID rejects with 409. An edited rate of **$2** invalidates approval and cannot release a new price until reapproved. Reapproval yields **$200.00** on a new request; historical retry and stored quote remain **$100.00**. Old book revision cannot save or approve. Changed business markup to 25% invalidates approval. After reapproval, the $2 rate produces **$250.00**. A separate unpriced request remains excluded: selected service is $250.00 and no whole-job total exists.

Changing an unrelated service must not rewrite historical receipts. Forged approval, origin, source, or zero-price classification is rejected. A foreign owner cannot replay another owner's request. No contact means no quote or lead writes.
