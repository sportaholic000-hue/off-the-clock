# Additional independent expectations, written before execution

E1–E3: Selecting unpriced bagging or 20 ft of lawn edging on the existing synthetic $100 mowing job returns $100 with the selected add-on expressly excluded, under Step 2b. Selecting unpriced ponding treatment on the existing synthetic $110 flat-roof repair returns $110 with that treatment excluded. The owner editor currently promises that missing optional prices return review; test this discrepancy against the actual result and voice exclusion.

E4–E6: A 320-by-320 synthetic roofing catalog with identical explicit rates must be live, and a selected pair produces the previously calculated $1,810.00. Remove the selected replacement's material rate: the service stays live for other complete products but this pair requires review. Insert malformed text as that rate: readiness must stop rather than quietly ignore malformed data.

E7–E11: Sparse arrays, getters, circular data, unknown customer fields, and non-finite rates require review with no total. Getters must not run.

E12–E13: A valid $100 receipt projects safely. Changing its displayed amount to $101 or its stored line amount by $1 without matching evidence must return review, not a forged total.

E14–E18: AI interview parsing preserves an explicit $0.0075 mowing rate; a discrete fixed gate at $1.005 is rejected. A synthetic starter with a $1 mowing rate keeps $1 exactly; a starter cannot set approval flags. Null interview extraction means clarification and no invented amount. Stubbed providers receive only synthetic input; no network call occurs.

E19–E22: A real phone tool invocation for the same synthetic $100 mowing job returns $100 CAD per visit, with no raw rate. Missing affirmative recap confirmation refuses a quote. Repeating the exact request stores only one successful quote and preserves $100. Changing current pricing after that successful call cannot rewrite its historical replay.
