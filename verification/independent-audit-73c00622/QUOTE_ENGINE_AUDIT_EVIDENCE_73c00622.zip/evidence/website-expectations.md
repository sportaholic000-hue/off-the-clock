# Synthetic website experiments — expectations written before execution

W1: A cleaning card with `[SYNTHETIC] Cleaning $99` and adjacent `Only homes under 1,000 sq ft; first visit only.` must preserve both sentences. The literal amount remains $99. A larger home has no advertised fixed quote.

W2: The same two lines in text/plain must retain the condition or omit the unsafe price. The amount remains $99; it is not an unrestricted $99 price.

W3: Two separate cards, `[SYNTHETIC] Cleaning $99` / `Only homes under 1,000 sq ft` and `[SYNTHETIC] Deep clean $199` / `Only homes under 2,000 sq ft`, must retain each respective limitation without attaching one to the other. Amounts remain $99 and $199.

W4: Two named prices in one article, each with a `Tax included` or `Plus tax` local note, must keep the notes associated with the correct item. $10 includes tax; $20 excludes tax. Neither amount is recalculated by the importer.

W5: A display-hidden stylesheet class is not executed by this importer. A price explicitly hidden by HTML attribute must be excluded. `$999` hidden price must not enter the result; visible `[SYNTHETIC] Cleaning $99` must remain $99. No external page is contacted.
