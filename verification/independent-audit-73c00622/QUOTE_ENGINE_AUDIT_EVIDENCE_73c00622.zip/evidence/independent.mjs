// [SYNTHETIC] Independent audit experiments. No application source is modified.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const root='/workspace/scratch/a52f6105f92a';
const tmp=fs.mkdtempSync(root+'/evidence/tmp/independent-');
process.env.PRICEBOOK_PATH=tmp+'/pricebooks';process.env.DATABASE_PATH=tmp+'/synthetic.sqlite';
process.env.ALLOW_PROVIDER_WRITES='false';
const E=await import(root+'/audit-repo/server/quote-engine-vnext/index.js');
const C=await import(root+'/audit-repo/server/quote-engine-vnext/contracts.js');
const categories=['labor','material','removal','prep','addon','equipment','travel','disposal','permit','overhead','surcharge'];
const map=(keys,v)=>Object.fromEntries(keys.map(k=>[k,v]));
const defaults=()=>({currency:'CAD',quoteTimeZone:'UTC',markupPercent:0,markupMode:'markup',overheadFixed:0,minimumJobPrice:0,travelFee:0,disposalFee:0,permitFee:0,taxMode:'TAX_NONE',taxPercent:0,rangeBufferPercent:0,markupApplies:map(categories,true),peakMonths:[],peakSurchargePercent:0});
function fixture(type,pricing,inputs){
 const id=crypto.randomUUID(); const p=E.withClass2Defaults(type,pricing);
 const s={id,source:'MANUAL',serviceType:type,service:'[SYNTHETIC] '+type,active:true,origin:{serviceId:id,serviceType:type,source:'MANUAL',ownerId:'synthetic-owner',operationId:'synthetic-create',createdAt:'2026-10-06T12:00:00.000Z'},pricing:p,knownOfferings:{},priceBasisByCategory:map(categories,'cost'),taxabilityByCategory:map(categories,false),feeRules:map(['travel','disposal','permit','overhead'],'not_applicable')};
 const fields=C.customerContractForVNext(type,p,s).fields;
 const c=structuredClone(inputs);for(const [k,d] of Object.entries(fields))if(d.type==='slug'&&c[k]!==undefined&&c[k]!=='none'){
  const oid=crypto.randomUUID();s.knownOfferings[k]={[c[k]]:oid};c.confirmedFacts??={};c.confirmedFacts[k]={status:'identified',field:k,value:c[k],offeringId:oid};
 }
 return {serviceType:type,ownerPricing:s,businessDefaults:defaults(),customerInputs:c,callerType:'owner',currentMonth:10};
}
const cases=[];
const add=(name,f,expected,rule,display)=>{cases.push({name,f,expected,rule,display});return f;};
const alter=(f,fn)=>{const n=structuredClone(f);fn(n);return n;};
const roof=fixture('ROOFING_REPLACEMENT',{minimumJob:0,laborPerSquare:{test:5000},materialCostPerSquare:{test:10000},tearOffPerSquare:{test:2000},underlaymentPerSquare:{test:100},underlaymentPriceBasis:{test:'installed_area_sell_price'},accessoryPricingMode:'per_square_allin'}, {roofSizeMethod:'roof_measured',roofSizeInput:1000,existingRoofType:'test',replacementRoofType:'test',pitch:'low',stories:1,existingLayers:1,roofComplexity:'simple',serviceScope:'full'});
add('roof',roof,181000,'10*$50 labor +11*$100 materials +10*$20 removal +10*$1 installed underlayment = $1,810.00.');
add('roof-partial',alter(roof,f=>Object.assign(f.customerInputs,{serviceScope:'partial',partialPercent:25})),45250,'2.5*$50 +2.75*$100 +2.5*$20 +2.5*$1 = $452.50.');
const flat=fixture('FLAT_ROOF_REPLACEMENT',{minimumJob:0,laborPerSqft:{test:100},membraneCostPerSqft:{test:200},tearOffPerSqft:{test:300}},{roofSqft:100,sqftMethod:'exact',membraneType:'test',replacementMembraneType:'test',existingLayers:1,accessDifficulty:'easy',serviceScope:'full',insulationNeeded:false,coverboardNeeded:false});
add('flat-roof',flat,62000,'100*$1 +100*1.10*$2 +100*$3 = $620.00.');
for(const type of ['ROOFING_REPAIR','FLAT_ROOF_REPAIR','SIDING_REPAIR']){
 const roofRepair=type==='ROOFING_REPAIR',flatRepair=type==='FLAT_ROOF_REPAIR',product=roofRepair?'roofType':flatRepair?'membraneType':'sidingType',task=type==='SIDING_REPAIR'?'damageLevel':'repairType',key=type==='SIDING_REPAIR'?'vinyl':'test';
 const hours=flatRepair?'patchRepairHours':'repairHours',mat=roofRepair?'repairMaterialAllowance':flatRepair?'patchMaterialAllowance':'materialAllowance';
 const f=fixture(type,{laborHourlyRate:10000,repairMinimum:0,largeRepairMaxSqft:500,[hours]:{[key]:{patch:{small:1,medium:2,large:3}}},[mat]:{[key]:{patch:{small:1000,medium:2000,large:3000}}}}, {[product]:key,[task]:'patch',affectedArea:10,...(type!=='SIDING_REPAIR'?{leakPresent:false}:{}),...(roofRepair?{pitch:'low',stories:1}:flatRepair?{pondingWater:false,accessDifficulty:'easy'}:{stories:1})});
 add(type,f,11000,'1 hour*$100 +$10 materials = $110.00.');
 add(type+'-medium',alter(f,x=>x.customerInputs.affectedArea=roofRepair?50:20),22000,'2 hours*$100 +$20 = $220.00 at the inclusive medium lower boundary.');
 add(type+'-large',alter(f,x=>x.customerInputs.affectedArea=roofRepair?200.01:80.01),33000,'3 hours*$100 +$30 = $330.00 above medium maximum.');
 add(type+'-too-large',alter(f,x=>x.customerInputs.affectedArea=500.01),null,'Above explicit 500 sq ft repair maximum: review, no price.');
}
const paint=fixture('INTERIOR_PAINTING',{minimumJob:0,laborPerWallSqftPerCoat:100,materialPerWallSqftPerCoat:20},{areaInputMethod:'wall_sqft',wallAreaSqft:100,wallHeight:'standard',wallScopeUniform:true,surfaceCondition:'good',coats:2,ceilingsIncluded:false,trimIncluded:false});paint.ownerPricing.priceBasisByCategory.material='sell_price';
add('basic-paint',paint,24400,'100*2*$1 labor +100*2*$0.20*1.10 paint = $244.00.');
add('basic-paint-fair',alter(paint,x=>x.customerInputs.surfaceCondition='fair'),null,'Basic fair walls must review, never reuse good preparation.');
for(const type of ['INTERIOR_PAINTING','EXTERIOR_PAINTING'])for(const mode of ['installed','itemized']){
 const inside=type==='INTERIOR_PAINTING';
 const d={description:'[SYNTHETIC] defined painting',substrate:'[SYNTHETIC] wall',coating:'[SYNTHETIC] paint',finishCoats:2,surfaceCondition:'good',preparation:'[SYNTHETIC] preparation',primerCoats:1,...(inside?{ceilingsOffered:false,trimOffered:false}: {})};
 const r=mode==='installed'?{installedWallPerSqft:300}:{wallLaborPerSqftPerCoat:100,wallMaterialPerSqftPerCoat:20,prepLaborPerSqft_good:10,prepMaterialPerSqft_good:10,primerLaborPerSqftPerCoat:50,primerMaterialPerSqftPerCoat:10};
 const f=fixture(type,{minimumJob:0,offeringMode:mode,offeringDetails:d,offeringRates:r},{areaInputMethod:'wall_sqft',[inside?'wallAreaSqft':'exteriorAreaSqft']:100,coats:2,surfaceCondition:'good',...(inside?{wallHeight:'standard',wallScopeUniform:true,ceilingsIncluded:false,trimIncluded:false}:{stories:1})});f.ownerPricing.priceBasisByCategory.material='sell_price';
 add(type+'-'+mode,f,mode==='installed'?30000:32600,mode==='installed'?'100*$3 = $300.00.':'Finish $200+$44; prep $10+$11; primer $50+$11 = $326.00.');
}
const floor=fixture('FLOORING_INSTALL',{minimumJob:0,laborPerSqft:{tile:100},materialPerSqft:{tile:100}},{sqft:100,sqftMethod:'exact',newFlooringType:'tile',existingFloorType:'none',removalNeeded:false,roomCount:1,layoutPattern:'straight',stairSteps:0});
add('floor-install',floor,23200,'Small-room labor 100*$1*1.2=$120; material 100*$1*1.12=$112; $232.00.');
add('floor-replacement',fixture('FLOORING_REPLACEMENT',floor.ownerPricing.pricing,{...floor.customerInputs,subfloorIssues:false}),23200,'Same selected scope as installation: $232.00.');
add('floor-diagonal',alter(floor,x=>x.customerInputs.layoutPattern='diagonal_or_pattern'),26300,'Labor 100*1*1.2*1.2=$144; material 100*1*1.19=$119; $263.00.');
for(const [area,total]of [[150,34800],[150.01,33302],[300,66600],[300.01,63602]])add('floor-boundary-'+area,alter(floor,x=>x.customerInputs.sqft=area),total,'Inclusive small maximum 150 and medium maximum 300. Totals respectively $348.00, $333.02, $666.00, $636.02; round each extended line once.');
for(const type of ['FENCING_INSTALL','FENCING_REPLACEMENT'])for(const mode of ['installed','itemized']){
 const d={description:'[SYNTHETIC] fence',fenceType:'test',fenceHeight:6,postFootingDescription:'[SYNTHETIC] standard footing',gates:{},...(type.endsWith('REPLACEMENT')?{removalOffered:false}:{})};
 const f=fixture(type,{minimumJob:0,offeringMode:mode,offeringDetails:d,offeringRates:mode==='installed'?{installedFencePerLF:1000}:{fenceLaborPerLF:100,fenceMaterialPerLF:100,postMaterialEach:100,footingLaborEach:100,footingMaterialEach:100}},{linearFeet:100,lfMethod:'exact',fenceType:'test',fenceHeight:6,terrainSlope:'flat',gates:{},cornerCount:0,...(type.endsWith('REPLACEMENT')?{oldFenceRemoval:false}:{})});
 add(type+'-'+mode,f,mode==='installed'?100000:25200,mode==='installed'?'100*$10=$1,000.00.':'100 labor +110 waste-adjusted infill +14 posts*($1+$1+$1)=$252.00.');
}
const slab=fixture('CONCRETE_DRIVEWAY',{minimumJob:0,laborPerSqft:100,concreteCostPerCubicYard:8100,formworkPerLF:100},{dimensionMethod:'exact',length:10,width:10,thickness:4,finishType:'broom',demolitionNeeded:false,reinforcement:'none',accessDifficulty:'easy',baseNeeded:false,adjoinsExistingConcrete:false});
add('concrete-driveway',slab,25000,'100*$1 labor +100*4/324*1.10*$81 concrete +40*$1 formwork = $250.00.');
add('concrete-patio',fixture('CONCRETE_PATIO_SLAB',slab.ownerPricing.pricing,slab.customerInputs),25000,'Same dimensions and scope: $250.00.');
add('concrete-adjoining',alter(slab,x=>Object.assign(x.customerInputs,{adjoinsExistingConcrete:true,adjoiningEdgeLF:10})),24000,'$100 labor+$110 concrete+30*$1 formwork=$240.00.');
add('concrete-all-adjoining',alter(slab,x=>Object.assign(x.customerInputs,{adjoinsExistingConcrete:true,adjoiningEdgeLF:40})),21000,'$100 labor+$110 concrete+zero formwork=$210.00.');
add('concrete-excess-edge',alter(slab,x=>Object.assign(x.customerInputs,{adjoinsExistingConcrete:true,adjoiningEdgeLF:40.01})),null,'Adjoining edges exceed perimeter: review, no estimate.');
add('cleanup',fixture('LANDSCAPING_CLEANUP',{minimumServiceCharge:0,cleanupBaseRatePerSqft:100,debrisPricing:map(['light','moderate','heavy'],{laborMultiplier:1,disposalFlat:2000})},{yardSqft:100,sqftMethod:'exact',debrisLevel:'light',slope:'flat',haulAway:false}),12000,'100*$1+$20 disposal=$120.00.');
const mulch=fixture('LANDSCAPING_MULCH',{minimumServiceCharge:0,mulchMaterialPerYard:{test:1000},mulchInstallLaborPerYard:500},{inputMethod:'yards',mulchArea:2,mulchType:'test',bedCondition:'clean',edgingNeeded:false,accessDifficulty:'easy'});
add('mulch-yards',mulch,3000,'2*$10+2*$5=$30.00; direct yards have no extra overage.');
add('mulch-area',alter(mulch,x=>Object.assign(x.customerInputs,{inputMethod:'sqft',mulchArea:324,mulchDepth:2})),3300,'324*2/324=2 yd; material 2*1.15*$10=$23; labor2*$5=$10; $33.00.');
add('sod',fixture('LANDSCAPING_SOD',{minimumServiceCharge:0,sodMaterialPerSqft:100,sodInstallLaborPerSqft:100},{sodSqft:100,sqftMethod:'exact',groundPrepNeeded:false,slope:'flat',accessDifficulty:'easy'}),20500,'100*$1 labor+105*$1 material=$205.00.');
add('planting',fixture('LANDSCAPING_PLANTING',{minimumServiceCharge:0,plantingLaborPerPlant:{small:1000,medium:2000,large:3000},plantMaterialAllowance:{small:2000,medium:3000,large:4000}},{plantsBySize:{small:1,medium:2,large:0},bedCondition:'clean',mulchNeeded:false,accessDifficulty:'easy'}),13000,'1*($10+$20)+2*($20+$30)=$130.00.');
const mowing=fixture('LANDSCAPING_MOWING',{minimumServiceCharge:0,mowingBaseRatePerSqft:100,frequencyMultipliers:map(['weekly','biweekly','monthly','one_time'],1),overgrowthMultipliers:map(['maintained','overgrown','severe'],1)},{yardSqft:100,sqftMethod:'exact',serviceFrequency:'weekly',grassCondition:'maintained',bagClippings:false,edgingIncluded:false});
add('mowing',mowing,10000,'100*$1=$100.00 per visit.');
add('siding',fixture('SIDING_REPLACEMENT',{minimumJob:0,laborPerSqft:{vinyl:100},materialPerSqft:{vinyl:100}},{areaInputMethod:'sqft',sidingAreaSqft:100,sidingType:'vinyl',stories:1,oldSidingRemoval:false,trimIncluded:false}),21000,'100*$1 labor+110*$1 material=$210.00.');
for(const [unit,inputs]of [['flat',{}],['per_hour',{hours:2}],['per_unit',{itemCount:2}],['per_sqft',{areaSqft:2}],['per_LF',{linearFeet:2}],['per_square',{roofSquares:2}]]){
 const f=fixture('CUSTOM',{minimumJob:0,customPricingMode:'fixed',price:10000,unit,customChargeClassification:'labor'},{service:'[SYNTHETIC] CUSTOM',serviceConfirmed:true,unit,...inputs});
 add('custom-'+unit,f,unit==='flat'?10000:20000,unit==='flat'?'One fixed $100.00 service.':'2 units*$100=$200.00.');
}
add('markup',alter(mowing,x=>x.businessDefaults.markupPercent=25),12500,'$100 cost plus 25% markup=$125.00.');
add('margin',alter(mowing,x=>Object.assign(x.businessDefaults,{markupPercent:25,markupMode:'margin'})),13333,'$100/0.75=$133.333..., rounded $133.33.');
add('tax-all-minimum',alter(mowing,x=>Object.assign(x.businessDefaults,{minimumJobPrice:15000,taxMode:'TAX_ALL',taxPercent:10,rangeBufferPercent:10})),16500,'Minimum $150 pre-tax +$15 tax=$165.00 single minimum-bound price.',[165,165,165]);
add('fractional-rate',alter(mowing,x=>{x.ownerPricing.pricing.mowingBaseRatePerSqft=0.75;x.customerInputs.yardSqft=10000;}),7500,'10,000*$0.0075=$75.00.');
add('half-cent-line',alter(mowing,x=>{x.ownerPricing.pricing.mowingBaseRatePerSqft=0.5;x.customerInputs.yardSqft=201;}),101,'201*$0.005=$1.005, rounds $1.01.');
add('peak-month',alter(mowing,x=>Object.assign(x.businessDefaults,{peakMonths:[10],peakSurchargePercent:10})),11000,'$100 explicit labor+10%=$110.00.');
add('fee',alter(mowing,x=>{x.ownerPricing.feeRules.travel='always';x.businessDefaults.travelFee=1500;}),11500,'$100 labor+$15 flat travel=$115.00.');
add('invalid-margin',alter(mowing,x=>Object.assign(x.businessDefaults,{markupPercent:100,markupMode:'margin'})),null,'100% margin is division by zero: review.');
add('missing-scope-price',alter(floor,x=>Object.assign(x.customerInputs,{stairSteps:2})),null,'Selected stairs without defined scope cannot yield a subtotal.');
add('malformed-number',alter(mowing,x=>x.customerInputs.yardSqft='100'),null,'Text is not a numeric measured area: review.');
add('oversized-measurement',alter(mowing,x=>x.customerInputs.yardSqft=10000001),null,'Above 10,000,000 square feet: review.');
add('unsafe-total',alter(mowing,x=>x.ownerPricing.pricing.mowingBaseRatePerSqft=Number.MAX_SAFE_INTEGER),null,'Extended total exceeds safe cents: review.');
if(process.argv.includes('--expectations')){
 fs.writeFileSync(root+'/evidence/independent-expectations.md','# Independently handwritten expectations — before execution\n\nAll data explicitly synthetic. No fees, markup, tax or minimum unless stated.\n\n'+cases.map(c=>`- ${c.name}: ${c.rule}`).join('\n')+'\n');
 fs.writeFileSync(root+'/evidence/independent-cases.json',JSON.stringify(cases,null,2));
 console.log('Wrote expectations and inputs for '+cases.length+' cases; no engine calculation executed.');
}else if(!process.argv.includes('--fixtures-only')){
 const results=[];
 for(const c of cases){let result,error;try{result=E.generateQuoteVNext(c.f);const cents=result.options?.[0]?.calculationRecord?.scenarios?.mid?.finalTotalCents??result.calculationRecord?.options?.[0]?.scenarios?.mid?.finalTotalCents; if(c.expected===null)assert.equal(result.resultType,'ESTIMATE_REQUIRES_REVIEW');else{assert.equal(result.resultType,'INSTANT_ESTIMATE_READY');assert.equal(result.midEstimate,c.expected/100);if(c.display)assert.deepEqual([result.lowEstimate,result.midEstimate,result.highEstimate],c.display);assert.equal(E.sanitizeForCustomerVNext(result).resultType,'INSTANT_ESTIMATE_READY');}}catch(e){error=e.message;}
  results.push({name:c.name,pass:!error,error,result});console.log(JSON.stringify({name:c.name,pass:!error,expected:c.expected,actual:result?.midEstimate,resultType:result?.resultType,error}));
 }
 fs.writeFileSync(root+'/evidence/independent-results.json',JSON.stringify(results,null,2));
 console.log('SUMMARY '+JSON.stringify({tests:results.length,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length}));
}
export {fixture,defaults,cases,alter,add,root};
