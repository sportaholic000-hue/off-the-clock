import os, pathlib, subprocess, sys
root=pathlib.Path('/workspace/scratch/a52f6105f92a')
env=os.environ.copy()
env['PATH']=str(root/'named-contact-tools/node_modules/node/bin')+':'+env['PATH']
env['TMPDIR']=str(root/'named-contact-evidence/tmp')
env['PLAYWRIGHT_BROWSERS_PATH']=str(root/'named-contact-tools/browsers')
env['PRICEBOOK_BROWSER_MODULE']=str(root/'named-contact-tools/node_modules/playwright')
log=root/'named-contact-evidence'/sys.argv[1]
with log.open('w') as out:
    result=subprocess.run(sys.argv[2:],env=env,cwd=root/'named-contact-repo',stdout=out,stderr=subprocess.STDOUT)
print('exit='+str(result.returncode)+' log='+str(log),flush=True)
print('\n'.join(log.read_text().splitlines()[-24:]),flush=True)
sys.exit(result.returncode)
